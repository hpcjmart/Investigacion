#ifndef include_check_h
#define include_check_h

#include "cl_petsc_PetscError.h"


#define check(operation, error)						\
  do									\
    {									\
      const int code = (operation);					\
      if (code)								\
	cl_petsc_PetscError_mt_check_jint_LP_JA_jint(code, error);	\
    }									\
  while (0)


#endif /* !include_check_h */


/*
 * Local variables:
 * c-file-style: "gnu"
 * End:
 */
