/*
 * "Copyright (c) 1998 by Frederick C. Wong and The Regents of the University 
 * of California.  All rights reserved."
 * 
 * Permission to use, copy, modify, and distribute this software and its
 * documentation for any purpose, without fee, and without written agreement is
 * hereby granted, provided that the above copyright notice and the following
 * two paragraphs appear in all copies of this software.
 *  
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY PARTY FOR
 * DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES ARISING OUT
 * OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF THE UNIVERSITY OF
 * CALIFORNIA HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * THE UNIVERSITY OF CALIFORNIA SPECIFICALLY DISCLAIMS ANY WARRANTIES,
 * INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY
 * AND FITNESS FOR A PARTICULAR PURPOSE.  THE SOFTWARE PROVIDED HEREUNDER IS
 * ON AN "AS IS" BASIS, AND THE UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO
 * PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS.
 * 
 * Author:	        Frederick C. Wong (fredwong@CS.Berkeley.EDU)
 * Filename:            am_init.c
 * Creation Date:       Sat Jan 25th 1997
 * Description:         Initialization code MPICH v1.0.12 ADI-AMII-sun4
 * Last Modified:       Wed Aug 19th 1998
 *
 */

#include <split-c.h>
#include "mpid.h"

int MPI_cooperates_with_Split_C = 1;

void* MPID_AM_Init(int *argc,
		   char ***argv) {
  
  int   network_pid;
  int   i;
  char  buffer[512];
  
  en_t  my_ep_name;
  en_t *ep_name;

  /* No stdout and stderr buffering */
  setvbuf(stdout, NULL, _IONBF, 0);
  setvbuf(stderr, NULL, _IONBF, 0);

  bzero(buffer, 512);
  MPID_AM_ERROR(sysinfo(SI_HOSTNAME, buffer, 257), -1);

  MPID_AM_ERROR(Glib_Initialize(), 0);
  MPID_MyWorldRank = (int) Glib_GetMyVnn();
  MPID_WorldSize   = (int) Glib_GetParallelDegree();
  network_pid      = (int) Glib_GetMyNpid();

  /* setting up active messages layer */
  MPID_AM_SAFE(AM_Init(), AM_OK);
  MPID_AM_Bundle = __sc_bundle;
  MPID_AM_SAFE(AM_AllocateEndpoint(MPID_AM_Bundle,
				   &MPID_AM_EndPoint,
				   &my_ep_name),
	       AM_OK);
  MPID_AM_SAFE(AM_SetTag(MPID_AM_EndPoint, (tag_t)network_pid), AM_OK);

  /* setup all the active messages handlers */
  MPID_AM_SAFE(AM_SetHandler(MPID_AM_EndPoint,
			     MPID_DEFAULT_ERROR_HANDLER,
			     (void (*) ()) MPID_Default_error_handler),
	       AM_OK);
  MPID_AM_SAFE(AM_SetHandler(MPID_AM_EndPoint,
			     MPID_STANDARD_NULL_HANDLER,
			     MPID_Standard_null_handler),
	       AM_OK);
  MPID_AM_SAFE(AM_SetHandler(MPID_AM_EndPoint,
			     MPID_STANDARD_SHORT_HANDLER,
			     MPID_Standard_short_handler),
	       AM_OK);
  MPID_AM_SAFE(AM_SetHandler(MPID_AM_EndPoint,
			     MPID_STANDARD_LONG_HANDLER,
			     MPID_Standard_long_handler),
	       AM_OK);
  MPID_AM_SAFE(AM_SetHandler(MPID_AM_EndPoint,
			     MPID_READY_HANDLER,
			     MPID_Ready_handler),
	       AM_OK);
  MPID_AM_SAFE(AM_SetHandler(MPID_AM_EndPoint,
			     MPID_SYNC_HANDLER,
			     MPID_Sync_handler),
	       AM_OK);
  MPID_AM_SAFE(AM_SetHandler(MPID_AM_EndPoint,
			     MPID_REPLY_SEND_COMPLETED_HANDLER,
			     MPID_Reply_send_completed_handler),
	       AM_OK);
  MPID_AM_SAFE(AM_SetHandler(MPID_AM_EndPoint,
			     MPID_REPLY_NOTHING_HANDLER,
			     MPID_Reply_nothing_handler),
	       AM_OK);
  MPID_AM_SAFE(AM_SetHandler(MPID_AM_EndPoint,
			     MPID_REPLY_OKAY_TO_SEND_HANDLER,
			     MPID_Reply_okay_to_send_handler),
	       AM_OK);
  MPID_AM_SAFE(AM_SetHandler(MPID_AM_EndPoint,
			     MPID_REPLY_SEND_ERROR_HANDLER,
			     MPID_Reply_send_error_handler),
	       AM_OK);
  MPID_AM_SAFE(AM_SetHandler(MPID_AM_EndPoint,
			     MPID_SEND_BYTE_HANDLER,
			     MPID_Send_byte_handler),
	       AM_OK);
  MPID_AM_SAFE(AM_SetHandler(MPID_AM_EndPoint,
			     MPID_REQUEST_OKAY_TO_SEND_HANDLER,
			     MPID_Request_okay_to_send_handler),
	       AM_OK);
  MPID_MaxXferSize = AM_MaxMedium();

  /* setup nameserver to map other endpoints */
  putenv("NS_SILENT=SHUT_THE_HELL_UP");
  /* ENS_HOST is defined as a literal string in the Makefile */
  putenv("NS_HOSTNAME=" ENS_HOST);

  MPID_AM_SAFE(NameServer_Init(), 0);
  /* bind my endpoint name */
  bzero(buffer, 512);
  sprintf(buffer, "%s-%d-%d", (*argv)[0], network_pid, MPID_MyWorldRank);
  MPID_AM_SAFE(NameServer_Bind_Version_Flags(buffer,
					     (byte *)&my_ep_name,
					     sizeof(en_t),
					     ENS_VERSION_NOT_THERE,
					     ENS_FLAG_DESTROY_BINDING_ON_CONNECTION_CLOSE),
	       0);
  /* lookup other endpoint names */
  srand((unsigned int)MPID_MyWorldRank);
  for (i = 0; i < MPID_WorldSize; i++) {
    if (i != MPID_MyWorldRank) {
      /* lookup other endpoint */
      int nbytes;
      bzero(buffer, 512);
      sprintf (buffer, "%s-%d-%d", (*argv)[0], network_pid, i);
      do {
	nbytes = 0;
	MPID_AM_SAFE(NameServer_Lookup(buffer, (byte **)&ep_name, &nbytes), 0);
	if(nbytes == 0) usleep((rand() * rand()) % 100000);
      } while (nbytes == 0);
      /* found it, map to my endpoint */
      MPID_AM_SAFE(AM_Map(MPID_AM_EndPoint, i, *ep_name, (tag_t)network_pid),
		   AM_OK);
    }
  }

  Glib_Barrier();

  return ctx;
}

void MPID_AM_End() {

  Glib_Barrier();

  AM_FreeEndpoint(MPID_AM_EndPoint);
  AM_Terminate();
}
