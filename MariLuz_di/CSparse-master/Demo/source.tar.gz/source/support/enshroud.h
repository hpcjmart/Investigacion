#ifndef include_enshroud_h
#define include_enshroud_h

#include <petschead.h>
#include "cl_petsc_PetscError.h"

#define cl(type)   cl_petsc_##type
#define new(type)  ((cl(type) *) ti_malloc(sizeof(cl(type))))
#define ctor(type) cl(type##_mt_##type##_LP_cl_petsc_Opaque)

#define enshroud(handle, type)										\
  (((PetscObject) handle)->cpp ? (cl(type) *) ((PetscObject) handle)->cpp				\
                               : ((PetscObject) handle)->cpp = ctor(type)(new(type),			\
									  (cl(Opaque) *) (handle)))


#endif /* !include_enshroud_h */


/*
 * Local variables:
 * c-file-style: "gnu"
 * End:
 */
