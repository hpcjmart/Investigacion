#ifndef include_mpi_init_h
#define include_mpi_init_h


extern int MPI_cooperates_with_Split_C;


#endif /* !include_mpi_init_h */
