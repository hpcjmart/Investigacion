import petsc.Petsc;
import petsc.Range;
import petsc.Vec;


public class DistVectorSum {
    public static void main(String[] args) {
	Petsc local petsc = new Petsc(args, null, null, null);

	int limit = Ti.numProcs();
	int n = Ti.thisProc() + 1;

	/*
	 * We want to compute the following triangular sum:
	 *
	 *     1 +
	 *     2 + 2 +
	 *     3 + 3 + 3 +
	 *     4 + 4 + 4 + 4 +
	 *     5 + 5 + 5 + 5 + 5
	 *
	 * and so on, up to some maximum limit (in this case, 5).
	 *
	 * We do this by creating a vector containing all of the
	 * addends, and then requesting the vector's sum.  The vector
	 * is distributed in a very uneven manner:
	 *
	 *    - process 0 holds one 1
	 *    - process 1 holds two 2's
	 *    - process 2 holds three 3's
	 *    - and so on
	 */
	
	Vec local vector = new Vec(n, Vec.PETSC_DECIDE, null);	
	Range range = vector.getOwnershipRange(null);
	System.out.println("populating " + range + " with all " + n + "'s");
	
	for (int entry = range.start; entry < range.end; ++entry)
	    vector.setValue(entry, n, Vec.INSERT_VALUES);

	System.out.println("summing vector");
	System.out.println("sum == " + vector.sum(null)
			   + ", should be "
			   + (2 * limit + 1) * (limit + 1) * limit / 6.);
	
	petsc.finalize(null);
    }
}
