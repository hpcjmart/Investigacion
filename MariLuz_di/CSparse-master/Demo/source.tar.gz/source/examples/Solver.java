import petsc.*;

/*
  WARNING: this application does not make any sense, mathematically.
  
  It is intended to illustrate, as briefly as possible, how one goes
  about subclassing, creating, and using a nonlinear solver.  The
  actual mathematical operations being performed are completely bogus,
  and should *not* be taken seriously.
 */

class Solver extends SNESNonlinear {

    /**
     * create a solver for our particular problem
     *
     * @see {@link petsc.SNESNonlinear#SNESNonlinear(Comm, int[])}
     */
    Solver() {
	super(Comm.self, null);
	
	/*
	  If we needed to store any extra data for use later, here is
	  where we might set that up.  The Solver class could easily
	  be given extra fields, and those fields would be available
	  later when Solver.function or Solver.jacobian is called.

	  It might also be reasonable to call SNES.setJacobian or
	  SNESNonlinear.setFunction here, if those are things that
	  would be fixed for all instances of the solver.
	  Essentially, you are taking a generic nonlinear solver and
	  customizing it to be a solver for your *particular* problem.
	*/
    }
    

    /**
     * compute the function to be solved at a particular point
     *
     * @param x the vector at which the function is to be evaluated
     * @param f the vector into which the function value is to be placed
     * @param error an reference to a PETSc error code.  This is
     *              suitable for passing down to any other PETSc
     *              methods that the function may call.
     * @see {@link petsc.SNESNonlinear#function}
     */
    protected local void function(Vec local x, Vec local f, int[] local error)
    {
	// f(x) = 1/x
	x.copy(f, error);
	f.reciprocal(error);
    }

    /**
     * compute an approximation of the Jacobian
     *
     * @param x the vector at which the function is to be evaluated
     * @param A a reference to the Jacobian matrix
     * @param B a reference to the preconditioner matrix
     * @param flag a flag indicating information about the
     *             preconditioner matrix structure.  This must be one
     *             of the constants defined by {@link MatStructure}.
     * @param error an reference to a PETSc error code.  This is
     *              suitable for passing down to any other PETSc
     *              methods that the function may call.
     * @see {@link petsc.SNES#jacobian}
     */
    protected local void jacobian(Vec local x,
				  MatBase local[] local A,
				  MatBase local[] local B,
				  int[] local flag, int[] local error)
    {
	/*
	  I really haven't the faintest idea what a Jacobian is.
	
	  There should probably be some fancy math here.  I presume
	  that we would be computing a new B[0] in terms of x and
	  A[0], or something like that.
	
	  In any case, both A and B are designed so that you can
	  replace them with entirely new matrixes, if that's called
	  for.  For example, you could do this:
	  
	  A[0] = new Mat(...);

	  After doing whatever calculations are needed, be sure to set
	  flag[0] appropriately.  This flag describes how the A[0] and
	  B[0] matrixes have been changed.  {@link petsc.MatStructure}
	  defines the various constants that one can use.
	*/
    }

    static public void main(String[] args) {
	Petsc.initialize(args, null, null, null);

	// All of the following should actually be set to something
	// useful.  I'm leaving them uninitialized here simply because
	// this example program is mathematically bogus anyway.
	Vec local x, r;
	Mat local A, B;

	// create and set up the solver
	Solver local solver = new Solver();
	solver.setFunction(r, null);
	solver.setJacobian(A, B, null);

	// solve it!
	int iters = solver.solve(x, null);
	
	Petsc.finish(null);
    }
}
