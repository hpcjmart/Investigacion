import petsc.*;


class VectorRawAccess {
    public static void main(String[] args)
    {
	// start up PETSc
	Petsc.initialize(args, null, null, null);

	// create a vector and get access to its raw data
	Vec local vector = new Vec(10, null);
	double[1d] local array = vector.getArray(null);

	// fill in the raw data array
	foreach (entry in array.domain())
	    array[entry] = entry[1];

	// tell the vector we're done poking around in its internals
	vector.restoreArray(array, null);

	// visually show that the values we put into the raw data
	// array really did make it back into the vector itself	
	vector.view(ViewerASCII.out(Comm.self), null);

	// shut down PETSc
	Petsc.finish(null);
    }
}
