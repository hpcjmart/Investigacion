import petsc.Petsc;


public class HelloWorld {
    public static void main(String[] args) {
	Petsc local petsc = new Petsc(args, null, null, null);
	System.out.println("Hello, world!");
	petsc.finalize(null);
    }
}
