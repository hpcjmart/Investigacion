import petsc.Options;
import petsc.Petsc;
import petsc.Vec;


public class SimpleVectorOps {
    public static void main(String[] args) {
	Petsc local petsc = new Petsc(args, null, null, null);

	Integer option = Options.getInt(null, "-n", null);
	int n = option == null ? 10 : option.intValue();
	Vec local vector = new Vec(n, null);
	int entry;

	System.out.println("populating vector with  1/1, 1/2, 1/3, ... 1/" + n);
	for (int entry = 0; entry < n; ++entry)
	    vector.setValue(entry, 1. / (entry + 1), Vec.INSERT_VALUES);

	System.out.println("taking reciprocal of vector");
	vector.reciprocal(null);

	System.out.println("summing vector");
	System.out.println("sum == " + vector.sum(null)
			   + ", should be " + (n * n + n) / 2.);

	petsc.finalize(null);
    }
}
