import petsc.Comm;
import petsc.Mat;
import petsc.Petsc;
import petsc.PetscObject;
import petsc.Vec;
import petsc.Viewer;
import petsc.ViewerASCII;


public class MatMult {

    public static void main(String[] args) {
	Petsc local petsc = new Petsc(args, null, null, null);
	Viewer local viewer = ViewerASCII.out(Comm.self);

	int n = 3;
	Vec local vector = new Vec(n, null);
	int entry;

	/* Set up the vector with the values 0..n-1 */
	for (entry = 0; entry < n; ++entry) {
	  vector.setValue(entry, entry, Vec.INSERT_VALUES);
	}

	/* Print it out. */
	vector.view(viewer, null);

	/* Set up the matrix with the values 0..(n^2)-1 */
	Mat local mat = new Mat(n, n, 3, null, null);
	double[] local vals = new double[n*n];
	int[] local indices = new int[n];
	for (entry = 0; entry < (n*n); ++entry) {
	  vals[entry] = entry;
	}
	for (entry = 0; entry < n; ++entry) {
	  indices[entry] = entry;
	}

	mat.setValues(n, indices, n, indices, vals, Mat.INSERT_VALUES, null);
	mat.assemblyBegin(Mat.FINAL_ASSEMBLY, null);
	mat.assemblyEnd(  Mat.FINAL_ASSEMBLY, null);

	/* Print it out. */
	mat.view(viewer, null);

	/* Set up the result vector */
	Vec local result = new Vec(n, null);
	
	/* Multiply! */
	mat.mult(vector, result, null);

	/* Print the result out. */
	result.view(viewer, null);

	petsc.finalize(null);
    }
}
