package petsc;


/**
 * any raw PETSc object created by the native libraries.  This is not
 * actually a Titanium Object, but rather is simply a C pointer.  This
 * field can be copied around and assigned, but it must never be used
 * as though it were actually a real Object.  It may only be used by
 * native code, which may cast an <code>Opaque local</code> back to
 * the proper PETSc C type, such as <code>Vec</code> or
 * <code>Mat</code>.
 */

interface Opaque {
}
