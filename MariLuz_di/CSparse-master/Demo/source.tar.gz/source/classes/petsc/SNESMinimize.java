package petsc;


/** SNES solvers for unconstrained minimization problems */

public abstract class SNESMinimize extends SNES {

    /**
     * creates a solver for unconstrained minimization problems
     *
     * @param comm the communicator that will use the solver
     * @param error an optional reference to a PETSc error code
     * @see <a href="http://www-unix.mcs.anl.gov/petsc/docs/manualpages/SNES/SNESCreate.html"><code>SNESCreate</code></a>
     */
    public SNESMinimize(Comm comm, int[] local error) {
	super(createRaw(comm, error));
    }

    /**
     * creates a solver for unconstrained minimization problems
     *
     * @return the new solver's opaque handle
     * @param comm the communicator that will use the solver
     * @param error an optional reference to a PETSc error code
     * @see <a href="http://www-unix.mcs.anl.gov/petsc/docs/manualpages/SNES/SNESCreate.html"><code>SNESCreate</code></a>
     */
    private native static Opaque local createRaw(Comm comm, int[] local error);
}
