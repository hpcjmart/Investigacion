package petsc;


/**
 * a range of indexes, represented as a half-closed interval.  A
 * <code>Range</code> describes a contiguous subset of a vector or a
 * matrix dimension.  For example, the local subset of a distributed
 * vector is a <code>Range</code>, accessible using {@link Vec#getOwnershipRange(int[])}.
 *
 * Keep in mind that the interval is half-closed: the {@link #end}
 * index is one greater than the last element of the range.
 */

public immutable class Range {

    /** the first element of the range */
    public int start;

    /** one more than the last element of the range */
    public int end;

    /** constructs a degenerate, empty range */
    private Range() {
	this(0, 0);
    }

    /**
     * constructs a range as a half-closed interval
     *
     * @param start the first element of the range
     * @param end one more than the last element of the range
     */
    public Range(int start, int end) {
	this.start = start;
	this.end = end;
    }

    /**
     * produces a printable representation of a range
     *
     * @returns a string describing the range, using interval notation
     */
    public String local toString() {
	return "[" + start + ", " + end + ')';
    }
}
