package petsc;

import java.io.File;
import java.io.FileDescriptor;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;


/**
 * a file output stream that is compatible with the C standard I/O
 * library.  Each instance contains an opaque handle that native code
 * may use as a regular stdio <code>FILE *</code>.  Thus, native and
 * Titanium code may both use the stream without creating multiple-
 * buffer scrambling problems.
 */

final public class StdioOutputStream extends FileOutputStream {

    /**
     * an output stream that is compatible with C's
     * <code>stdout</code> stream
     */
    public static StdioOutputStream local out = new StdioOutputStream(getStandardFile(1));

    /**
     * an output stream that is compatible with C's
     * <code>stderr</code> stream
     */
    public static StdioOutputStream local err = new StdioOutputStream(getStandardFile(2));

    /**
     * an opaque handle on the underlying stdio stream.  This is
     * really a <code>FILE *</code>, and may be used as such by native
     * code.
     */
    private Opaque local handle;

    /**
     * creates a stdio-compatible output file with the specified File
     * object
     *
     * @param file the file to be opened for reading
     * @exception IOException if the file is not found or a
     *                        stdio-compatible stream could not be
     *                        associated with it
     */
    public StdioOutputStream(File file) throws IOException {
	super(file);
	handle = fdopen(getFD());
    }
    
    /**
     * creates a stdio-compatible output file with the specified
     * system dependent file name
     *
     * @param name the system dependent file name 
     * @exception IOException if the file is not found or a
     *                        stdio-compatible stream could not be
     *                        associated with it
     */
    public StdioOutputStream(String name) throws IOException {
	super(name);
	handle = fdopen(getFD());
    }

    /**
     * attaches a stdio-compatible stream to an existing
     * <code>FileDescriptor</code> object
     *
     * @param descriptor the already-open file descriptor
     * @exception IOException if a stdio-compatible stream could not
     *                        be associated with the file descriptor
     */
    public StdioOutputStream(FileDescriptor descriptor) throws IOException {
	super(descriptor);
	handle = fdopen(getFD());
    }

    /**
     * attaches a stdio-compatible stream to an existing opaque file
     * handle
     *
     * @param handle the already-open stdio <code>FILE *</code>, as an
     *               opaque handle
     */
    StdioOutputStream(Opaque local handle) {
	super(getDesc(handle));
	this.handle = handle;
    }

    /**
     * closes the stream, including its underlying <code>FILE
     * *</code>. This method must be called to release any resources
     * associated with the stream.
     *
     * @exception IOException if an I/O error has occurred
     */
    public native void close() throws IOException;

    /**
     * associates a new stdio <code>FILE *</code> with an existing
     * open file descriptor
     *
     * @return the stdio <code>FILE *</code>, as an opaque handle
     * @param desc the already-open file descriptor
     * @exception IOException if an I/O error has occurred
     */
    private static native Opaque local fdopen(FileDescriptor desc) throws IOException;

    /**
     * flushes the stream. This will write any buffered output bytes.
     *
     * @exception IOException If an I/O error has occurred.
     */
    public native void flush() throws IOException;

    /**
     * extracts the raw file descriptor corresponding to an existing
     * stdio <code>FILE *</code> stream
     *
     * @return the underlying file descriptor
     * @param handle the stdio <code>FILE *</code>, as an opaque
     *               handle
     */
    private static native FileDescriptor local getDesc(Opaque local handle);     

    /**
     * retrieves an existing stdio <code>FILE *</code> stream.  This
     * is only used to set up <code>StdioOutputStream</code> instances
     * corresponding to the existing <code>stdout</code> and
     * <code>stderr</code> streams from the C stdio library.
     *
     * @param number 1 for stdout, or 2 for stderr
     */
    private static native Opaque local getStandardFile(int number);

    /**
     * redirects the standard Java output streams, {@link
     * java.lang.System#out} and {@link java.lang.System#err}, through
     * {@link StdioOutputStream#out} and {@link
     * StdioOutputStream#error}.  This lets one use existing Java code
     * unmodified, while still retaining stdio compatibility.
     */
    public static void redirectJavaStreams() {
	System.out.flush();
	System.err.flush();
	System.out = new PrintStream(out);
	System.err = new PrintStream(err);
    }
    
    /**
     * writes a byte of data.  This method will block until the byte
     * is actually written.
     *
     * @param datum the byte to be written
     * @exception IOException if an I/O error has occurred
     */
    public native void write(int datum) throws IOException;
    
    /**
     * writes an array of bytes.  This method will block until the
     * bytes are actually written.
     *
     * @param data the data to be written
     * @exception IOException if an I/O error has occurred
     */
    public void write(byte[] data) throws IOException {
	write(data, 0, data.length);
    }

    /**
     * writes a subarray of bytes
     *
     * @param data the data to be written
     * @param offset the start offset in the data
     * @param length the number of bytes to be written
     * @exception IOException if an I/O error has occurred
     */
    public native void write(byte[] data, int offset, int length) throws IOException;
}
