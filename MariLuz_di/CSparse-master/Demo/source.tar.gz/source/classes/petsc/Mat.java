package petsc;


public final class Mat extends MatBase
{
  /**
   * creates a sequential matrix.
   * @param m the number of rows
   * @param n the number of columns
   * @param nz the number of nonzeros per row
   * @param nnz an array containing the number of nonzeros in each row.
   * This parameter can be null to let PETSc figure it out.
   * @param error an optional reference to a PETSc error code
   * @see <a href="http://www-unix.mcs.anl.gov/petsc/docs/manualpages/Mat/MatCreateSeqAIJ.html">
   */
  public Mat(int m, int n, int nz, int[] local nnz, int[] local error) {
    super(createSeqAIJ(m, n, nz, nnz, error), error);
  }

  /**
   * creates a distributed matrix. without a nonzero element map.
   * @param m the number of local rows, or PETSC_DECIDE if M is given.
   * @param n the number of local columns, or PETSC_DECIDE is N is given.
   * @param M the number of global rows, or PETSC_DETERMINE if m is given.
   * @param N the number of global columns, or PETSC_DETERMINE if n is given.
   * @param d_nz the number of nonzeros per row in the diagonal portion of the
   * local submatrix
   * @param d_nnz array containing the number of nonzeros in the various rows
   * of the diagonal portion of the local submatrix, possibly different for 
   * each row, or null if d_nz is used to specify the nonzero structure. The 
   * size of this array is equal to the number of local rows, i.e 'm'. You 
   * must leave room for the diagonal entry even if it is zero. 
   * @param o_nz the number of nonzeros per row in the off-diagonal portion 
   * of the local submatrix (same value is used for all local rows). 
   * @param o_nnz array containing the number of nonzeros in the various rows 
   * of the off-diagonal portion of the local submatrix (possibly different 
   * for each row) or null, if o_nz is used to specify the nonzero structure. 
   * The size of this array is equal to the number of local rows, i.e 'm'. 
   * @param error an optional reference to a PETSc error code
   * @see <a href="http://www-unix.mcs.anl.gov/petsc/docs/manualpages/Mat/MatCreateMPIAIJ.html">
   */
  public Mat(int m, int n, int M, int N, int d_nz, int[] local d_nnz,
	     int o_nz, int[] local o_nnz, int[] local error) {
    super(createMPIAIJ(m, n, M, N, d_nz, d_nnz, o_nz, o_nnz, error), error);
  }

  /**
   * Loads a matrix that has been stored in binary format with a ViewerBinary. 
   * The matrix format is determined from the options database. Generates a 
   * parallel MPI matrix if the communicator has more than one processor. 
   * The default matrix type is AIJ. 
   * @param Viewer the viewer for the input file
   * @param outtype the type of matrix desired -- MATSEQAIJ, MATMPIAIJ, etc.
   * @param error an optional reference to a PETSc error code
   */
  public Mat(ViewerBinary local v, int outtype, int[] local error) {
    super(load(v, outtype, error), error);
  }

  /**
   * Duplicates an existing matrix. Can either copy the values, or not,
   * depending on the value of the "copyValues" parameter.
   * @param m the matrix to be duplicated.
   * @param copyValues true if the values are to be copied also.
   * @param error an optional reference to a PETSc error code
   * @see <a href="http://www-unix.mcs.anl.gov/petsc/docs/manualpages/Mat/MatDuplicate.html">
   */
  public Mat(Mat local m, boolean copyValues, int[] local error) {
    super(duplicateRaw(m, copyValues, error), error);
  }

  /**
   * constructs a matrix with a given opaque handle
   *
   * @param handle the opaque C representation of the matrix
   */
  Mat(Opaque local handle) {
    super(handle, null);
  }

  private native static Opaque local duplicateRaw(Mat local m, boolean copyValues, int[] local error);

  /**
   * Begins assembling a matrix. This method should be called after 
   * completing all calls to setValues().
   * @param error the assembly type, either Mat.FLUSH_ASSEMBLY or 
   * Mat.FINAL_ASSEMBLY.
   * @param error an optional reference to a PETSc error code
   * @see <a href="http://www-unix.mcs.anl.gov/petsc/docs/manualpages/Mat/MatAssemblyBegin.html">
   */
  public native local void assemblyBegin(int type, int[] local error);

  /**
   * Completes assembling a matrix. This routine should be called after 
   * assemblyBegin().
   * @param error the assembly type, either Mat.FLUSH_ASSEMBLY or 
   * Mat.FINAL_ASSEMBLY.
   * @param error an optional reference to a PETSc error code
   * @see <a href="http://www-unix.mcs.anl.gov/petsc/docs/manualpages/Mat/MatAssemblyEnd.html">
   */
  public native local void assemblyEnd(int type, int[] local error);

  /**
   * Inserts or adds a block of values into a matrix. These values may be 
   * cached, so assemblyBegin() and assemblyEnd() MUST be called 
   * after all calls to setValues() have been completed. 
   * @param m the number of rows
   * @param idxm the global indices of the rows to be updated
   * @param n the number of columns
   * @param idxn the global indices of the columns to be updated
   * @param v a logically two-dimensional array of values
   * @param addv either Mat.ADD_VALUES or Mat.INSERT_VALUES.
   * This determines whether the values will replace (possibly) existing 
   * ones in the matrix, or whether they will be added to them.
   * @param error an optional reference to a PETSc error code
   * @see <a href="http://www-unix.mcs.anl.gov/petsc/docs/manualpages/Mat/MatSetValues.html">
   */
  public native local void setValues(int m, int[] local idxm, int n, 
					   int[] local idxn, double[] local v,
					   int addv, int[] local error);

  /**
   * Set a single entry into a matrix.
   * @param row the row location of the entry
   * @param col the column location of the entry
   * @param value the value to insert
   * @param addv either Mat.ADD_VALUES or Mat.INSERT_VALUES.
   * @param error an optional reference to a PETSc error code
   * This determines whether the value will replace a (possibly) existing
   * one in the matrix, or whether it will be added in.
   */
  public native local void setValue(int row, int col,
					  double value, int addv,
					  int[] local error);

  /**
   * Multiply a matrix by a vector x giving the result y.
   * @param x the multiplier vector
   * @param y the result vector
   * @param error an optional reference to a PETSc error code
   * @see <a href="http://www-unix.mcs.anl.gov/petsc/docs/manualpages/Mat/MatMult.html">
   */
  public native local void mult(Vec local x, Vec local y, int[] local error);

  /**
   * Multiply a matrix by a vector v1, and add the product to a vector v2, 
   * giving the result r.
   * @param v1 the multiplier vector
   * @param v2 the addend vector
   * @param r the result vector
   * @param error an optional reference to a PETSc error code
   * @see <a href="http://www-unix.mcs.anl.gov/petsc/docs/manualpages/Mat/Mat/MatMultAdd.html">
   */
  public native local void multAdd(Vec local v1, Vec local v2,
					 Vec local r, int[] local error);

  /**
   * Multiply the transpose of the matrix by a vector x, giving the result y.
   * @param x the multiplier vector
   * @param y the result vector
   * @param error an optional reference to a PETSc error code
   * @see <a href="http://www-unix.mcs.anl.gov/petsc/docs/manualpages/Mat/Mat/MatMultTrans.html">
   */
  public native local void multTrans(Vec local x, Vec local y, int[] local error);

  /**
   * computes v3 = v2 + this' * v1
   *
   * @param v1 the multiplier vector
   * @param v2 the addend vector
   * @param v3 the result vector
   * @param error an optional reference to a PETSc error code
   * @see <a href="http://www-unix.mcs.anl.gov/petsc/docs/manualpages/Mat/MatMultTransAdd.html"><code>MatMultTransAdd</code></a>
   */
  public local native void multTransAdd(Vec local v1, Vec local v2,
					Vec local v3, int[] local error);
  
  /**
   * Transpose the matrix and return a new matrix.
   * @param error an optional reference to a PETSc error code
   * @see <a href="http://www-unix.mcs.anl.gov/petsc/docs/manualpages/Mat/Mat/MatTranspose.html">
   */
  public local Mat transpose(int[] local error) {
    return new Mat(transposeRaw(error));
    
  }

  /**
   * Transpose the matrix in-place.
   * @param error an optional reference to a PETSc error code 
   * @see <a href="http://www-unix.mcs.anl.gov/petsc/docs/manualpages/Mat/Mat/MatTranspose.html">
   */
  public local void transposeInPlace(int[] local error) {
    transposeRawInPlace(error);
  }

  

  private native local Opaque local transposeRaw(int[] local error);

  private native local void transposeRawInPlace(int[] local error);

  private static native Opaque local load(ViewerBinary local v, int outtype, 
					  int[] local error);

  private static native Opaque local createMPIAIJ(int m, int n, int M, int N, 
						  int d_nz, int[] local d_nnz, 
						  int o_nz, int[] local o_nnz, 
						  int[] local error);

  private static native Opaque local createSeqAIJ(int m, int n, int nz, 
						  int[] local nnz, 
						  int[] local error);
}


// Local variables:
// c-basic-offset: 2
// End:
