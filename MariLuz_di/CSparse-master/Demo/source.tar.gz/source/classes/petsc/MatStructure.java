package petsc;


/**
 * constants that describe changes to matrix structure, such as when
 * {@link Mat#copy copying} or between solver iterations
 */

public interface MatStructure {
    
    /** the locations of nonzeros have not changed */
    static final int SAME_NONZERO_PATTERN = 0;

    /** the locations of nonzeros have changed */
    static final int DIFFERENT_NONZERO_PATTERN = 1;

    /** the preconditioner has not changed */
    static final int SAME_PRECONDITIONER = 2;
}
