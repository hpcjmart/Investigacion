package petsc;

// used by native code, so force code generation
import petsc.PetscError;


/**
 * an ordered collection of communicating Titanium processes.  These
 * loosely correspond to MPI communicators.  Some Titanium-PETSc
 * methods accept a Comm argument to decide how a data structure is to
 * be distributed across multiple processes.
 */

public immutable class Comm {

    /** a communicator containing only the local process */
    static public Comm self;

    /** a communicator containing all Titanium processes */
    static public Comm world;

    /**
     * the raw MPI_Comm object to which this instance corresponds.
     * This is not actually a Titanium Object, but rather is simply a
     * C pointer.  This field can be copied around and assigned, but
     * it must never be used as though it were actually a real Object.
     */
    Opaque local handle;

    /**
     * constructs an invalid, null communicator.  Such a communicator
     * must never be used for any purpose by the native libraries.
     */
    private Comm() { }

    /**
     * constructs a communicator with a given opaque handle.  The
     * handle is the MPI communicator, with C type
     * <code>MPI_Comm</code>.
     *
     * @param handle the opaque C representation of the communicator
     */
    private Comm(Opaque local handle) {
	this.handle = handle;
    }

    /**
     * creates the standard {@link #self} and {@link #world}
     * communicators.  This is called by {@link Petsc#initialize} once
     * the underlying MPI libraries have been initialized.
     */
    static void createStandardComms() {
	self = new Comm(createSelfRaw());
	world = new Comm(createWorldRaw());
    }

    /**
     * creates an opaque communicator handle containing only the local
     * process
     *
     * @return an opaque handle corresponding to PETSC_COMM_SELF
     */
    native private static Opaque local createSelfRaw();


    /**
     * creates an opaque communicator handle containing all Titanium
     * processes
     *
     * @return an opaque handle corresponding to PETSC_COMM_WORLD
     */
    native private static Opaque local createWorldRaw();
}
