package petsc;

/**
 * This is a multigrid preconditioner, a specific subclass of the more general
 * PC class.
 */
public final class MG extends PC
{

  public static final int MULTIPLICATIVE = 0;
  public static final int ADDITIVE = 1;
  public static final int FULL = 2;
  public static final int KASKADE = 3;

  /**
   * An MG is a multigrid preconditioner. 
   * @see http://www-unix.mcs.anl.gov/petsc/docs/manual/manual.html#Node6
   * @see http://www-unix.mcs.anl.gov/petsc/docs/manualpages/PC/PCCreate.html
   */
  public MG(PC local pc) {
    super(pc.handle);
    setType(PC.MG, null);
  }

  /**
   * Sets the number of levels to use with MG. Must be called before any
   * other MG routine.
   * @param levels the number of levels.
   * @param error an optional reference to a PETSc error code
   * @see http://www-unix.mcs.anl.gov/petsc/docs/manualpages/PC/MGSetLevels.html
   */
  public native local void setLevels(int levels, int[] local error);

  /**
   * Sets the MG type. The allowable integer constants are:
   * MG.MULTIPLICATIVE, MG.ADDITIVE, MG.FULL, and MG.KASKADE.
   * @param type the desired type
   * @param error an optional reference to a PETSc error code
   * @see http://www-unix.mcs.anl.gov/petsc/docs/manualpages/PC/setType.html
   */
  public native local void setType(int type, int[] local error);

  /**
   * Gets the solver context to be used on the coarse grid. 
   * @param error an optional reference to a PETSc error code
   * @see http://www-unix.mcs.anl.gov/petsc/docs/manualpages/PC/MGSetLevels.html   
   */
  public native local SLES local getCoarseSolve(int[] local error);
  
  /**
   * Gets the SLES context to be used as smoother for both pre- and 
   * post-smoothing. Call both getSmootherUp() and getSmootherDown() to use 
   * different functions for pre- and post-smoothing. 
   * @param l the level to supply
   * @param error an optional reference to a PETSc error code
   * @see http://www-unix.mcs.anl.gov/petsc/docs/manualpages/PC/MGGetSmoother.html   
   */
  public native local SLES local getSmoother(int l, int[] local error);

  /**
   * Sets the vector space to be used to store the right-hand side on a 
   * particular level. The user should free this space at the conclusion of 
   * multigrid use. 
   * @param l the level this operation is to be performed on
   * @param c the vector space
   * @param error an optional reference to a PETSc error code
   * @see http://www-unix.mcs.anl.gov/petsc/docs/manualpages/PC/MGSetRhs.html
   */
  public native local void setRhs(int l, Vec local c, int[] local error);

  /**
   * Sets the vector space to be used to store the residual on a 
   * particular level. The user should free this space at the conclusion of 
   * multigrid use. 
   * @param l the level this operation is to be performed on
   * @param c the vector space
   * @param error an optional reference to a PETSc error code
   * @see http://www-unix.mcs.anl.gov/petsc/docs/manualpages/PC/MGSetR.html
   */
  public native local void setR(int l, Vec local c, int[] local error);

  /**
   * Sets the function to be used to calculate the residual on the lth level.
   * @param l the level this operation is to be performed on
   * @param c the vector space
   * @param error an optional reference to a PETSc error code
   * @see http://www-unix.mcs.anl.gov/petsc/docs/manualpages/PC/MGSetX.html
   */
  public native local void setResidualDefault(int l, MatBase local c,
					      int[] local error);

  /**
   * Sets the vector space to be used to store the solution on a 
   * particular level. The user should free this space at the conclusion of 
   * multigrid use. 
   * @param l the level this operation is to be performed on
   * @param c the vector space
   * @param error an optional reference to a PETSc error code
   * @see http://www-unix.mcs.anl.gov/petsc/docs/manualpages/PC/MGSetX.html
   */
  public native local void setX(int l, Vec local c, int[] local error);

  /**
   * Sets the function to be used to calculate the interpolation on the lth 
   * level. 
   * @param l the level this operation is to be performed on
   * @param mat the matrix interpolation operator
   * @param error an optional reference to a PETSc error code
   * @see http://www-unix.mcs.anl.gov/petsc/docs/manualpages/PC/MGSetInterpolation.html
   */
  public native local void setInterpolate(int l, MatBase local mat, int[] local error);

  /**
   * Sets the function to be used to restrict a vector from level l to l-1. 
   * @param l the level to supply
   * @param l the restriction matrix
   * @param error an optional reference to a PETSc error code
   * @see http://www-unix.mcs.anl.gov/petsc/docs/manualpages/PC/MGSetRestriction.html
   */
  public native local void setRestriction(int l, MatBase local mat, int[] local error);
}


// Local variables:
// c-basic-offset: 2
// End:
