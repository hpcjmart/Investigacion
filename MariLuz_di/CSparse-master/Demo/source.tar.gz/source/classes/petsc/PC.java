package petsc;

/**
 * The Scalable Linear Equations Solvers (SLES) component provides an
 * easy-to-use interface to the combination of a Krylov subspace
 * iterative method and a preconditioner (in the KSP and PC         
 * components, respectively) or a sequential direct solver. SLES users
 * can set various preconditioning options at runtime via the options
 * database (e.g., -pc_type jacobi ). SLES users can also set PC options
 * directly in application codes by first extracting the PC context from
 * the SLES context via SLESGetPC() and then directly calling the PC
 * routines listed below (e.g., PCSetType() ).
 */
public class PC
    extends PetscObject
{
  public static final String NONE = "none";
  public static final String JACOBI = "jacobi";
  public static final String SOR = "sor";
  public static final String LU = "lu";
  public static final String SHELL = "shell";
  public static final String BJACOBI = "bjacobi";
  public static final String MG = "mg";
  public static final String EISENSTAT = "eisenstat";
  public static final String ILU = "ilu";
  public static final String ICC = "icc";
  public static final String ASM = "asm";
  public static final String SLES = "sles";
  public static final String COMPOSITE = "composite";

  /**
   * A PC is a Preconditioner Context, which is a data structure
   * which tells a solver how to precondition its inputs.
   * This constructor should not be called; a PC comes built-in to a SLES
   * solver and should be extracted instead with getPC().
   * @see http://www-unix.mcs.anl.gov/petsc/docs/manualpages/PC/PCCreate.html
   */
  protected PC(Opaque local opaque) {
    super(opaque);
  }

  protected PC() {
    super(null);
  }

  /**
   * Set the type of the PC. The available string constants are:
   * PC.NONE, PC.JACOBI, PC.SOR, PC.LU, PC.SHELL, PC.BJACOBI,
   * PC.MG, PC.EISENSTAT, PC.ILU, PC.ICC, PC.ASM, PC.SLES, and
   * PC.COMPOSITE.
   * @param type One of the above string constants.
   * @param error an optional reference to a PETSc error code
   * @see http://www-unix.mcs.anl.gov/petsc/docs/manualpages/PC/PCSetType.html
   */
  public local final void setType(String type, int[] local error) {
    setTypeRaw(Util.getBytes(type), error);
  }

  /**
   * Get the type of the PC. The available string constants are:
   * PC.NONE, PC.JACOBI, PC.SOR, PC.LU, PC.SHELL, PC.BJACOBI,
   * PC.MG, PC.EISENSTAT, PC.ILU, PC.ICC, PC.ASM, PC.SLES, and
   * PC.COMPOSITE.
   * @param error an optional reference to a PETSc error code
   */
  public final local native String local getType(int[] local error);

  private local native void setTypeRaw(byte[] local type, int[] local error);

  private local native void getTypeRaw(byte[] local str, int[] local error);
}
