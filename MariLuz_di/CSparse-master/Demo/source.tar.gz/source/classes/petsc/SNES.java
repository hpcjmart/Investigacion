package petsc;


/**
 * The Scalable Nonlinear Equations Solvers (SNES) component provides
 * an easy-to-use interface to Newton-based methods for solving
 * systems of nonlinear equations.  SNES users can set various
 * algorithmic options at runtime via the options database (e.g.,
 * specifying a trust region method via <code>-snes_type tr</code>).
 * SNES internally employs {@link SLES} for the solution of its linear
 * systems.  SNES users can also set SLES options directly in
 * application codes by first extracting the SLES context from the
 * SNES context via {@link #getSLES} and then directly calling various
 * SLES (and {@link KSP} and {@link PC}) routines (e.g., {@link
 * PC#setType}).
 */

/*
 * For the record, I'd just like to state how disappointed I am that
 * SNES here does not stand for Super Nintendo Entertainment System.
 */

public abstract class SNES
    extends PetscObject
    implements MatStructure {

    /** preallocated matrix reference for use in Jacobian callbacks */
    private static final MatBase local[] local A = { null };
    
    /** preallocated matrix reference for use in Jacobian callbacks */
    private static final MatBase local[] local B = { null };
    
    /** preallocated flag reference for use in Jacobian callbacks */
    private static final int[] local flag = { 0 };
    
    /** preallocated error reference for use in Jacobian callbacks */
    private static final int[] local error = { 0 };
    
    /**
     * creates a nonlinear solver context with a given opaque handle
     *
     * @param handle the solver's opaque handle
     * @see <a href="http://www-unix.mcs.anl.gov/petsc/docs/manualpages/SNES/SNESCreate.html"><code>SNESCreate</code></a>
     */
    protected SNES(Opaque local handle) {
	super(handle);
    }

    /**
     * returns the SLES context for a SNES solver
     *
     * @return the SLES context
     * @param error an optional reference to a PETSc error code
     * @see <a href="http://www-unix.mcs.anl.gov/petsc/docs/manualpages/SNES/SNESGetSLES.html"><code>SNESGetSLES</code></a>
     */
    public local final native SLES local getSLES(int[] local error);

    /**
     * the Jacobian evaluation routine for use by the solver
     *
     * @param x the vector at which the function is to be evaluated
     * @param A a reference to the Jacobian matrix.  If appropriate,
     *          the evaluation routine may change this to a completely
     *          new matrix.
     * @param B a reference to the preconditioner matrix, usually the
     *          same as A.  If appropriate, the evaluation routine may
     *          change this to a completely new matrix.
     * @param flag a flag indicating information about the
     *             preconditioner matrix structure.  This must be one
     *             of the constants defined by {@link MatStructure}.
     * @param error an reference to a PETSc error code.  This is
     *              suitable for passing down to any other PETSc
     *              methods that the function may call.
     * @see #setJacobian
     */
    protected abstract local void jacobian(Vec local x,
					   MatBase local[] local A,
					   MatBase local[] local B,
					   int[] local flag,
					   int[] local error);

    /**
     * sets various SNES and SLES parameters from user options
     *
     * @param error an optional reference to a PETSc error code
     * @see <a href="http://www-unix.mcs.anl.gov/petsc/docs/manualpages/SNES/SNESSetFromOptions.html"><code>SNESSetFromOptions</code></a>
     */
    public local final native void setFromOptions(int[] local error);

    /**
     * sets the function to compute Jacobian as well as the location
     * to store the matrix.  The routine that actually does the
     * computation is not set here; rather, application developer
     * should subclass <code>SNES</code> and implement the {@link
     * #jacobian} method in that subclass.
     *
     * @param A the Jacobian matrix
     * @param B the preconditioner matrix (usually the same as the Jacobian)
     * @param error an optional reference to a PETSc error code
     * @see <a href="http://www-unix.mcs.anl.gov/petsc/docs/manualpages/SNES/SNESSetJacobian.html"><code>SNESSetJacobian</code></a>
     */
    public local final native void setJacobian(MatBase local A, MatBase local B, int[] local error);

    /**
     * solves a nonlinear system
     *
     * @return the number of iterations until termination
     * @param x the solution vector
     * @param error an optional reference to a PETSc error code
     * @see <a href="http://www-unix.mcs.anl.gov/petsc/docs/manualpages/SNES/SNESSolve.html"><code>SNESSolve</code></a>
     */
    public local final native int solve(Vec local x, int[] local error);
}
