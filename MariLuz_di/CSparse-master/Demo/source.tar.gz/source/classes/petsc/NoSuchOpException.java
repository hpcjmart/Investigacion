package petsc;


public final class NoSuchOpException extends RuntimeException {

    /** the matrix shell from which the operation was missing */
    public final MatShell local matrix;

    /**
     * constructs a no-such-operator exception object, to report that
     * a matrix shell did not implement some required operation
     *
     * @param matrix the matrix shell on which the operation was to be
     *               performed
     * @param operation the name of the missing operation
     */
    NoSuchOpException(MatShell local matrix, String local operation) {
	super(operation);
	this.matrix = matrix;
    }
}
