package petsc;


/** viewers that represent objects as human-readable ASCII text */

final public class ViewerASCII extends Viewer {

    /** default format */
    public static final int FORMAT_DEFAULT = 0;
    
    /** Matlab format */
    public static final int FORMAT_MATLAB = 1;
    
    /**
     * implementation-specific format.  In many cases this is the same
     * as default.
     */
    public static final int FORMAT_IMPL = 2;
    
    /** basic information about object */
    public static final int FORMAT_INFO = 3;
    
    /** more detailed info about object */
    public static final int FORMAT_INFO_LONG = 4;
    
    /** identical output format for all objects of a particular type */
    public static final int FORMAT_COMMON = 5;

    /*
     * ??? Documentation needed ... what does this do?  Apparently
     * only used to print AIJ matrixes.
     */
    public static final int FORMAT_SYMMODU = 6;

    /**
     * opens an ASCII file as a viewer with the specified File object
     *
     * @param comm the communicator
     * @param file the file name to be opened
     * @param error an optional reference to a PETSc error code
     * @see <a href="http://www-unix.mcs.anl.gov/petsc/docs/manualpages/Viewer/ViewerASCIIOpen.html"><code>ViewerASCIIOpen</code></a>
     */
    public ViewerASCII(Comm comm, java.io.File file, int[] local error) {
	this(comm, file.getPath(), error);
    }

    /**
     * opens an ASCII file as a viewer with the specified system
     * dependent file name
     *
     * @param comm the communicator
     * @param name the system dependent file name 
     * @param error an optional reference to a PETSc error code
     * @see <a href="http://www-unix.mcs.anl.gov/petsc/docs/manualpages/Viewer/ViewerASCIIOpen.html"><code>ViewerASCIIOpen</code></a>
     */
    public ViewerASCII(Comm comm, String name, int[] local error) {
	super(openRaw(comm, Util.getBytes(name), error));
    }

    /**
     * extracts the file stream from an ASCII viewer
     *
     * @return the viewer's file output stream
     * @param error an optional reference to a PETSc error code
     * @see <a href="http://www-unix.mcs.anl.gov/petsc/docs/manualpages/Viewer/ViewerASCIIGetPointer.html"><code>ViewerASCIIGetPointer</code></a>
     */
    public local StdioOutputStream local getFile(int[] local error) {
	return new StdioOutputStream(getFileRaw(error));
    }

    /**
     * extracts the file stream from an ASCII viewer
     *
     * @return the viewer's file output stream's opaque handle
     * @param error an optional reference to a PETSc error code
     */
    private native local Opaque local getFileRaw(int[] local error);

    /**
     * opens a predefined stream as a viewer
     *
     * @param comm the communicator
     * @param number 1 for stdout, or 2 for stderr
     */
    private ViewerASCII(Comm comm, int number) {
	super(openRaw(comm, number));
    }

    /**
     * opens an ASCII file as a viewer
     *
     * @return the viewer's opaque handle
     * @param comm the communicator
     * @param name the system dependent file name 
     * @param error an optional reference to a PETSc error code
     */
    private native static Opaque local openRaw(Comm comm, byte[] local name, int[] local error);
    
    /**
     * opens a predefined stream as a viewer
     *
     * @return the viewer's opaque handle
     * @param comm the communicator
     * @param number 1 for stdout, or 2 for stderr
     */
    private native static Opaque local openRaw(Comm comm, int number);
    
    /**
     * creates an ASCII viewer shared by all processes in a
     * communicator, linked to the standard error stream
     *
     * @return a standard error viewer
     */
    public static ViewerASCII local err(Comm comm) {
	return new ViewerASCII(comm, 2);
    }

    /**
     * creates an ASCII viewer shared by all processes in a
     * communicator, linked to the standard output stream
     *
     * @return a standard output viewer
     */
    public static ViewerASCII local out(Comm comm) {
	return new ViewerASCII(comm, 1);
    }
}
