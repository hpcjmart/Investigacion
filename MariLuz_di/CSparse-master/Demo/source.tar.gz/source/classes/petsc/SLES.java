package petsc;


/**
 * The Scalable Linear Equations Solvers (SLES) component provides an
 * easy-to-use interface to the combination of a Krylov subspace
 * iterative method and a preconditioner (in the {@link KSP} and
 * {@link PC} components, respectively) or a sequential direct solver.
 * SLES users can set various Krylov and preconditioning options at
 * runtime via the options database (e.g., <code>-pc_type jacobi
 * -ksp_type gmres</code>).  SLES users can also set KSP and PC
 * options directly in application codes by first extracting the KSP
 * and/or PC context from the SLES context via {@link
 * SLES#getKSP}/{@link SLES#getPC} and then directly calling the KSP
 * and PC routines (e.g., {@link KSP#setType}/{@link PC#setType}).
 * Both KSP and PC components can be used directly to create and
 * destroy solvers; this is not needed for users but is intended for
 * library developers.
 */

final public class SLES extends PetscObject {

    /**
     * constructs an SLES context with a given opaque handle
     *
     * @param handle the opaque C representation of the solver
     */
    SLES(Opaque local handle) {
	super(handle);
    }

    /**
     * returns the {@link PC preconditioner context} for a SLES solver
     *
     * @return the preconditioner context
     * @param error an optional reference to a PETSc error code
     * @see <a href="http://www-unix.mcs.anl.gov/petsc/docs/manualpages/SLES/SLESGetPC.html"><code>SLESGetPC</code></a>
     */
    public native local PC local getPC(int[] local error);

    /**
     * sets various SLES parameters from user options.  Also takes all
     * {@link KSP} and {@link PC} options.
     *
     * @param error an optional reference to a PETSc error code
     * @see <a href="http://www-unix.mcs.anl.gov/petsc/docs/manualpages/SLES/SLESSetFromOptions.html"><code>SLESSetFromOptions</code></a>
     */
    public native local void setFromOptions(int[] local error);

    /**
     * sets the matrix associated with the linear system and a
     * (possibly) different one associated with the preconditioner.
     * The <code>flag</code> parameter must be selected from among the
     * constants defined in {@link MatStructure}.
     *
     * @param Amat the matrix associated with the linear system
     * @param Pmat the matrix to be used in constructing the
     *             preconditioner.  This is usually the same as Amat.
     * @param flag flag indicating information about the
     *             preconditioner matrix structure during successive
     *             linear solves. This flag is ignored the first time
     *             a linear system is solved, and thus is irrelevant
     *             when solving just one linear system.
     * @param error an optional reference to a PETSc error code
     * @see <a href="http://www-unix.mcs.anl.gov/petsc/docs/manualpages/SLES/SLESSetOperators.html"><code>SLESSetOperators</code></a>
     */
    public native local void setOperators(MatBase local Amat, MatBase local Pmat,
					  int flag, int[] local error);

    /**
     * sets the prefix used for searching for all SLES options in the
     * database
     *
     * @param prefix the prefix to prepend to all option names
     * @param error an optional reference to a PETSc error code
     * @see <a href="http://www-unix.mcs.anl.gov/petsc/docs/manualpages/SLES/SLESSetOptionsPrefix.html"><code>SLESSetOptionsPrefix</code></a>
     */
    public local void setOptionsPrefix(String prefix, int[] local error) {
	setOptionsPrefixRaw(Util.getBytes(prefix), error);
    }

    /**
     * sets the prefix used for searching for all SLES options in the
     * database
     *
     * @param prefix the prefix to prepend to all option names
     * @param error an optional reference to a PETSc error code
     * @see <a href="http://www-unix.mcs.anl.gov/petsc/docs/manualpages/SLES/SLESSetOptionsPrefix.html"><code>SLESSetOptionsPrefix</code></a>
     */
    private native local void setOptionsPrefixRaw(byte[] local prefix, int[] local error);
}
