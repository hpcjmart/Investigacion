package petsc;


public class MatShell extends MatBase {
    
    /**
     * creates a new matrix for use with a user-defined private data
     * storage format
     *
     * @param comm comm the communicator that will use the matrix
     * @param m number of local rows (must be given)
     * @param n number of local columns (must be given)
     * @param M number of global rows (may be {@link #PETSC_DETERMINE})
     * @param N number of global rows (may be {@link #PETSC_DETERMINE})
     * @param error an optional reference to a PETSc error code
     * @see <a href="http://www-unix.mcs.anl.gov/petsc/docs/manualpages/Mat/MatCreateShell.html">
     */
    public MatShell(Comm comm, int m, int n, int M, int N, int[] local error) {
	super(createRaw(comm, m, n, M, N, error), error);
    }

    /**
     * creates a new matrix for use with a user-defined private data
     * storage format
     *
     * @return the new matrix shell's opaque handle
     * @param comm comm the communicator that will use the matrix
     * @param m number of local rows (must be given)
     * @param n number of local columns (must be given)
     * @param M number of global rows (may be {@link #PETSC_DETERMINE})
     * @param N number of global rows (may be {@link #PETSC_DETERMINE})
     * @param error an optional reference to a PETSc error code
     * @see <a href="http://www-unix.mcs.anl.gov/petsc/docs/manualpages/Mat/MatCreateShell.html">
     */
    private local native Opaque local createRaw(Comm comm, int m, int n,
						int M, int N, int[] local error);

    /**
     * multiply a matrix by a vector x giving the result y
     *
     * @param x the multiplier vector
     * @param y the result vector
     * @param error an optional reference to a PETSc error code
     * @see <a href="http://www-unix.mcs.anl.gov/petsc/docs/manualpages/Mat/MatMult.html">
     */
    public local void mult(Vec local x, Vec local y, int[] local error) {
	throw new NoSuchOpException(this, "mult");
    }
    
    /**
     * computes v3 = v2 + this' * v1
     *
     * @param v1 the multiplier vector
     * @param v2 the addend vector
     * @param v3 the result vector
     * @param error an optional reference to a PETSc error code
     * @see <a href="http://www-unix.mcs.anl.gov/petsc/docs/manualpages/Mat/MatMultTransAdd.html"><code>MatMultTransAdd</code></a>
     */
    public local void multTransAdd(Vec local v1, Vec local v2,
				   Vec local v3, int[] local error) {
	throw new NoSuchOpException(this, "multTransAdd");
    }

    /**
     * a preallocated error reference, used for matrix shell operation
     * upcalls
     */    
    private static final int[] local error = { 0 };
}
