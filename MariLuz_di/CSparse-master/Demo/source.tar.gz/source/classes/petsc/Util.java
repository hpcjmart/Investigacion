package petsc;


/** internal utility routines that don't belong anywhere else */

abstract class Util {

    /**
     * converts a Java string into a null-terminated array of bytes.
     * This is used internally to extract raw ASCII data suitable for
     * use with traditional C routines.
     *
     * @return a newly-allocated array of ASCII bytes, or
     *         <code>null</code> if <code>string</code> is null
     * @param string the string to be converted
     */     
    static byte[] local getBytes(String string) {
	if (string == null)
	    return null;
	else {
	    int length = string.length();
	    byte[] local bytes = new byte[length + 1];

	    string.getBytes(0, length, bytes, 0);
	    bytes[length] = 0;
	    return bytes;
	}
    }
}
