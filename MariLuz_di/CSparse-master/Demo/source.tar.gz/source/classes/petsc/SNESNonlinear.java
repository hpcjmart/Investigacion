package petsc;


/** SNES solvers for systems of nonlinear equations */

public abstract class SNESNonlinear extends SNES {

    /**
     * creates a solver for systems of nonlinear equations
     *
     * @param comm the communicator that will use the solver
     * @param error an optional reference to a PETSc error code
     * @see <a href="http://www-unix.mcs.anl.gov/petsc/docs/manualpages/SNES/SNESCreate.html"><code>SNESCreate</code></a>
     */
    protected SNESNonlinear(Comm comm, int[] local error) {
	super(createRaw(comm, error));
    }

    /**
     * creates a solver for systems of nonlinear equations with a
     * given opaque handle
     *
     * @param handle the solver's opaque handle
     * @see <a href="http://www-unix.mcs.anl.gov/petsc/docs/manualpages/SNES/SNESCreate.html"><code>SNESCreate</code></a>
     */
    SNESNonlinear(Opaque local handle) {
	super(handle);
    }

    /**
     * creates a solver for systems of nonlinear equations
     *
     * @return the new solver's opaque handle
     * @param comm the communicator that will use the solver
     * @param error an optional reference to a PETSc error code
     * @see <a href="http://www-unix.mcs.anl.gov/petsc/docs/manualpages/SNES/SNESCreate.html"><code>SNESCreate</code></a>
     */
    private static native Opaque local createRaw(Comm comm, int[] local error);

    /**
     * the function evaluation routine for use by the solver
     *
     * @param x the vector at which the function is to be evaluated
     * @param f the vector into which the function value is to be placed
     * @param error an reference to a PETSc error code.  This is
     *              suitable for passing down to any other PETSc
     *              methods that the function may call.
     * @see #setFunction
     */
    protected abstract local void function(Vec local x,
					   Vec local f,
					   int[] local error);

    /**
     * sets the function evaluation routine and function vector for
     * use by the {@link SNES} routines in solving systems of
     * nonlinear equations.  The routine that actually does the
     * computation is not set here; rather, application developer
     * should subclass <code>SNESNonlinear</code> and implement the
     * {@link #function} method in that subclass.
     *
     * @param r vector to store function value
     * @param error an optional reference to a PETSc error code
     * @see <a href="http://www-unix.mcs.anl.gov/petsc/docs/manualpages/SNES/SNESSetFunction.html"><code>SNESSetFunction</code></a>
     */
    public local final native void setFunction(Vec local r, int[] local error);

    private static final int[] local error = { 0 };
}
