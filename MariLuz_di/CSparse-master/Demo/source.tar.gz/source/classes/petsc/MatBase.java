package petsc;


public abstract class MatBase
    extends PetscObject
    implements Constants, InsertMode, MatType, NormType
{
  /**
   * The size of the local portion of the matrix in rows and columns.
   */
  public int m = -1, n = -1;

  /**
   * The size of the global matrix in rows and columns.
   */
  public int M = -1, N = -1;

  /**
   * Constants used for matrix assembly.
   */
  public static final int FLUSH_ASSEMBLY = 1;
  public static final int FINAL_ASSEMBLY = 0;

  /**
   * constructs a matrix with a given opaque handle
   *
   * @param handle the opaque C representation of the matrix
   * @param error an optional reference to a PETSc error code
   */
  MatBase(Opaque local handle, int[] local error) {
    super(handle);
    getSize(error);
  }

  /**
   * Gets the size of a matrix. Places it into {@link #m} and {@link
   * #n}. This method should be called inside all the constructors, so
   * the user should not have to do it.
   */
  private native local void getSize(int[] local error);
  
  /**
   * multiply a matrix by a vector x giving the result y
   *
   * @param x the multiplier vector
   * @param y the result vector
   * @param error an optional reference to a PETSc error code
   * @see <a href="http://www-unix.mcs.anl.gov/petsc/docs/manualpages/Mat/MatMult.html">
   */
  public local abstract void mult(Vec local x, Vec local y, int[] local error);
  
  /**
   * computes v3 = v2 + this' * v1
   *
   * @param v1 the multiplier vector
   * @param v2 the addend vector
   * @param v3 the result vector
   * @param error an optional reference to a PETSc error code
   * @see <a href="http://www-unix.mcs.anl.gov/petsc/docs/manualpages/Mat/MatMultTransAdd.html"><code>MatMultTransAdd</code></a>
   */
  public local abstract void multTransAdd(Vec local v1, Vec local v2,
					  Vec local v3, int[] local error);
}


// Local variables:
// c-basic-offset: 2
// End:
