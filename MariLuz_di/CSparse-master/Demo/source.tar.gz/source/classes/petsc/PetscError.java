package petsc;

/**
 * A collection of interfaces for managing PETSc errors.
 *
 * The last parameter to most Titanium-PETSc methods is an optional
 * array of <code>int</code>.  If a PETSc error occurs, and this array
 * is non-<code>null</code>, element zero of the array will be set to
 * the corresponding PETSc error code.  In this way, Titanium-PETSc
 * resembles the Fortran API's error reporting approach.
 *
 * It can be tedious to always check for a returned error, though.
 * Therefore, if the <code>error</code> parameter is null, the error
 * will be checked automatically instead of being passed back to the
 * caller.  Most programmers, then, will almost always want to pass
 * <code>null</code> to get complete error checking with minimal
 * hassle.  Only when a particular action requires special error
 * handling should the method be called with a non-<code>null</code>
 * array; generally this will be an array of just a single element.
 *
 * When Titanium-PETSc checks automatically, it needs to know what to
 * do when an error does occur.  The action to take is determined by
 * the current global error policy, which may be queried or changed
 * using methods in this class; available policies include
 * <code>{@link #POLICY_ABORT aborting}</code> the program,
 * <code>{@link #POLICY_IGNORE ignoring}</code> the error, and
 * <code>{@link #POLICY_THROW throwing}</code> an exception.  Throwing
 * an exception is the default unless changed by the program.
 *
 * These policies are <em>only</em> used when the error code has not
 * been passed back to the caller.  If a method was invoked with a
 * non-<code>null</code> error code array, then the caller is
 * responsible for checking the returned code and handling any error
 * appropriately.
 */

final public class PetscError {
  
    /**
     * the policy of aborting the program following an error.  When an
     * automatically-checked PETSc error occurs, and the corresponding
     * error policy is <code>POLICY_ABORT</code>, the running program
     * will be terminated.  The exit status of the program will be the
     * nonzero PETSc error code.
     */
    public static final int POLICY_ABORT = 0;

    /**
     * the policy of ignoring errors.  When an automatically-checked
     * PETSc error occurs, and the corresponding error policy is
     * <code>POLICY_IGNORE</code>, the error will be disregarded and
     * the program will continue to run.
     */
    public static final int POLICY_IGNORE = 1;

    /**
     * the policy of throwing an exception following an error.  When
     * an automatically-checked PETSc error occurs, and the
     * corresponding error policy is <code>POLICY_THROW</code>, a
     * <code>{@link PetscException}</code> will be thrown.  The
     * specific error code is available as the <code>{@link
     * PetscException#code}</code> field of the thrown exception.
     *
     * This is the default policy unless changed by the program.
     */
    static public final int POLICY_THROW = 2;

    /**
     * the current error handling policy.  This policy governs
     * treatment of all PETSc errors that arise but are not passed
     * back to the method's caller.
     */
    static private int errorPolicy = POLICY_THROW;

    /**
     * gets the automatically-checked error handling policy
     *
     * @return the current policy.  This will be one of the
     *         <code>POLICY_*</code> policy constants defined above.
     * @see #POLICY_ABORT
     * @see #POLICY_IGNORE
     * @see #POLICY_THROW
     */
    public static int getErrorPolicy() {
	return errorPolicy;
    }

    /**
     * sets the automatically-checked error handling policy
     *
     * @param policy the new policy.  This must be one of the
     *               <code>POLICY_*</code> policy constants defined
     *               above.
     * @see #POLICY_ABORT
     * @see #POLICY_IGNORE
     * @see #POLICY_THROW
     */
    public static void setErrorPolicy(int policy) {
	switch (policy) {
	case POLICY_ABORT:
	case POLICY_IGNORE:
	case POLICY_THROW:
	    errorPolicy = policy;
	    break;
	default:
	    throw new IllegalArgumentException("no such error policy: " + policy);
	}
    }

    /**
     * checks for an error.  If an error did occur, and the error
     * return array is non-<code>null</code>, the error code will be
     * placed in element zero of the array.  Otherwise, if the error
     * return array is <code>null</code>, the error will will be
     * handled using the current error handling policy.
     *
     * @param errorCode the error code returned by a PETSc call
     * @param errorReturn an optional reference for error returns
     * @see #setErrorPolicy
     */
    static void check(int errorCode, int[] local errorReturn) {
	if (errorCode != 0)
	    if (errorReturn != null)
		errorReturn[0] = errorCode;
	    else
		switch (errorPolicy) {
		case POLICY_ABORT:
		    System.exit(errorCode);
		    break;
		case POLICY_THROW:
		    throw new PetscException(errorCode);
		}
    }
}
