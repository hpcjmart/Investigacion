package petsc;


/**
 * constants that describe ways to compute normals.  The
 * <code>NORM_1_AND_2</code> normal type used in the C and Fortran is
 * not available.  If you wish to compute both <code>NORM_1</code> and
 * <code>NORM_2</code> of a vector, call {@link Vec#norm1and2}.
 */

public interface NormType {

    /** computes the sum of magnitudes */
    static final int NORM_1 = 1;

    /** computes the root of the sum of squares */
    static final int NORM_2 = 2;

    /** computes the Frobenius norm, for matrixes only */
    static final int NORM_FROBENIUS = 3;

    /** computes the greatest magnitude */
    static final int NORM_INFINITY = 4;
}
