package petsc;

/**
 * Viewers that represent objects in binary form. This format is not 
 * human-readable, but it is the only format that can be used to load 
 * PETSc objects off disk. ASCII viewers are output-only.
 */

final public class ViewerBinary extends Viewer {

    /* default format */
    static final int FORMAT_DEFAULT = 9;

    /**
     * store the object to the binary file in its native format.  For
     * example, dense matrices are stored as dense.
     */
    static final int FORMAT_NATIVE = 10;
    
    public static final int BINARY_RDONLY = 0;
    public static final int BINARY_WRONLY = 1;
    public static final int BINARY_CREATE = 2;

    /**
     * opens a binary file as a viewer with the specified File object
     *
     * @param comm the communicator
     * @param file the file name to be opened
     * @param type the viewer binary type
     * @param error an optional reference to a PETSc error code
     * @see <a href="http://www-unix.mcs.anl.gov/petsc/docs/manualpages/Viewer/ViewerBinaryOpen.html"><code>ViewerBinaryOpen</code></a>
     */
    public ViewerBinary(Comm comm, java.io.File file, int type, int[] local error) 
    {
	this(comm, file.getPath(), type, error);
    }

    /**
     * opens a binary file as a viewer with the specified system
     * dependent file name
     *
     * @param comm the communicator
     * @param name the system dependent file name to be opened
     * @param type the viewer binary type
     * @param error an optional reference to a PETSc error code
     * @see <a href="http://www-unix.mcs.anl.gov/petsc/docs/manualpages/Viewer/ViewerBinaryOpen.html"><code>ViewerBinaryOpen</code></a>
     */
    public ViewerBinary(Comm comm, String name, int type, int[] local error) 
    {
	super(open(comm, Util.getBytes(name), type, error));
    }

    /**
     * extracts the file descriptor from a viewer
     *
     * @return the viewer's underlying file descriptor
     * @param error an optional reference to a PETSc error code
     * @see <a href="http://www-unix.mcs.anl.gov/petsc/docs/manualpages/Viewer/ViewerBinaryGetDescriptor.html"><code>ViewerBinaryGetDescriptor</code></a>
     */
    public native local java.io.FileDescriptor local getDescriptor(int[] local error);

    /**
     * opens an binary file as a viewer
     *
     * @return the viewer's opaque handle
     * @param comm the communicator
     * @param bytes the file name
     * @param type the viewer binary type
     * @param error an optional reference to a PETSc error code
     */
    native private static Opaque local open(Comm comm, byte[] local bytes, 
					    int type, int[] local error);
}
