package petsc;

import java.io.File;


/**
 * viewers that represent objects by drawing pictures of them in
 * windows
 */

final public class ViewerDraw extends Viewer {

    /**
     * creates a window viewer shared by all processes in a communicator
     *
     * @param comm communicator that will share the window 
     * @see <a href="http://www-unix.mcs.anl.gov/petsc/docs/manualpages/Viewer/VIEWER_DRAW_.html"><code>VIEWER_DRAW_</code></a>
     */
    public ViewerDraw(Comm comm)
    {
	super(openRaw(comm));
    }

    /**
     * opens an X window for use as a viewer
     *
     * @param comm communicator that will share the window 
     * @param display the X display on which to open, or <code>null</code> for the local machine 
     * @param title the title to put in the title bar, or <code>null</code> for no title 
     * @param x the screen coordinate of the left edge of the window 
     * @param x the screen coordinate of the top edge of the window 
     * @param w the window width in pixels
     * @param h the window height in pixels
     * @param error an optional reference to a PETSc error code
     * @see <a href="http://www-unix.mcs.anl.gov/petsc/docs/manualpages/Viewer/ViewerDrawOpen.html"><code>ViewerDrawOpen</code></a>
     */
    public ViewerDraw(Comm comm, String display, String title,
		      int x, int y, int w, int h, int[] local error)
    {
	super(openXRaw(comm,
		       Util.getBytes(display),
		       Util.getBytes(title),
		       x, y, w, h, error));
    }

    /**
     * opens a VRML file viewer with the specified File object
     *
     * @param comm communicator that will share viewer
     * @param file the filename to open, or <code>null</code> for stdout
     * @param error an optional reference to a PETSc error code
     */
    public ViewerDraw(Comm comm, File file, int[] local error) {
	this(comm, file == null ? file.getPath() : null, error);
    }

    /**
     * opens a VRML file viewer with the specified system dependent
     * file name
     *
     * @param comm communicator that will share viewer
     * @param name the filename to open, or <code>null</code> for stdout
     * @param error an optional reference to a PETSc error code
     */
    public ViewerDraw(Comm comm, String file, int[] local error) {
	super(openVRMLRaw(comm, Util.getBytes(file), error));
    }

    /**
     * creates a window viewer shared by all processes in a communicator
     *
     * @param comm communicator that will share the window 
     * @see <a href="http://www-unix.mcs.anl.gov/petsc/docs/manualpages/Viewer/VIEWER_DRAW_.html"><code>VIEWER_DRAW_</code></a>
     */
    private static native Opaque local openRaw(Comm comm);

    /**
     * opens an X window for use as a viewer
     *
     * @return the viewer's opaque handle
     * @param comm communicator that will share the window 
     * @param display the X display on which to open, or <code>null</code> for the local machine 
     * @param title the title to put in the title bar, or <code>null</code> for no title 
     * @param x the screen coordinate of the left edge of the window 
     * @param x the screen coordinate of the top edge of the window 
     * @param w the window width in pixels
     * @param h the window height in pixels
     * @param error an optional reference to a PETSc error code
     */
    private static native Opaque local openXRaw(Comm comm,
						byte[] local display,
						byte[] local title,
						int x, int y, int w, int h,
						int[] local error);

    /**
     * opens a VRML file viewer
     *
     * @return the viewer's opaque handle
     * @param comm communicator that will share viewer
     * @param name the filename to open, or <code>null</code> for stdout
     * @param error an optional reference to a PETSc error code
     */
    private static native Opaque local openVRMLRaw(Comm comm, byte[] local file,
						   int[] local error);
}
