package petsc;


/**
 * a variety of methods for profiling applications that use the PETSc
 * libraries
 */

public abstract class PLog {

    /**
     * adds floating point operations to the global counter
     *
     * @param f flop counter
     * @see <a href="http://www-unix.mcs.anl.gov/petsc/docs/manualpages/Profiling/PLogFlops.html"><code>PLogFlops</code></a>
     */
    public static native void flops(int f);
}
