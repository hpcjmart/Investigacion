package petsc;


final public class PetscException extends RuntimeException {

    /** The error code returned by the native library. */
    public final int code;

    /**
     * Constructs a PETSc exception object for a given error code.
     *
     * @param code error code returned by the native library
     */
    PetscException( int code ) {
	this.code = code;
    }
}
