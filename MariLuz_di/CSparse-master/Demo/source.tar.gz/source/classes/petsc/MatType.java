package petsc;


/**
 * constants that describe matrix data storage formats
 */

public interface MatType {    
    public static final int MATSAME = -1;
    public static final int MATSEQDENSE = 0;
    public static final int MATSEQAIJ = 1;
    public static final int MATMPIAIJ = 2;
    public static final int MATSHELL = 3;
    public static final int MATMPIROWBS = 4;
    public static final int MATSEQBDIAG = 5;
    public static final int MATMPIBDIAG = 6;
    public static final int MATMPIDENSE = 7;
    public static final int MATSEQBAIJ = 8;
    public static final int MATMPIBAIJ = 9;
    public static final int MATMPICSN = 10;
    public static final int MATSEQCSN = 11;
    public static final int MATSEQADJ = 12;
    public static final int MATMPIADJ = 13;
}
