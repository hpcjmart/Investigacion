package petsc;

// used by native code, so force code generation
import petsc.PetscError;


/** random number generators */
final public class PetscRandom extends PetscObject {

    /**
     * creates a context for generating random numbers, and
     * initializes the random-number generator
     *
     * @param comm the communicator that will use the generator
     * @param error an optional reference to a PETSc error code
     * @see <a href="http://www-unix.mcs.anl.gov/petsc/docs/manualpages/Sys/PetscRandomCreate.html"><code>PetscRandomCreate</code></a>
    */
    public PetscRandom(Comm comm, int[] local error) {
	super(createRaw(comm, error));
    }

    /**
     * creates a context for generating random numbers, and
     * initializes the random-number generator
     *
     * @return the generator's opaque handle
     * @param comm the communicator that will use the generator
     * @param error an optional reference to a PETSc error code
     * @see <a href="http://www-unix.mcs.anl.gov/petsc/docs/manualpages/Sys/PetscRandomCreate.html"><code>PetscRandomCreate</code></a>
    */
    private native static Opaque local createRaw(Comm comm, int[] local error);
}
