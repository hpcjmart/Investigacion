package petsc;

// used by native code, so force code generation
import petsc.PetscError;


/**
 * a persistent mapping between elements of two vectors, which
 * provides the context for one or more vector scatter operations
 */

final public class VecScatter
    extends PetscObject
    implements InsertMode, ScatterMode {
    
    /**
     * creates a vector scatter context
     *
     * @param xin a vector that defines the shape (parallel data layout of the vector) of vectors from which we scatter
     * @param yin a vector that defines the shape (parallel data layout of the vector) of vectors to which we scatter
     * @param ix the indices of <code>xin</code> to scatter
     * @param iy the indices of <code>yin</code> to hold results
     * @param error an optional reference to a PETSc error code
     * @see <a href="http://www-unix.mcs.anl.gov/petsc/docs/manualpages/Vec/VecScatterCreate.html"><code>VecScatterCreate</code></a>
     */
    public VecScatter(Vec local xin, IS local ix,
		      Vec local yin, IS local iy,
		      int[] local error) {
	super(createRaw(xin, ix, yin, iy, error));
    }

    /**
     * begins a generalized scatter from one vector to another.
     * Complete the scattering phase with {@link #end}.
     *
     * @param x the vector from which we scatter
     * @param y the vector to which we scatter
     * @param addv either {@link #ADD_VALUES} or {@link #INSERT_VALUES}
     * @param mode the scattering mode, usually {@link #SCATTER_FORWARD}
     * @param error an optional reference to a PETSc error code
     * @see <a href="http://www-unix.mcs.anl.gov/petsc/docs/manualpages/Vec/VecScatterBegin.html"><code>VecScatterBegin</code></a>
     */
    public native local void begin(Vec local x, Vec local y, int addv, int mode, int[] local error);
	
    /**
     * creates a vector scatter context
     *
     * @return the new scatter context's opaque handle
     * @param xin a vector that defines the shape (parallel data layout of the vector) of vectors from which we scatter
     * @param yin a vector that defines the shape (parallel data layout of the vector) of vectors to which we scatter
     * @param ix the indices of <code>xin</code> to scatter
     * @param iy the indices of <code>yin</code> to hold results
     * @param error an optional reference to a PETSc error code
     * @see <a href="http://www-unix.mcs.anl.gov/petsc/docs/manualpages/Vec/VecScatterCreate.html"><code>VecScatterCreate</code></a>
     */
    private native static Opaque local createRaw(Vec local xin, IS local ix,
						 Vec local yin, IS local iy,
						 int[] local error);
    
    /**
     * ends a generalized scatter from one vector to another.  Call
     * after first calling {@link #begin}.
     *
     * @param x the vector from which we scatter
     * @param y the vector to which we scatter
     * @param addv either {@link #ADD_VALUES} or {@link #INSERT_VALUES}
     * @param mode the scattering mode, usually {@link #SCATTER_FORWARD}
     * @param error an optional reference to a PETSc error code
     * @see <a href="http://www-unix.mcs.anl.gov/petsc/docs/manualpages/Vec/VecScatterEnd.html"><code>VecScatterEnd</code></a>
     */
    public native local void end(Vec local x, Vec local y, int addv, int mode, int[] local error);
}
