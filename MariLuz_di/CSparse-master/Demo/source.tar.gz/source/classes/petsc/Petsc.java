package petsc;

// used by native code, so force code generation
import petsc.PetscError;


/**
 * a collection of methods for managing the PETSc system as a whole.
 * At present, this includes methods for initializing PETSc before use
 * and finalizing PETSc when the program's work is done.
 */

final public class Petsc {

    /**
     * initializes the PETsc database and MPI.  Initialization should
     * always happen exactly once, near the beginning of the program.
     * Each process must either create a <code>Petsc</code> instance
     * or call <code>{@link #initialize(String[], String,
     * String)}</code>.  If a <code>Petsc</code> instance is created,
     * it must later be destroyed by a call to <code>{@link
     * #finalize}</code>.
     *
     * @param args the command line arguments.
     * @param file the PETSc database file.  If <code>null</code>,
     *             defaults to <code>~username/.petscrc</code>.
     * @param help the help message to print, if non-<code>null</code>
     * @param error an optional reference to a PETSc error code
     * @see <a href="http://www-unix.mcs.anl.gov/petsc/docs/manualpages/Sys/PetscInitialize.html"><code>PetscInitialize</code></a>
     */
    public Petsc(String[] args, String file, String help, int[] local error) {
	initialize(args, file, help, error);
    }

    /**
     * checks for options to be called at the conclusion of the
     * program and closes down MPI.  Each <code>Petsc</code> instance
     * must be finalized exactly once, by the same process that
     * created it.
     *
     * @see <a href="http://www-unix.mcs.anl.gov/petsc/docs/manualpages/Sys/PetscFinalize.html"><code>PetscFinalize</code></a>
     */
    public void finalize() {
	finalize(null);
    }

    /**
     * checks for options to be called at the conclusion of the
     * program and closes down MPI.  Each <code>Petsc</code> instance
     * must be finalized exactly once, by the same process that
     * created it.
     *
     * @param error an optional reference to a PETSc error code
     * @see <a href="http://www-unix.mcs.anl.gov/petsc/docs/manualpages/Sys/PetscFinalize.html"><code>PetscFinalize</code></a>
     */
    public void finalize(int[] local error) {
	finish(error);
    }

    /**
     * initializes the PETsc database and MPI.  Initialization should
     * always happen exactly once, near the beginning of the program.
     * Each process must either create a <code>Petsc</code> instance
     * or call <code>initialize</code>.  If <code>initialize</code> is
     * called, then it must be matched by a later call to <code>{@link
     * #finish}</code>.
     *
     * @return an explicit PETSc error code
     * @param args the command line arguments
     * @param file the PETSc database file.  If <code>null</code>,
     *             defaults to <code>~username/.petscrc</code>.
     * @param help the help message to print, if non-<code>null</code>
     * @param error an optional reference to a PETSc error code
     * @see <a href="http://www-unix.mcs.anl.gov/petsc/docs/manualpages/Sys/PetscInitialize.html"><code>PetscInitialize</code></a>
     */
    public static void initialize(String[] args, String file, String help, int[] local error) {
	int argc = args.length + 1;
	byte[] local [] local argv = new byte[argc][] local;

	// C expects first argument to be the executable name
	argv[0] = Util.getBytes("(Titanium program)");

	// convert given args from strings into byte arrays
	for (int scan = 1; scan < argc; ++scan)
	    argv[scan] = Util.getBytes(args[scan - 1]);

	// PETSc does not actually change argc or argv, so there is no
	// need to simulate call-by-reference here.
	initialize(argc, argv, Util.getBytes(file),
		   Util.getBytes(help), error);

	// create the standard communicators, now that MPI is up and running
	Comm.createStandardComms();

	// redirect java.lang.System's output and error streams through stdio
	StdioOutputStream.redirectJavaStreams();
    }

    /**
     * initializes the PETsc database and MPI, with strings
     * represented as null-terminated arrays of ASCII bytes.
     *
     * @return an explicit PETSc error code
     * @param args the command line arguments
     * @param file the PETSc database file.  If <code>null</code>,
     *             defaults to <code>~username/.petscrc</code>.
     * @param help the help message to print, if non-<code>null</code>
     * @param error an optional reference to a PETSc error code
     * @see <a href="http://www-unix.mcs.anl.gov/petsc/docs/manualpages/Sys/PetscInitialize.html"><code>PetscInitialize</code></a>
     */
    private native static void initialize(int argc, byte[] local [] local argv,
					  byte[] local file, byte[] local help,
					  int[] local error);
    
    /**
     * checks for options to be called at the conclusion of the
     * program and closes down MPI.  Each process that initialized
     * PETSc by calling <code>{@link #initialize(String[], String,
     * String)}</code> must eventually call <code>finish</code> before
     * exiting.
     *
     * @return an explicit PETSc error code
     */
    public native static void finish(int[] local error);
}
