package petsc;


/** PETSc viewers export information and data from PETSc objects. */

public abstract class Viewer extends PetscObject {
    
    /**
     * constructs a viewer with a given opaque handle
     *
     * @param handle the opaque C representation of the viewer
     */
    protected Viewer(Opaque local handle) {
	super(handle);
    }

    /**
     * restores the previous output or display format for a viewer, in
     * stack order
     *
     * @param error an optional reference to a PETSc error code
     * @see <a href="http://www-unix.mcs.anl.gov/petsc/docs/manualpages/Viewer/ViewerPopFormat.html"><code>ViewerPopFormat</code></a>
     */
    public local final native void popFormat(int[] local error);

    /**
     * sets the output or display format for a viewer, retaining the
     * previous format in stack order
     *
     * @param format the output format.  This must be one of the
     *               <code>FORMAT_*</code> constants from an
     *               appropriate <code>Viewer</Code> subclass.
     * @param name an object name, or <code>null</code>.  This is only
     *             used in certain output formats, such as {@link
     *             ViewerASCII#FORMAT_MATLAB}.
     * @param error an optional reference to a PETSc error code
     * @see <a href="http://www-unix.mcs.anl.gov/petsc/docs/manualpages/Viewer/ViewerPushFormat.html"><code>ViewerPushFormat</code></a>
     */
    public local final void pushFormat(int format, String name, int[] local error) {
	pushFormatRaw(format, Util.getBytes(name), error);
    }

    /**
     * sets the output or display format for a viewer, retaining the
     * previous format in stack order
     *
     * @param format the output format.  This must be one of the
     *               <code>FORMAT_*</code> constants from an
     *               appropriate <code>Viewer</Code> subclass.
     * @param name an object name as a <code>null</code>-terminated
     *             array of bytes, or <code>null</code>.
     * @param error an optional reference to a PETSc error code
     */
    private local native void pushFormatRaw(int format, byte[] local name, int[] local error);
    
    /**
     * sets the output or display format for a viewer
     *
     * @param format the output format.  This must be one of the
     *               <code>FORMAT_*</code> constants from an
     *               appropriate <code>Viewer</Code> subclass.
     * @param name an object name, or <code>null</code>.  This is only
     *             used in certain output formats, such as {@link
     *             ViewerASCII#FORMAT_MATLAB}.
     * @param error an optional reference to a PETSc error code
     * @see <a href="http://www-unix.mcs.anl.gov/petsc/docs/manualpages/Viewer/ViewerSetFormat.html"><code>ViewerSetFormat</code></a>
     */
    public local final void setFormat(int format, String name, int[] local error) {
	setFormatRaw(format, Util.getBytes(name), error);
    }

    /**
     * sets the output or display format for a viewer
     *
     * @param format the output format.  This must be one of the
     *               <code>FORMAT_*</code> constants from an
     *               appropriate <code>Viewer</Code> subclass.
     * @param name an object name as a <code>null</code>-terminated
     *             array of bytes, or <code>null</code>.
     * @param error an optional reference to a PETSc error code
     */
    private local native void setFormatRaw(int format, byte[] local name, int[] local error);
}
