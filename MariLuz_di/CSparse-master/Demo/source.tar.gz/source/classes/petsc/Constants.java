package petsc;


/**
 *  global constants used broadly, across a variety of methods
 */

public interface Constants {
    /** requests that PETSc choose some value automatically */
    static final int PETSC_DECIDE = -1;
    
    /** requests that PETSc compute some value automatically */
    static final int PETSC_DETERMINE = -1;
}
