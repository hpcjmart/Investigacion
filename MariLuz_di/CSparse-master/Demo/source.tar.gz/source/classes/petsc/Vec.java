package petsc;

// used by native code, so force code generation
import petsc.PetscError;


final public class Vec
    extends PetscObject
    implements Constants, InsertMode, NormType {
    
    /**
     * creates a standard, sequential array-style vector
     *
     * @param n the vector length
     * @param error an optional reference to a PETSc error code
     * @see <a href="http://www-unix.mcs.anl.gov/petsc/docs/manualpages/Vec/VecCreateSeq.html"><code>VecCreateSeq</code></a>
    */
    public Vec(int n, int[] local error) {
	super(createSeqRaw(n, error));
    }

    /**
     * creates a parallel vector
     *
     * @param n the local vector length (or {@link #PETSC_DECIDE} to have calculated if <code>N</code> is given)
     * @param N the total vector length (or {@link #PETSC_DECIDE} to have calculated if <code>n</code> is given)
     * @param error an optional reference to a PETSc error code
     * @see <a href="http://www-unix.mcs.anl.gov/petsc/docs/manualpages/Vec/VecCreateMPI.html"><code>VecCreateMPI</code></a>
     */
    public Vec(int n, int N, int[] local error) {
	super(createMPIRaw(n, N, error));
    }

    /**
     * creates a new vector of the same type as an existing vector
     *
     * @param x a vector to mimic
     * @param error an optional reference to a PETSc error code
     * @see <a href="http://www-unix.mcs.anl.gov/petsc/docs/manualpages/Vec/VecDuplicate.html"><code>VecDuplicate</code></a>
     */
    public Vec(Vec local x, int[] local error) {
	super(x.duplicateRaw(error));
    }

    /**
     * constructs a vector with a given opaque handle
     *
     * @param handle the opaque C representation of the vector
     */
    Vec(Opaque local handle) {
	super(handle);
    }

    /**
     * replaces every element in a vector with its absolute value
     *
     * @param error an optional reference to a PETSc error code
     * @see <a href="http://www-unix.mcs.anl.gov/petsc/docs/manualpages/Vec/VecAbs.html"><code>VecAbs</code></a>
     */
    native public local void abs(int[] local error);

    /**
     * computes y = alpha x + beta y, where y is the Vec instance on
     * which the method is called
     *
     * @param alpha a scalar
     * @param beta a scalar
     * @param x a vector
     * @param error an optional reference to a PETSc error code
     * @see <a href="http://www-unix.mcs.anl.gov/petsc/docs/manualpages/Vec/VecAXPBY.html"><code>VecAXPBY</code></a>
     */
    native public local void axpby(double alpha, double beta, Vec local x, int[] local error);

    /**
     * computes y = alpha x + y, where y is the Vec instance on which
     * the method is called
     *
     * @param alpha the scalar
     * @param x a vector
     * @param error an optional reference to a PETSc error code
     * @see <a href="http://www-unix.mcs.anl.gov/petsc/docs/manualpages/Vec/VecAXPY.html"><code>VecAXPY</code></a>
     */
    native public local void axpy(double alpha, Vec local x, int[] local error);
    
    /**
     * computes y = x + alpha y, where y is the Vec instance on which
     * the method is called
     *
     * @param alpha a scalar
     * @param x a vector
     * @param error an optional reference to a PETSc error code
     * @see <a href="http://www-unix.mcs.anl.gov/petsc/docs/manualpages/Vec/VecAYPX.html"><code>VecAYPX</code></a>
     */
    native public local void aypx(double alpha, Vec local x, int[] local error);

    /**
     * copies this vector to a destination vector.
     *
     * @param y the destination copy
     * @param error an optional reference to a PETSc error code
     * @see <a href="http://www-unix.mcs.anl.gov/petsc/docs/manualpages/Vec/VecCopy.html"><code>VecCopy</code></a>
     */
    native public local void copy(Vec local y, int[] local error);

    /**
     * creates a parallel vector
     *
     * @return the new vector's opaque handle
     * @param n the local vector length (or {@link #PETSC_DECIDE} to have calculated if <code>N</code> is given)
     * @param N the local vector length (or {@link #PETSC_DECIDE} to have calculated if <code>n</code> is given)
     * @param error an optional reference to a PETSc error code
     */
    native private static Opaque local createMPIRaw(int n, int N, int[] local error);

    /**
     * creates a standard, sequential array-style vector
     *
     * @return the new vector's opaque handle
     * @param n the vector length
     * @param error an optional reference to a PETSc error code
     */
    native private static Opaque local createSeqRaw(int n, int[] local error);

    /**
     * computes the vector dot product x y, where x is the Vec
     * instance on which the method is called
     *
     * @return the dot product
     * @param y the multiplicand vector
     * @param error an optional reference to a PETSc error code
     * @see <a href="http://www-unix.mcs.anl.gov/petsc/docs/manualpages/Vec/VecDot.html"><code>VecDot</code></a>
     */
    native public local double dot(Vec local y, int[] local error);

    /**
     * creates a new vector of the same type as an existing vector
     *
     * @return a new vector with the same layout as <code>this</code>
     * @param error an optional reference to a PETSc error code
     * @see <a href="http://www-unix.mcs.anl.gov/petsc/docs/manualpages/Vec/VecDuplicate.html"><code>VecDuplicate</code></a>
     */
    public local Vec local duplicate(int[] local error) {
	return new Vec(this, error);
    }

    /**
     * creates a new vector of the same type as an existing vector
     *
     * @return the new vector's opaque handle
     * @param x a vector to mimic
     * @param error an optional reference to a PETSc error code
     * @see <a href="http://www-unix.mcs.anl.gov/petsc/docs/manualpages/Vec/VecDuplicate.html"><code>VecDuplicate</code></a>
     */
    native private local Opaque local duplicateRaw(int[] local error);
    
    /**
     * returns a pointer to a contiguous array that contains this
     * processor's portion of the vector data. For the standard PETSc
     * vectors, <code>getArray</code> returns a pointer to the local
     * data array and does not use any copies. If the underlying
     * vector data is not stored in a contiquous array this routine
     * will copy the data to a contiquous array and return a pointer
     * to that. You <em>must</em> call {@link #restoreArray} when you
     * no longer need access to the array.
     *
     * @return the array containing the vector's data
     * @param error an optional reference to a PETSc error code
     * @see <a href="http://www-unix.mcs.anl.gov/petsc/docs/manualpages/Vec/VecGetArray.html"><code>VecGetArray</code></a>
     */
    public local double[1d] local getArray(int[] local error)
    {
	return getArrayRaw([0 : getLocalSize(error)], error);
    }

    /**
     * returns a pointer to a contiguous array that contains this
     * processor's portion of the vector data
     *
     * @return the array containing the vector's data
     * @param domain the domain of the local portion of the vector's data
     * @param error an optional reference to a PETSc error code
     * @see <a href="http://www-unix.mcs.anl.gov/petsc/docs/manualpages/Vec/VecGetArray.html"><code>VecGetArray</code></a>
     */
    native private local double[1d] local getArrayRaw(RectDomain<1> domain, int[] local error);

    /**
     * returns the number of elements of the vector stored in local
     * memory.  This routine may be implementation dependent, so use
     * with care.
     *
     * @return the length of the local piece of the vector
     * @param error an optional reference to a PETSc error code
     * @see <a href="http://www-unix.mcs.anl.gov/petsc/docs/manualpages/Vec/VecGetLocalSize.html"><code>VecGetLocalSize</code></a>
     */
    native public local int getLocalSize(int[] local error);

    /**
     * returns the range of indices owned by this processor.  This
     * assumes that the vectors are laid out with the first n1
     * elements on the first processor, next n2 elements on the
     * second, etc.  For certain parallel layouts this range may not
     * be well defined.
     *
     * @return the half-closed interval representing the local range
     * @param error an optional reference to a PETSc error code
     * @see #getOwnershipRange(int[], int[], int[]);
     * @see <a href="http://www-unix.mcs.anl.gov/petsc/docs/manualpages/Vec/VecGetOwnershipRange.html"><code>VecGetOwnershipRange</code></a>
     */
    public local Range getOwnershipRange(int[] local error) {
	int[] local start = { 0 };
	int[] local end = { 0 };
	
	getOwnershipRange(start, end, error);
	return new Range(start[0], end[0]);
    }

    /**
     * returns the range of indices owned by this processor.  This
     * assumes that the vectors are laid out with the first n1
     * elements on the first processor, next n2 elements on the
     * second, etc.  For certain parallel layouts this range may not
     * be well defined.
     *
     * @param low a reference to the first local element.  Pass in
     *            <code>null</code> if not interested.
     * @param high a reference to one more than the last local
     *            element.  Pass in <code>null</code> if not
     *            interested.
     * @param error an optional reference to a PETSc error code
     * @see #getOwnershipRange(int[])
     * @see <a href="http://www-unix.mcs.anl.gov/petsc/docs/manualpages/Vec/VecGetOwnershipRange.html"><code>VecGetOwnershipRange</code></a>
     */
    native public local void getOwnershipRange(int[] local low, int[] local high, int[] local error);

    /**
     * returns the global number of elements of the entire vector
     *
     * @return the global length of the vector
     * @param error an optional reference to a PETSc error code
     * @see <a href="http://www-unix.mcs.anl.gov/petsc/docs/manualpages/Vec/VecGetSize.html"><code>VecGetSize</code></a>
     */
    native public local int getSize(int[] local error);

    /**
     * computes x = x + sum alpha[j] y[j], where x is the Vec instance
     * on which the method is called
     *
     * @param alpha an array of scalars
     * @param y an array of vector
     * @param error an optional reference to a PETSc error code
     * @exception IllegalArgumentException if <code>alpha</code> and
     *            <code>y</code> are of differing lengths
     * @see <a href="http://www-unix.mcs.anl.gov/petsc/docs/manualpages/Vec/VecMAXPY.html"><code>VecMAXPY</code></a>
     */
    public local void maxpy(double[] local alpha, Vec local[] local y, int[] local error) {
	if (alpha.length != y.length)
	    throw new IllegalArgumentException("maxpy: length mismatch: alpha["
					       + alpha.length + "] versus y["
					       + y.length + ']');

	maxpyRaw(alpha, handles(y), error);
    }

    /**
     * computes x = x + sum alpha[j] y[j], where x is the Vec instance
     * on which the method is called.  The <code>alpha</code> and
     * <code>y</code> arrays are assumed to be of equal length.
     *
     * @param alpha an array of scalars
     * @param y an array of opaque vector handles
     * @param error an optional reference to a PETSc error code
     */
    native private local void maxpyRaw(double[] local alpha, Opaque local[] local y, int[] local error);

    /**
     * computes multiple vector dot products
     *
     * @return an array of the dot products
     * @param y an array of multiplicand vectors
     * @param error an optional reference to a PETSc error code
     * @see <a href="http://www-unix.mcs.anl.gov/petsc/docs/manualpages/Vec/VecMDot.html"><code>VecMDot</code></a>
     */
    public local double[] local mDot(Vec local[] local y, int[] local error) {
	double[] local results = new double[y.length];
	mDotRaw(handles(y), results, error);
	return results;
    }

    /**
     * computes multiple vector dot products using opaque vector handles
     *
     * @return an array of the dot products
     * @param y an array of opaque handles of multiplicand vectors
     * @param val an array of dot product results, of the same length as <code>y</code>
     * @param error an optional reference to a PETSc error code
     * @see <a href="http://www-unix.mcs.anl.gov/petsc/docs/manualpages/Vec/VecMDot.html"><code>VecMDot</code></a>
     */
    native private local void mDotRaw(Opaque local[] local y, double[] local val, int[] local error);

    /**
     * computes the vector norm.  Note that normal type
     * <code>NORM_1_AND_2</code> used in C and Fortran is not
     * available.  If you wish to compute both <code>NORM_1</code> and
     * <code>NORM_2</code> of a vector, call {@link #norm1and2}.
     *
     * @return the norm
     * @param type one of {@link #NORM_1}, {@link #NORM_2}, {@link
     *             #NORM_INFINITY}
     * @param error an optional reference to a PETSc error code
     * @see <a href="http://www-unix.mcs.anl.gov/petsc/docs/manualpages/Vec/VecNorm.html"><code>VecNorm</code></a>
     */
    native public local double norm(int type, int[] local error);

    /**
     * computes vector norms {@link #NORM_1} and {@link #NORM_2}, and
     * returns them in a new array.  This is equivalent to calling
     * <code>VecNorm</code> with <code>NORM_1_AND_2</code> in C or
     * Fortran.
     *
     * @return a two-element array of the norms
     * @param error an optional reference to a PETSc error code
     * @see #norm1and2(double[], int[])
     * @see <a href="http://www-unix.mcs.anl.gov/petsc/docs/manualpages/Vec/VecNorm.html"><code>VecNorm</code></a>
     */
    public local double[] local norm1and2(int[] local error) {
	double[] local norms = { 0, 0 };
	norm1and2(norms, error);
	return norms;
    }

    /**
     * computes vector norms {@link #NORM_1} and {@link #NORM_2}, and
     * places them in a given array.  This is equivalent to calling
     * <code>VecNorm</code> with <code>NORM_1_AND_2</code> in C or
     * Fortran.
     *
     * @param norms a two-element array of the norms
     * @param error an optional reference to a PETSc error code
     * @see #norm1and2(int[])
     * @see <a href="http://www-unix.mcs.anl.gov/petsc/docs/manualpages/Vec/VecNorm.html"><code>VecNorm</code></a>
     */
    native public local void norm1and2(double[] local norms, int[] local error);

    /**
     * computes the componentwise multiplication w = x * y, where w is
     * the Vec instance on which the method is called
     *
     * @param x the multiplier
     * @param y the multiplicand
     * @param error an optional reference to a PETSc error code
     * @see <a href="http://www-unix.mcs.anl.gov/petsc/docs/manualpages/Vec/VecPointwiseMult.html"><code>VecPointwiseMult</code></a>
     */
    native public local void pointwiseMult(Vec local x, Vec local y, int[] local error);

    /**
     * replaces each component of a vector by its reciprocal
     *
     * @param error an optional reference to a PETSc error code
     * @see <a href="http://www-unix.mcs.anl.gov/petsc/docs/manualpages/Vec/VecReciprocal.html"><code>VecReciprocal</code></a>
     */
    native public local void reciprocal(int[] local error);

    /**
     * restores a vector after {@link #GetArray} has been called.
     *
     * @param array array obtained from {@link #GetArray}
     * @param error an optional reference to a PETSc error code
     * @see <a href="http://www-unix.mcs.anl.gov/petsc/docs/manualpages/Vec/VecRestoreArray.html"><code>VecRestoreArray</code></a>
     */
    native public local void restoreArray(double[1d] local array, int[] local error);

    /**
     * scales each component of a vector by a scalar
     *
     * @param alpha the scalar
     * @param error an optional reference to a PETSc error code
     * @see <a href="http://www-unix.mcs.anl.gov/petsc/docs/manualpages/Vec/VecScale.html"><code>VecScale</code></a>
     */
    native public local void scale(double alpha, int[] local error);

    /**
     * sets all components of a vector to a single scalar value
     *
     * @param alpha the scalar
     * @param error an optional reference to a PETSc error code
     * @see <a href="http://www-unix.mcs.anl.gov/petsc/docs/manualpages/Vec/VecSet.html"><code>VecSet</code></a>
     */
    native public local void set(double alpha, int[] local error);

    /**
     * sets all components of a vector to random numbers
     *
     * @param rctx the random number context
     * @param error an optional reference to a PETSc error code
     * @see <a href="http://www-unix.mcs.anl.gov/petsc/docs/manualpages/Vec/VecSetRandom.html"><code>VecSetRandom</code></a>
     */
    native public local void setRandom(PetscRandom local rctx, int[] local error);

    /**
     * sets a single entry into a vector
     *
     * @param row the row location of the entry
     * @param value the value to insert
     * @param mode the treatment of any existing values (see {@link InsertMode})
     * @see <a href="http://www-unix.mcs.anl.gov/petsc/docs/manualpages/Vec/VecSetValue.html"><code>VecSetValue</code></a>
     */
    native public local void setValue(int row, double value, int mode);

    /**
     * computes the sum of all the components of a vector
     *
     * @param error an optional reference to a PETSc error code
     * @see <a href="http://www-unix.mcs.anl.gov/petsc/docs/manualpages/Vec/VecSum.html"><code>VecSum</code></a>
     */
    native public local double sum(int[] local error);

    /**
     * computes w = alpha x + y, where w is the Vec instance on which
     * the method is called
     *
     * @param alpha a scalar
     * @param beta a scalar
     * @param x a vector
     * @param y a vector
     * @param error an optional reference to a PETSc error code
     * @see <a href="http://www-unix.mcs.anl.gov/petsc/docs/manualpages/Vec/VecWAXPY.html"><code>VecWAXPY</code></a>
     */
    native public local void waxpy(double alpha, Vec local x, Vec local y, int[] local error);
}
