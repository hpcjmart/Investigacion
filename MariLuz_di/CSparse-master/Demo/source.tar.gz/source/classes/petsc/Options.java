package petsc;


/**
 * methods for managing the command-line options database
 */

final public class Options {

    /**
     * gets the double precision value for a particular option in the
     * database
     *
     * @return the value, or <code>null</code> if the named option was
     *         not found
     * @param pre a string to prepend to each name, or <code>null</code>
     * @param name the option one is seking
     * @param error an optional reference to a PETSc error code
     */
    public static Double local getDouble(String pre, String name, int[] local error) {
	double[] local value = { 0. };

	return getDoubleRaw(Util.getBytes(pre),
			    Util.getBytes(name),
			    value, error)
	    ? new Double(value[0])
	    : null;
    }

    /**
     * gets the double precision value for a particular option in the
     * database
     *
     * @return <code>true</code> if the value was found;
     *         <code>false</code> if it was not
     * @param pre a string to prepend to each name, or <code>null</code>
     * @param name the option one is seking
     * @param dvalue a reference to the returned value
     * @param error an optional reference to a PETSc error code
     */
    private static native boolean getDoubleRaw(byte[] local pre,
					       byte[] local name,
					       double[] local dvalue,
					       int[] local error);

    /**
     * gets the integer value for a particular option in the database
     *
     * @return the value, or <code>null</code> if the named option was
     *         not found
     * @param pre a string to prepend to each name, or <code>null</code>
     * @param name the option one is seking
     * @param error an optional reference to a PETSc error code
     */
    public static Integer local getInt(String pre, String name, int[] local error) {
	int[] local value = { 0 };

	return getIntRaw(Util.getBytes(pre),
			 Util.getBytes(name),
			 value, error)
	    ? new Integer(value[0])
	    : null;
    }

    /**
     * gets the integer value for a particular option in the database
     *
     * @return <code>true</code> if the value was found;
     *         <code>false</code> if it was not
     * @param pre a string to prepend to each name, or <code>null</code>
     * @param name the option one is seking
     * @param dvalue a reference to the returned value
     * @param error an optional reference to a PETSc error code
     */
    private static native boolean getIntRaw(byte[] local pre,
					       byte[] local name,
					       int[] local dvalue,
					       int[] local error);

    /**
     * gets the string value for a particular option in the database
     *
     * @return the string, or <code>null</code> if the named option
     *         was not found
     * @param pre a string to prepend to each name, or <code>null</code>
     * @param name the option one is seking
     * @param error an optional reference to a PETSc error code
     */
    public static native String local getString(String pre,
						String name,
						int[] local error);

    /**
     * determines whether a certain option is given in the database
     *
     * @return <code>true</code> if the option was found;
     *         <code>false</code> if it was not
     * @param pre a string to prepend to each name, or <code>null</code>
     * @param name the option one is seking
     * @param error an optional reference to a PETSc error code
     */
    public static boolean hasName(String pre, String name, int[] local error) {
	return hasNameRaw(Util.getBytes(pre), Util.getBytes(name), error);
    }

    /**
     * determines whether a certain option is given in the database
     *
     * @return <code>true</code> if the option was found;
     *         <code>false</code> if it was not
     * @param pre a string to prepend to each name, or <code>null</code>
     * @param name the option one is seking
     * @param error an optional reference to a PETSc error code
     */
    private static native boolean hasNameRaw(byte[] local pre,
					     byte[] local name,
					     int[] local error);
}
