package petsc;

// used by native code, so force code generation
import petsc.PetscError;


/**
 * an ordered sequence of indexes.  IS instances are used to index
 * into vectors and matrices and to set up vector scatters.
 */

final public class IS extends PetscObject {

    /**
     * creates a blocked index set containing a list of integers
     * grouped into contiguous spans.  The indices are relative to
     * entries, not blocks.
     *
     * @param comm the communicator
     * @param bs the number of elements in each block
     * @param idx the list of integers.  Each integer is the start of
     *            a new block of <code>bs</code> contiguous values.
     * @param error an optional reference to a PETSc error code
     * @see <a href="http://www-unix.mcs.anl.gov/petsc/docs/manualpages/IS/ISCreateBlock.html"><code>ISCreateBlock</code></a>
     */
    public IS(Comm comm, int bs, int[] local idx, int[] local error) {
	super(createBlockRaw(comm, bs, idx, error));
    }

    /**
     * creates a generalized index set containing an arbitrary list of
     * integers
     *
     * @param comm the communicator
     * @param idx the list of integers
     * @param error an optional reference to a PETSc error code
     * @see <a href="http://www-unix.mcs.anl.gov/petsc/docs/manualpages/IS/ISCreateGeneral.html"><code>ISCreateGeneral</code></a>
     */
    public IS(Comm comm, int[] local idx, int[] local error) {
	super(createGeneralRaw(comm, idx, error));
    }

    /**
     * creates a strided index set containing a list of evenly spaced
     * integers
     *
     * @param comm the communicator
     * @param n the length of the index set
     * @param first the first element of the index set
     * @param step the change to the next index
     * @param error an optional reference to a PETSc error code
     * @see <a href="http://www-unix.mcs.anl.gov/petsc/docs/manualpages/IS/ISCreateStride.html"><code>ISCreateStride</code></a>
     */
    public IS(Comm comm, int n, int first, int step, int[] local error) {
	super(createStrideRaw(comm, n, first, step, error));
    }

    /**
     * creates a strided index set containing the same integers as a
     * one-dimensional rectangular domain
     *
     * @param comm the communicator
     * @param domain the rectangular domain
     * @param error an optional reference to a PETSc error code
     * @see <a href="http://www-unix.mcs.anl.gov/petsc/docs/manualpages/IS/ISCreateStride.html"><code>ISCreateStride</code></a>
     */
    public IS(Comm comm, RectDomain<1> domain, int[] local error) {
	this(comm, domain.size(), domain.min()[1], domain.stride()[1], error);
    }

    /**
     * creates a blocked index set containing a list of integers
     * grouped into contiguous spans.  The indices are relative to
     * entries, not blocks.
     *
     * @return the new index set's opaque handle
     * @param comm the communicator
     * @param bs the number of elements in each block
     * @param idx the list of integers.  Each integer is the start of
     *            a new block of <code>bs</code> contiguous values.
     * @param error an optional reference to a PETSc error code
     * @see <a href="http://www-unix.mcs.anl.gov/petsc/docs/manualpages/IS/ISCreateBlock.html"><code>ISCreateBlock</code></a>
     */
    private native static Opaque local createBlockRaw(Comm comm, int bs, int[] local idx, int[] local error);

    /**
     * creates a generalized index set containing an arbitrary list of
     * integers
     *
     * @return the new index set's opaque handle
     * @param comm the communicator
     * @param idx the list of integers
     * @param error an optional reference to a PETSc error code
     * @see <a href="http://www-unix.mcs.anl.gov/petsc/docs/manualpages/IS/ISCreateGeneral.html"><code>ISGeneralBlock</code></a>
     */
    private native static Opaque local createGeneralRaw(Comm comm, int[] local idx, int[] local error);

    /**
     * creates a strided index set containing a list of evenly spaced
     * integers
     *
     * @return the new index set's opaque handle
     * @param comm the communicator
     * @param n the length of the index set
     * @param first the first element of the index set
     * @param step the change to the next index
     * @param error an optional reference to a PETSc error code
     * @see <a href="http://www-unix.mcs.anl.gov/petsc/docs/manualpages/IS/ISCreateStride.html"><code>ISCreateStride</code></a>
     */
    private native static Opaque local createStrideRaw(Comm comm, int n, int first, int step, int[] local error);
}
