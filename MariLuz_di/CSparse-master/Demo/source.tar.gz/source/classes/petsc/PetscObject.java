package petsc;


/**
 * common base class for all PETSc objects.  This includes vectors,
 * matrixes, mappings, viewers, solvers, and the like.  All such
 * objects share certain common functionality, which is defined here.
 */

public abstract class PetscObject {
    /**
     * the raw PETSc object created by the native libraries.  This is
     * not actually a Titanium Object, but rather is simply a C
     * pointer.  This field can be copied around and assigned, but it
     * must never be used as though it were actually a real Object.
     */
    protected final Opaque local handle;

    /**
     * constructs a PETSc object with a given opaque handle.  The
     * handle is the C representation of the object.  This would be a
     * C <code>Vec</code>, for example, if a Titanium
     * <code>petsc.Vec</code> were being constructed.
     *
     * @param handle the opaque C representation of the PETSc object
     */
    protected PetscObject(Opaque local handle) {
	this.handle = handle;
	createRaw();
    }

    /**
     * completes internal construction of a PETSc object
     */
    private native local void createRaw();

    /**
     * unwraps an array of PetscObjects, returning an array of their
     * opaque handles.  This is used in preparation for calling a
     * native routine that expects to manipulate an array of PETSc
     * objects.
     *
     * @return an extracted array of opaque handles
     * @param objects an array of PETSc objects
     */
    protected static Opaque local[] local handles(PetscObject local[] local objects) {
	Opaque local[] local raw = new Opaque local[objects.length];
	
	for (int extract = 0; extract < objects.length; ++extract)
	    raw[extract] = objects[extract].handle;

	return raw;
    }

    /**
     * views any PETSc object, regardless of the type
     *
     * @param viewer any PETSc viewer
     * @param error an optional reference to a PETSc error code
     * @see <a href="http://www-unix.mcs.anl.gov/petsc/docs/manualpages/Sys/PetscObjectView.html"><code>PetscObjectView</code></a>
     */
    public final local native void view(Viewer local viewer, int[] local error);

    /**
     * destroys any PETSc object, regardless of the type
     *
     * @param error an optional reference to a PETSc error code
     * @see <a href="http://www-unix.mcs.anl.gov/petsc/docs/manualpages/Sys/PetscObjectDestroy.html"><code>PetscObjectDestroy</code></a>
     */
    public local native void destroy(int[] local error);

    /**
     * destroys any PETSc object, regardless of the type
     *
     * @see <a href="http://www-unix.mcs.anl.gov/petsc/docs/manualpages/Sys/PetscObjectDestroy.html"><code>PetscObjectDestroy</code></a>
     */
    public void finalize() {
	((PetscObject local) this).destroy(null);
    }
}
