package petsc;


/**
 * constants that describe ways to combine new values with existing ones
 */

public interface InsertMode {
    
    /** keep the existing value, and simply ignore the new one */
    static final int NOT_SET_VALUES = 0;

    /** replace any existing value with the new one */
    static final int INSERT_VALUES = 1;

    /** add the new value to the existing one */
    static final int ADD_VALUES = 2;

    /** use the greater of the new and existing values */
    static final int MAX_VALUES = 3;
}
