package petsc;


/**
 * constants that describe ways to perform a vector-to-vector scatter
 */

public interface ScatterMode {
    static final int SCATTER_FORWARD = 0;
    static final int SCATTER_REVERSE = 1;
    static final int SCATTER_FORWARD_LOCAL = 2;
    static final int SCATTER_REVERSE_LOCAL = 3;
    static final int SCATTER_LOCAL = 2;
}
