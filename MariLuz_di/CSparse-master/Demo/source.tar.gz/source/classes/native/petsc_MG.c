#include <mg.h>
#include <vec.h>
#include <mat.h>
#include "check.h"
#include "enshroud.h"

#include "cl_petsc_SLES.h"
#include "layout!JA_jint.h"
#include "layout!cl_petsc_MG.h"
#include "layout!cl_petsc_MatBase.h"
#include "layout!cl_petsc_Vec.h"

#define unwrap(me) ((PC) (me)->cl_petsc_PetscObject_fld_handle)
#define unwrapVec(me) ((Vec) (me)->cl_petsc_PetscObject_fld_handle)
#define unwrapMat(me) ((Mat) (me)->cl_petsc_PetscObject_fld_handle)


void cl_petsc_MG_mt_setLevels_L_jint_LP_JA_jint(
    LP_cl_petsc_MG me, jint levels, LP_JA_jint error
)
{
  check(MGSetLevels(unwrap(me), levels), error);
}

void cl_petsc_MG_mt_setType_L_jint_LP_JA_jint(
    LP_cl_petsc_MG me, jint type, LP_JA_jint error
)
{
  check(MGSetType(unwrap(me), type), error);
}

void cl_petsc_MG_mt_setRhs_L_jint_LP_cl_petsc_Vec_LP_JA_jint(
    LP_cl_petsc_MG me, jint level, LP_cl_petsc_Vec v, LP_JA_jint error
)
{
  check(MGSetRhs(unwrap(me), level, unwrapVec(v)), error);
}

void cl_petsc_MG_mt_setX_L_jint_LP_cl_petsc_Vec_LP_JA_jint(
    LP_cl_petsc_MG me, jint level, LP_cl_petsc_Vec v, LP_JA_jint error
)
{
  check(MGSetX(unwrap(me), level, unwrapVec(v)), error);
}

void cl_petsc_MG_mt_setR_L_jint_LP_cl_petsc_Vec_LP_JA_jint(
    LP_cl_petsc_MG me, jint level, LP_cl_petsc_Vec v, LP_JA_jint error
)
{
  check(MGSetR(unwrap(me), level, unwrapVec(v)), error);
}

void cl_petsc_MG_mt_setResidualDefault_L_jint_LP_cl_petsc_MatBase_LP_JA_jint(
    cl_petsc_MG *me, jint level, cl_petsc_MatBase *m, JA_jint *error
)
{
  check(MGSetResidual(unwrap(me), level, MGDefaultResidual, unwrapMat(m)),
	error);
}

cl_petsc_SLES *cl_petsc_MG_mt_getCoarseSolve_L_LP_JA_jint(
  cl_petsc_MG *me, JA_jint *error)
{
  SLES sles;
  check(MGGetCoarseSolve(unwrap(me), &sles), error);
  return enshroud(sles, SLES);
}

cl_petsc_SLES *cl_petsc_MG_mt_getSmoother_L_jint_LP_JA_jint(
    LP_cl_petsc_MG me, jint l, LP_JA_jint error
)
{
  SLES sles;
  check(MGGetSmoother(unwrap(me), l, &sles), error);
  return enshroud(sles, SLES);
}

void cl_petsc_MG_mt_setInterpolate_L_jint_LP_cl_petsc_MatBase_LP_JA_jint(
    cl_petsc_MG *me,
    jint l,
    cl_petsc_MatBase* mat,
    JA_jint *error
)
{
  check(MGSetInterpolate(unwrap(me), l, unwrapMat(mat)), error);
}

void cl_petsc_MG_mt_setRestriction_L_jint_LP_cl_petsc_MatBase_LP_JA_jint(
    cl_petsc_MG *me, 
    jint l, 
    cl_petsc_MatBase *mat, 
    JA_jint *error
) 
{
  check(MGSetRestriction(unwrap(me), l, unwrapMat(mat)), error);
}


/*
 * Local variables:
 * c-file-style: "gnu"
 * c-file-offsets: ((arglist-intro . +))
 * End:
 */
