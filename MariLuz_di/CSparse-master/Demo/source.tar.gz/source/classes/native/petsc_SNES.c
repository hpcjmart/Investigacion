#include <snes.h>
#include "check.h"
#include "enshroud.h"

#include "cl_petsc_Mat.h"
#include "cl_petsc_Vec.h"
#include "cl_petsc_SLES.h"
#include "layout!JA_jint.h"


#define uncomm(comm)  ((MPI_Comm) (comm).cl_petsc_Comm_fld_handle)
#define unmat(mat)    ((Mat)  (mat)->cl_petsc_PetscObject_fld_handle)
#define unvec(vec)    ((Vec)  (vec)->cl_petsc_PetscObject_fld_handle)
#define unwrap(me)    ((SNES) (me )->cl_petsc_PetscObject_fld_handle)

#define STATIC(field) (STATIC_REF(cl_petsc_SNES_fld_ ## field))


/**********************************************************************/


static int upcallJacobian(SNES snesRaw, Vec xRaw, Mat *aRaw, Mat *bRaw, MatStructure *flag, void *context)
{
  /*
   * How do we know to enshroud A and B as Mat instead of MatBase?  We
   * simply assume that if either were a MatShell, it would already be
   * enshrouded.
   */

  cl_petsc_Vec * const x = enshroud(xRaw, Vec);
  cl_petsc_MatBase * const A = (cl_petsc_MatBase *) enshroud(*aRaw, Mat);
  cl_petsc_MatBase * const B = (cl_petsc_MatBase *) enshroud(*bRaw, Mat);
  cl_petsc_SNES * const me = (cl_petsc_SNES *) context;

  *STATIC(A)->data = A;
  *STATIC(B)->data = B;
  *STATIC(flag)->data = *flag;
  *STATIC(error)->data = 0;

  me->class_info->_mt_jacobian_L_LP_cl_petsc_Vec_LP_JA_LP_cl_petsc_MatBase_LP_JA_LP_cl_petsc_MatBase_LP_JA_jint_LP_JA_jint(
    me, x, STATIC(A), STATIC(B), STATIC(flag), STATIC(error));
  
  *aRaw = unmat(*STATIC(A)->data);
  *bRaw = unmat(*STATIC(B)->data);
  *flag = (MatStructure) *STATIC(flag)->data;
  return *STATIC(error)->data;
}


/**********************************************************************/


cl_petsc_SLES *cl_petsc_SNES_mt_getSLES_L_LP_JA_jint(
  cl_petsc_SNES *me, JA_jint *error)
{
  SLES sles;
  check(SNESGetSLES(unwrap(me), &sles), error);
  return enshroud(sles, SLES);
}


void cl_petsc_SNES_mt_setFromOptions_L_LP_JA_jint(
  cl_petsc_SNES *me, JA_jint *error)
{
  check(SNESSetFromOptions(unwrap(me)), error);
}


void cl_petsc_SNES_mt_setJacobian_L_LP_cl_petsc_MatBase_LP_cl_petsc_MatBase_LP_JA_jint(
  cl_petsc_SNES *me, cl_petsc_MatBase *A, cl_petsc_MatBase *B, JA_jint *error)
{
  check(SNESSetJacobian(unwrap(me),
			unmat(A), unmat(B),
			upcallJacobian, me),
	error);
}


jint cl_petsc_SNES_mt_solve_L_LP_cl_petsc_Vec_LP_JA_jint(
  cl_petsc_SNES *me, cl_petsc_Vec *x, JA_jint *error)
{
  int iterations;
  check(SNESSolve(unwrap(me), unvec(x), &iterations), error);
  return iterations;
}


/*
 * Local variables:
 * c-file-style: "gnu"
 * c-file-offsets: ((arglist-intro . +))
 * End:
 */
