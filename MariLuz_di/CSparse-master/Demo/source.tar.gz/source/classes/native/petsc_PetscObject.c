#include <petsc.h>
#include "check.h"
#include "layout!cl_petsc_Viewer.h"


#define unwrap(me)  ((PetscObject) (me)->cl_petsc_PetscObject_fld_handle)
#define unview(me)  ((Viewer)      (me)->cl_petsc_PetscObject_fld_handle)


void cl_petsc_PetscObject_mt_createRaw_L(cl_petsc_PetscObject *me)
{
  unwrap(me)->cpp = me;
}


void cl_petsc_PetscObject_mt_destroy_L_LP_JA_jint(
  cl_petsc_PetscObject *me, JA_jint *error)
{
  if (unwrap(me))
    {
      check(PetscObjectDestroy(unwrap(me)), error);
      unwrap(me) = 0;
    }
}


void cl_petsc_PetscObject_mt_view_L_LP_cl_petsc_Viewer_LP_JA_jint(
  cl_petsc_PetscObject *me, cl_petsc_Viewer *viewer, JA_jint *error)
{
  check(PetscObjectView(unwrap(me), viewer ? unview(viewer) : 0), error);
}


/*
 * Local variables:
 * c-file-style: "gnu"
 * c-file-offsets: ((arglist-intro . +))
 * End:
 */
