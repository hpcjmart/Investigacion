#include <viewer.h>
#include "check.h"
#include "layout!JA_jbyte.h"
#include "layout!cl_petsc_Comm.h"


#define unwrap(me)    ((Viewer) (me)->cl_petsc_PetscObject_fld_handle)
#define uncomm(comm)  ((MPI_Comm) (comm).cl_petsc_Comm_fld_handle)


cl_petsc_Opaque *cl_petsc_ViewerASCII_mt_getFileRaw_L_LP_JA_jint(
  cl_petsc_ViewerASCII *me, JA_jint *error)
{
  FILE *file;
  check(ViewerASCIIGetPointer(unwrap(me), &file), error);
  return (cl_petsc_Opaque *) file;
};
  

cl_petsc_Opaque *cl_petsc_ViewerASCII_mt_openRaw_cl_petsc_Comm_LP_JA_jbyte_LP_JA_jint(
  cl_petsc_Comm comm, JA_jbyte *name, JA_jint *error)
{
  Viewer viewer;
  check(ViewerASCIIOpen(uncomm(comm), name->data, &viewer), error);
  return (cl_petsc_Opaque *) viewer;
};
  

cl_petsc_Opaque *cl_petsc_ViewerASCII_mt_openRaw_cl_petsc_Comm_jint(
  cl_petsc_Comm comm, jint number)
{
  Viewer viewer;

  switch (number) {
  case 1:
    viewer = VIEWER_STDOUT_(uncomm(comm));
    break;
  case 2:
    viewer = VIEWER_STDERR_(uncomm(comm));
    break;
  default:
    // ??? should probably throw an IllegalArgumentException
    viewer = 0;
  }

  return (cl_petsc_Opaque *) viewer;
};
  

/*
 * Local variables:
 * c-file-style: "gnu"
 * c-file-offsets: ((arglist-intro . +))
 * End:
 */
