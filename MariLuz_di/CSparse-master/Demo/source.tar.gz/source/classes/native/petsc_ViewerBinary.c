#include <viewer.h>
#include "check.h"
#include "layout!JA_jbyte.h"
#include "layout!JA_jint.h"
#include "layout!cl_java_io_FileDescriptor.h"
#include "layout!cl_petsc_Comm.h"


typedef cl_java_io_FileDescriptor FileDesc;

#define unwrap(me)    ((Viewer) (me)->cl_petsc_PetscObject_fld_handle)
#define uncomm(comm)  ((MPI_Comm) (comm).cl_petsc_Comm_fld_handle)


cl_petsc_Opaque *cl_petsc_ViewerBinary_mt_open_cl_petsc_Comm_LP_JA_jbyte_jint_LP_JA_jint(
  cl_petsc_Comm comm, JA_jbyte *bytes, jint type, JA_jint *error)
{
  Viewer viewer;
  check(ViewerBinaryOpen(uncomm(comm), bytes->data, type, &viewer), error);
  return (cl_petsc_Opaque *) viewer;
};


FileDesc *cl_petsc_ViewerBinary_mt_getDescriptor_L_LP_JA_jint(
  cl_petsc_ViewerBinary *me, JA_jint *error)
{
  int fd;
  FileDesc *desc;
  
  check(ViewerBinaryGetDescriptor(unwrap(me), &fd), error);
  
  desc = (FileDesc *) ti_malloc(sizeof(FileDesc));
  cl_java_io_FileDescriptor_mt_FileDescriptor(desc);    
  desc->cl_java_io_FileDescriptor_fld_fd = fd;
  
  return desc;
}
  

/*
 * Local variables:
 * c-file-style: "gnu"
 * c-file-offsets: ((arglist-intro . +))
 * End:
 */
