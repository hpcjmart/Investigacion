#include <pc.h>
#include <vec.h>
#include "check.h"
#include "layout!JA_jbyte.h"
#include "layout!JA_jint.h"

#define unwrap(me) ((PC) (me)->cl_petsc_PetscObject_fld_handle)


void cl_petsc_PC_mt_setTypeRaw_L_LP_JA_jbyte_LP_JA_jint(
    LP_cl_petsc_PC me, LP_JA_jbyte type, LP_JA_jint error
)
{
  check(PCSetType(unwrap(me), type->data), error);
}

LP_cl_java_lang_String cl_petsc_PC_mt_getType_L_LP_JA_jint(
    LP_cl_petsc_PC me, 
    LP_JA_jint error
)
{
  char *type;
  check(PCGetType(unwrap(me), &type), error);
  return java_string_build_8(type);
}
