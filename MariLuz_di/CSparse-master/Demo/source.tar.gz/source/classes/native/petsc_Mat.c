#include <mat.h>
#include <vec.h>
#include "check.h"
#include "layout!JA_jdouble.h"
#include "layout!JA_jint.h"
#include "layout!cl_petsc_Opaque.h"
#include "layout!cl_petsc_Vec.h"
#include "layout!cl_petsc_ViewerBinary.h"


#define unwrap(me) ((Mat) (me)->cl_petsc_PetscObject_fld_handle)
#define unwrapVec(me) ((Vec) (me)->cl_petsc_PetscObject_fld_handle)
#define unwrapViewer(me)  ((Viewer) (me)->cl_petsc_PetscObject_fld_handle)

void cl_petsc_Mat_mt_assemblyBegin_L_jint_LP_JA_jint(
    LP_cl_petsc_Mat me, jint type, LP_JA_jint error
)
{
  check(MatAssemblyBegin(unwrap(me), type), error);
}

void cl_petsc_Mat_mt_assemblyEnd_L_jint_LP_JA_jint(
    LP_cl_petsc_Mat me, jint type, LP_JA_jint error
)
{
  check(MatAssemblyEnd(unwrap(me), type), error);
}

void cl_petsc_Mat_mt_setValues_L_jint_LP_JA_jint_jint_LP_JA_jint_LP_JA_jdouble_jint_LP_JA_jint(
       cl_petsc_Mat *me, jint m, JA_jint *idxm,
       jint n, JA_jint *idxn, JA_jdouble *v, 
       jint addv, JA_jint *error)
{
  check(MatSetValues(unwrap(me), m, idxm->data, n, idxn->data, v->data, addv), 
	error);
}

void cl_petsc_Mat_mt_setValue_L_jint_jint_jdouble_jint_LP_JA_jint(
       cl_petsc_Mat *me, jint row, jint col, 
       jdouble value, jint addv, JA_jint *error)
{
  check(MatSetValues(unwrap(me), 1, &row, 1, &col, &value, addv), error);
}
  
  
LP_cl_petsc_Opaque cl_petsc_Mat_mt_createMPIAIJ_jint_jint_jint_jint_jint_LP_JA_jint_jint_LP_JA_jint_LP_JA_jint(
       jint m, jint n, jint M, jint N, jint d_nz,
       JA_jint *d_nnz, jint o_nz, JA_jint *o_nnz, 
       JA_jint *error)
{
  Mat matrix;
  int *d_indices, *nd_indices;
  d_indices = d_nnz ? d_nnz->data : NULL;
  nd_indices = o_nnz ? o_nnz->data : NULL;
  check(MatCreateMPIAIJ(PETSC_COMM_WORLD, m, n, M, N, d_nz, d_indices,
		  o_nz, nd_indices, &matrix), error);
  return (cl_petsc_Opaque *) matrix;
}

LP_cl_petsc_Opaque cl_petsc_Mat_mt_createSeqAIJ_jint_jint_jint_LP_JA_jint_LP_JA_jint(
	jint m, jint n, jint nz, 
	JA_jint *nnz,
	JA_jint *error)
{
  Mat matrix;
  int *indices;
  indices = nnz ? nnz->data : NULL;
  check(MatCreateSeqAIJ(PETSC_COMM_SELF, m, n, nz, indices, &matrix),
	error);
  return (cl_petsc_Opaque *) matrix;
}

LP_cl_petsc_Opaque cl_petsc_Mat_mt_load_LP_cl_petsc_ViewerBinary_jint_LP_JA_jint(
        cl_petsc_ViewerBinary *v,
	jint mattype,
	JA_jint *error) 
{
  Mat matrix;
  check(MatLoad(unwrapViewer(v), mattype, &matrix), error);
  return(cl_petsc_Opaque *) matrix;
}

void cl_petsc_Mat_mt_mult_L_LP_cl_petsc_Vec_LP_cl_petsc_Vec_LP_JA_jint(
        LP_cl_petsc_Mat me,
        LP_cl_petsc_Vec x, LP_cl_petsc_Vec y,
	JA_jint *error) 
{
  check(MatMult(unwrap(me), unwrapVec(x), unwrapVec(y)), error);
}

void cl_petsc_Mat_mt_multAdd_L_LP_cl_petsc_Vec_LP_cl_petsc_Vec_LP_cl_petsc_Vec_LP_JA_jint(
  LP_cl_petsc_Mat me, 
  LP_cl_petsc_Vec v1,
  LP_cl_petsc_Vec v2, 
  LP_cl_petsc_Vec r, 
  LP_JA_jint error
)
{
  check(MatMultAdd(unwrap(me), unwrapVec(v1), unwrapVec(v2), unwrapVec(r)), 
	error);
}

void cl_petsc_Mat_mt_multTrans_L_LP_cl_petsc_Vec_LP_cl_petsc_Vec_LP_JA_jint(
  LP_cl_petsc_Mat me, 
  LP_cl_petsc_Vec x, 
  LP_cl_petsc_Vec y, 
  LP_JA_jint error
)
{
  check(MatMultTrans(unwrap(me), unwrapVec(x), unwrapVec(y)), error);
}


void cl_petsc_Mat_mt_multTransAdd_L_LP_cl_petsc_Vec_LP_cl_petsc_Vec_LP_cl_petsc_Vec_LP_JA_jint(
  cl_petsc_Mat *me, cl_petsc_Vec *v1,
  cl_petsc_Vec *v2, cl_petsc_Vec *v3,
  JA_jint *error
)
{
  check(MatMultTransAdd(unwrap(me), unwrapVec(v1),
			unwrapVec(v2), unwrapVec(v3)),
	error);
}


LP_cl_petsc_Opaque cl_petsc_Mat_mt_transposeRaw_L_LP_JA_jint(
  LP_cl_petsc_Mat me,
  LP_JA_jint error
)
{
  Mat mat;
  check(MatTranspose(unwrap(me), &mat), error);
  return (LP_cl_petsc_Opaque)mat;
}

void cl_petsc_Mat_mt_transposeRawInPlace_L_LP_JA_jint(
  LP_cl_petsc_Mat me, 
  LP_JA_jint error
)
{
  check(MatTranspose(unwrap(me), NULL), error);
}

LP_cl_petsc_Opaque cl_petsc_Mat_mt_duplicateRaw_LP_cl_petsc_Mat_jboolean_LP_JA_jint(
    LP_cl_petsc_Mat m, 
    jboolean copyValues, 
    LP_JA_jint error
)
{
  Mat newMat;
  check(MatDuplicate(unwrap(m), 
		     (copyValues ? MAT_COPY_VALUES : MAT_DO_NOT_COPY_VALUES),
		     &newMat), error);
  return (LP_cl_petsc_Opaque)newMat; 
}

/*
 * Local variables:
 * c-file-style: "gnu"
 * c-file-offsets: ((arglist-intro . +))
 * End:
 */
