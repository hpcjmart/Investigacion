#include <petsc.h>
#include "check.h"


cl_petsc_Opaque *cl_petsc_Comm_mt_createSelfRaw()
{
  return (cl_petsc_Opaque *) PETSC_COMM_SELF;
}


cl_petsc_Opaque *cl_petsc_Comm_mt_createWorldRaw()
{
  return (cl_petsc_Opaque *) PETSC_COMM_WORLD;
}


/*
 * Local variables:
 * c-file-style: "gnu"
 * End:
 */
