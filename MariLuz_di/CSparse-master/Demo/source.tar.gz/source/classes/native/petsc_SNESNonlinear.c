#include <snes.h>
#include "check.h"
#include "enshroud.h"

#include "cl_petsc_Vec.h"

#define uncomm(comm)  ((MPI_Comm) (comm).cl_petsc_Comm_fld_handle)
#define unvec(vec)    ((Vec)  (vec)->cl_petsc_PetscObject_fld_handle)
#define unwrap(me)    ((SNES) (me )->cl_petsc_PetscObject_fld_handle)

#define STATIC(field) (STATIC_REF(cl_petsc_SNESNonlinear_fld_ ## field))


/**********************************************************************/


static int upcallFunction(SNES snes, Vec x, Vec f, void *context)
{
  cl_petsc_SNESNonlinear * const me = (cl_petsc_SNESNonlinear *) context;
  *STATIC(error)->data = 0;
  
  me->class_info->_mt_function_L_LP_cl_petsc_Vec_LP_cl_petsc_Vec_LP_JA_jint(
    me, enshroud(x, Vec), enshroud(f, Vec), STATIC(error));
  
  return *STATIC(error)->data;
}


/**********************************************************************/


cl_petsc_Opaque *cl_petsc_SNESNonlinear_mt_createRaw_cl_petsc_Comm_LP_JA_jint(
  cl_petsc_Comm comm, JA_jint *error)
{
  SNES solver;
  check(SNESCreate(uncomm(comm), SNES_NONLINEAR_EQUATIONS, &solver), error);
  return (cl_petsc_Opaque *) solver;
}


void cl_petsc_SNESNonlinear_mt_setFunction_L_LP_cl_petsc_Vec_LP_JA_jint(
  cl_petsc_SNESNonlinear *me, cl_petsc_Vec *r, JA_jint *error)
{
  check(SNESSetFunction(unwrap(me), unvec(r),
			upcallFunction, me),
	error);
}


/*
 * Local variables:
 * c-file-style: "gnu"
 * c-file-offsets: ((arglist-intro . +))
 * End:
 */
