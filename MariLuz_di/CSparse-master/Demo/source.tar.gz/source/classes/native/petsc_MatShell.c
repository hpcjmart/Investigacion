#include <mat.h>
#include "check.h"
#include "enshroud.h"

#include "cl_petsc_Vec.h"
#include "layout!JA_jint.h"


#define uncomm(comm)  ((MPI_Comm) (comm).cl_petsc_Comm_fld_handle)
#define STATIC(field) (STATIC_REF(cl_petsc_MatShell_fld_ ## field))


/**********************************************************************/


static int upcallMult(Mat mat, Vec x, Vec y)
{
  cl_petsc_MatShell * const me = (cl_petsc_MatShell *) ((PetscObject) mat)->cpp;
  *STATIC(error)->data = 0;
  
  me->class_info->_mt_mult_L_LP_cl_petsc_Vec_LP_cl_petsc_Vec_LP_JA_jint(
    me, enshroud(x, Vec), enshroud(y, Vec), STATIC(error));

  return *STATIC(error)->data;
}


static int upcallMultTransAdd(Mat mat, Vec v1, Vec v2, Vec v3)
{
  cl_petsc_MatShell * const me = (cl_petsc_MatShell *) ((PetscObject) mat)->cpp;
  *STATIC(error)->data = 0;
  
  me->class_info->_mt_multTransAdd_L_LP_cl_petsc_Vec_LP_cl_petsc_Vec_LP_cl_petsc_Vec_LP_JA_jint(
    me, enshroud(v1, Vec), enshroud(v2, Vec), enshroud(v3, Vec), STATIC(error));

  return *STATIC(error)->data;
}


struct {
  MatOperation code;
  void *handler;
} upcalls[] = {
  { MATOP_MULT,           upcallMult },
  { MATOP_MULT_TRANS_ADD, upcallMultTransAdd }
};


/**********************************************************************/


cl_petsc_Opaque *cl_petsc_MatShell_mt_createRaw_L_cl_petsc_Comm_jint_jint_jint_jint_LP_JA_jint(
  cl_petsc_MatShell *me, cl_petsc_Comm comm, jint m, jint n, jint M, jint N, JA_jint *error)
{
  int op;
  Mat matrix;
  check(MatCreateShell(uncomm(comm), m, n, M, N, me, &matrix), error);

  for (op = sizeof(upcalls) / sizeof(*upcalls); op--; )
    check(MatShellSetOperation(matrix, upcalls[op].code, upcalls[op].handler), error);

  return (cl_petsc_Opaque *) matrix;
}


/*
 * Local variables:
 * c-file-style: "gnu"
 * c-file-offsets: ((arglist-intro . +))
 * End:
 */
