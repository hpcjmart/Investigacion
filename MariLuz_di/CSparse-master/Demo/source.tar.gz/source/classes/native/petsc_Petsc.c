#include <petsc.h>
#include "check.h"
#include "mpi-init.h"
#include "layout!JA_LP_JA_jbyte.h"
#include "layout!JA_jbyte.h"


static int *cooperate = &MPI_cooperates_with_Split_C;


void cl_petsc_Petsc_mt_initialize_jint_LP_JA_LP_JA_jbyte_LP_JA_jbyte_LP_JA_jbyte_LP_JA_jint(
  jint argc, JA_LP_JA_jbyte *argv, JA_jbyte *file, JA_jbyte *help, JA_jint *error)
{
  // skip over the byte array headers and extract the data
  jbyte **raw = (jbyte **) ti_malloc(argc * sizeof(*raw));
  int scan;  
  for (scan = 0; scan < argc; ++scan)
    raw[scan] = argv->data[scan]->data;

  // call down to real initialize routine
  check(PetscInitialize(&argc, (char ***) &raw,
			file ? file->data : 0,
			help ? help->data : 0),
	error);

  // The calling signature for PetscInitialize() suggests that it
  // updates argc and argv after extracting any command-line options.
  // In fact, argc and argv are left unchanged.  So we don't need to
  // pass anything back up to the caller except for the error code.
}


void cl_petsc_Petsc_mt_finish_LP_JA_jint(JA_jint *error)
{
  check(PetscFinalize(), error);
}


/*
 * Local variables:
 * c-file-style: "gnu"
 * c-file-offsets: ((arglist-intro . +))
 * End:
 */
