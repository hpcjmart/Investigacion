#include <vec.h>
#include "check.h"
#include "layout!cl_petsc_IS.h"
#include "layout!cl_petsc_Vec.h"


#define unwrap(me)  ((VecScatter) (me )->cl_petsc_PetscObject_fld_handle)
#define unvec(vec)  ((Vec)        (vec)->cl_petsc_PetscObject_fld_handle)
#define unis(is)    ((IS)         (is )->cl_petsc_PetscObject_fld_handle)


void cl_petsc_VecScatter_mt_begin_L_LP_cl_petsc_Vec_LP_cl_petsc_Vec_jint_jint_LP_JA_jint(
  cl_petsc_VecScatter *me, cl_petsc_Vec *x, cl_petsc_Vec *y, jint addv, jint mode, JA_jint *error)
{
  check(VecScatterBegin(unvec(x), unvec(y), addv, mode, unwrap(me)), error);
}


cl_petsc_Opaque *cl_petsc_VecScatter_mt_createRaw_LP_cl_petsc_Vec_LP_cl_petsc_IS_LP_cl_petsc_Vec_LP_cl_petsc_IS_LP_JA_jint(
  cl_petsc_Vec *xin, cl_petsc_IS *ix,
  cl_petsc_Vec *yin, cl_petsc_IS *iy,
  JA_jint *error)
{
  VecScatter result;
  
  check(VecScatterCreate(unvec(xin), unis(ix),
			 unvec(yin), unis(iy),
			 &result),
	error);
  return (cl_petsc_Opaque *) result;
}


void cl_petsc_VecScatter_mt_end_L_LP_cl_petsc_Vec_LP_cl_petsc_Vec_jint_jint_LP_JA_jint(
  cl_petsc_VecScatter *me, cl_petsc_Vec *x, cl_petsc_Vec *y, jint addv, jint mode, JA_jint *error)
{
  check(VecScatterEnd(unvec(x), unvec(y), addv, mode, unwrap(me)), error);
}


/*
 * Local variables:
 * c-file-style: "gnu"
 * c-file-offsets: ((arglist-intro . +))
 * End:
 */
