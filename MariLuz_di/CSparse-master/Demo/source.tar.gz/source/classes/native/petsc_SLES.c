#include <snes.h>
#include "check.h"
#include "enshroud.h"

#include "cl_petsc_PC.h"
#include "layout!cl_petsc_MatBase.h"
#include "layout!JA_jbyte.h"
#include "layout!JA_jint.h"


#define unwrap(me)    ((SLES) (me )->cl_petsc_PetscObject_fld_handle)
#define unmat(mat)    ((Mat)  (mat)->cl_petsc_PetscObject_fld_handle)


cl_petsc_PC *cl_petsc_SLES_mt_getPC_L_LP_JA_jint(
  cl_petsc_SLES *me, JA_jint *error)
{
  PC pc;
  check(SLESGetPC(unwrap(me), &pc), error);
  
  return enshroud(pc, PC);
}


void cl_petsc_SLES_mt_setFromOptions_L_LP_JA_jint(
  cl_petsc_SLES *me, JA_jint *error)
{
  check(SLESSetFromOptions(unwrap(me)), error);
}


void cl_petsc_SLES_mt_setOperators_L_LP_cl_petsc_MatBase_LP_cl_petsc_MatBase_jint_LP_JA_jint(
  cl_petsc_SLES *me, cl_petsc_MatBase *Amat, cl_petsc_MatBase *Pmat, jint flag, JA_jint *error)
{
  check(SLESSetOperators(unwrap(me), unmat(Amat), unmat(Pmat), flag), error);
}


void cl_petsc_SLES_mt_setOptionsPrefixRaw_L_LP_JA_jbyte_LP_JA_jint(
  cl_petsc_SLES *me, JA_jbyte *prefix, JA_jint *error)
{
  check(SLESSetOptionsPrefix(unwrap(me),
			     prefix ? prefix->data : 0),
	error);
}


/*
 * Local variables:
 * c-file-style: "gnu"
 * c-file-offsets: ((arglist-intro . +))
 * End:
 */
