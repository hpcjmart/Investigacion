#include <sys.h>
#include "check.h"
#include "layout!JA_jint.h"


#define uncomm(comm)  ((MPI_Comm) (comm).cl_petsc_Comm_fld_handle)


cl_petsc_Opaque *cl_petsc_PetscRandom_mt_createRaw_cl_petsc_Comm_LP_JA_jint(
  cl_petsc_Comm comm, JA_jint *error)
{
  PetscRandom generator;
  check(PetscRandomCreate(uncomm(comm), RANDOM_DEFAULT, &generator), error);
  return (cl_petsc_Opaque *) generator;
}


/*
 * Local variables:
 * c-file-style: "gnu"
 * c-file-offsets: ((arglist-intro . +))
 * End:
 */
