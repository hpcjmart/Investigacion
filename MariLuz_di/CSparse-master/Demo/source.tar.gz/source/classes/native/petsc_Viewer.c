#include <viewer.h>
#include "check.h"
#include "layout!JA_jbyte.h"


#define unwrap(me)  ((Viewer) (me)->cl_petsc_PetscObject_fld_handle)


void cl_petsc_Viewer_mt_popFormat_L_LP_JA_jint(cl_petsc_Viewer *me, JA_jint *error)
{
  check(ViewerPopFormat(unwrap(me)), error);
}


void cl_petsc_Viewer_mt_pushFormatRaw_L_jint_LP_JA_jbyte_LP_JA_jint(
  cl_petsc_Viewer *me, jint format, JA_jbyte *name, JA_jint *error)
{
  check(ViewerPushFormat(unwrap(me), format, name->data), error);
}


void cl_petsc_Viewer_mt_setFormatRaw_L_jint_LP_JA_jbyte_LP_JA_jint(
  cl_petsc_Viewer *me, jint format, JA_jbyte *name, JA_jint *error)
{
  check(ViewerSetFormat(unwrap(me), format, name->data), error);
}


/*
 * Local variables:
 * c-file-style: "gnu"
 * c-file-offsets: ((arglist-intro . +))
 * End:
 */
