#include <options.h>
#include "check.h"
#include "cl_petsc_Util.h"
#include "java_string.h"
#include "layout!JA_jbyte.h"
#include "layout!JA_jdouble.h"

/*
 * the longest allowable string option.  We have to be a bit
 * arbitrary, unfortunately, becase PETSc has no API for us to ask how
 * long the string really is.  Rather, it requires that we allocate
 * the space in advance.
 */
enum { MaxString = 4096 };


  
jboolean cl_petsc_Options_mt_getDoubleRaw_LP_JA_jbyte_LP_JA_jbyte_LP_JA_jdouble_LP_JA_jint(
  JA_jbyte *pre, JA_jbyte *name, JA_jdouble *dvalue, JA_jint *error)
{
  int found;
  check(OptionsGetDouble(pre ? pre->data : 0, name->data,
			 dvalue->data, &found),
	error);
  
  return found;
}


jboolean cl_petsc_Options_mt_getIntRaw_LP_JA_jbyte_LP_JA_jbyte_LP_JA_jint_LP_JA_jint(
  JA_jbyte *pre, JA_jbyte *name, JA_jint *ivalue, JA_jint *error)
{
  int found;
  check(OptionsGetInt(pre ? pre->data : 0, name->data,
		      ivalue->data, &found),
	error);
  
  return found;
}


cl_java_lang_String *cl_petsc_Options_mt_getString_GP_cl_java_lang_String_GP_cl_java_lang_String_LP_JA_jint(
  GP_cl_java_lang_String pre, GP_cl_java_lang_String name, JA_jint *error)
{
  int found;
  char bytes[MaxString];
  JA_jbyte *preRaw  = cl_petsc_Util_mt_getBytes_GP_cl_java_lang_String(pre);
  JA_jbyte *nameRaw = cl_petsc_Util_mt_getBytes_GP_cl_java_lang_String(name);
  
  check(OptionsGetString(preRaw ? preRaw->data : 0,
			 nameRaw->data,
			 bytes, MaxString, &found),
	error);

  return found ? java_string_build_8(bytes) : 0;
}


jboolean cl_petsc_Options_mt_hasNameRaw_LP_JA_jbyte_LP_JA_jbyte_LP_JA_jint(
  JA_jbyte *pre, JA_jbyte *name, JA_jint *error)
{
  int found;
  check(OptionsHasName(pre ? pre->data : 0, name->data, &found), error);
  
  return found;
}

/*
 * Local variables:
 * c-file-style: "gnu"
 * c-file-offsets: ((arglist-intro . +))
 * End:
 */
