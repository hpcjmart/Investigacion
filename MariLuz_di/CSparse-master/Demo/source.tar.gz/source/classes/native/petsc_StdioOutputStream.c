#include <stdio.h>
#include "layout!JA_jbyte.h"
#include "layout!LP_jint.h"
#include "layout!cl_java_io_FileDescriptor.h"
#include "native-file-utils.h"


typedef cl_java_io_FileDescriptor FileDesc;

#define handle      cl_petsc_StdioOutputStream_fld_handle
#define unwrap(me)  ((FILE *) (me)->handle)


void cl_petsc_StdioOutputStream_mt_close_G(GP_cl_petsc_StdioOutputStream globalMe)
{
  cl_petsc_StdioOutputStream *me;
  localize(me, globalMe);
  
  if (fclose(unwrap(me)) == EOF)
    tossIOException();

  me->handle = 0;
}


cl_petsc_Opaque *cl_petsc_StdioOutputStream_mt_fdopen_GP_cl_java_io_FileDescriptor(
  GP_cl_java_io_FileDescriptor globalDesc)
{
  FILE *file;
  FileDesc *desc;
  localize(desc, globalDesc);
  
  file = fdopen(desc->cl_java_io_FileDescriptor_fld_fd, "w");
  if (!file) tossIOException();
  
  return (cl_petsc_Opaque *) file;
}


void cl_petsc_StdioOutputStream_mt_flush_G(
  GP_cl_petsc_StdioOutputStream globalMe)
{
  cl_petsc_StdioOutputStream *me;
  localize(me, globalMe);
  
  if (fflush(unwrap(me)) == EOF)
    tossIOException();
}


FileDesc *cl_petsc_StdioOutputStream_mt_getDesc_LP_cl_petsc_Opaque(cl_petsc_Opaque *handle)
{
  FileDesc * const desc = (FileDesc *) ti_malloc(sizeof(FileDesc));
  cl_java_io_FileDescriptor_mt_FileDescriptor(desc);
  
  desc->cl_java_io_FileDescriptor_fld_fd = fileno((FILE *) handle);
  return desc;
}


cl_petsc_Opaque *cl_petsc_StdioOutputStream_mt_getStandardFile_jint(jint number)
{
  switch (number)
    {
    case 1:
      return (cl_petsc_Opaque *) stdout;
    case 2:
      return (cl_petsc_Opaque *) stderr;
    default:
      // ??? should probably throw an IllegalArgumentException
      return 0;
    }
}


void cl_petsc_StdioOutputStream_mt_write_G_jint(
  GP_cl_petsc_StdioOutputStream globalMe, jint datum)
{
  cl_petsc_StdioOutputStream *me;
  localize(me, globalMe);
  
  if (fputc(datum, unwrap(me)) == EOF)
    tossIOException();
}


void cl_petsc_StdioOutputStream_mt_write_G_GP_JA_jbyte_jint_jint(
  GP_cl_petsc_StdioOutputStream globalMe, GP_JA_jbyte globalData,
  jint offset, jint length)
{
  cl_petsc_StdioOutputStream *me;
  JA_jbyte *data;

  localize(me, globalMe);
  localize(data, globalData);
  JAVA_ARRAY_CHECK_LOCAL(data, offset, length);
  
  if (fwrite(data->data + offset, sizeof(jbyte), length, unwrap(me)) == EOF)
    tossIOException();
}


/*
 * Local variables:
 * c-file-style: "gnu"
 * c-file-offsets: ((arglist-intro . +))
 * End:
 */
