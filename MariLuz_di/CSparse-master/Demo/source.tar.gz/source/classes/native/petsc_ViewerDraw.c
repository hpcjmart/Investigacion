#include <viewer.h>
#include "check.h"
#include "layout!JA_jbyte.h"
#include "layout!cl_petsc_Comm.h"


#define uncomm(comm)  ((MPI_Comm) (comm).cl_petsc_Comm_fld_handle)


cl_petsc_Opaque *cl_petsc_ViewerDraw_mt_openRaw_cl_petsc_Comm(cl_petsc_Comm comm)
{
  return (cl_petsc_Opaque *) VIEWER_DRAWX_(uncomm(comm));
}


cl_petsc_Opaque *cl_petsc_ViewerDraw_mt_openVRMLRaw_cl_petsc_Comm_LP_JA_jbyte_LP_JA_jint(
  cl_petsc_Comm comm, JA_jbyte *name, JA_jint *error)
{
  Viewer viewer;
  check(ViewerDrawOpenVRML(uncomm(comm), name->data, 0, &viewer), error);

  return (cl_petsc_Opaque *) viewer;
}
  

cl_petsc_Opaque *cl_petsc_ViewerDraw_mt_openXRaw_cl_petsc_Comm_LP_JA_jbyte_LP_JA_jbyte_jint_jint_jint_jint_LP_JA_jint(
  cl_petsc_Comm comm, JA_jbyte *display, JA_jbyte *title,
  jint x, jint y, jint w, jint h, JA_jint *error)
{
  Viewer viewer;
  check(ViewerDrawOpenX(uncomm(comm),
			display ? display->data : 0,
			title ? title->data : 0,
			x, y, w, h, &viewer),
	error);

  return (cl_petsc_Opaque *) viewer;
}


/*
 * Local variables:
 * c-file-style: "gnu"
 * c-file-offsets: ((arglist-intro . +))
 * End:
 */
