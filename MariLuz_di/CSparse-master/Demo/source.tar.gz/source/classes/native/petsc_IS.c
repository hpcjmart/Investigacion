#include <is.h>
#include "check.h"
#include "layout!JA_jint.h"
#include "layout!cl_petsc_Comm.h"


#define uncomm(comm)  ((MPI_Comm) (comm).cl_petsc_Comm_fld_handle)


cl_petsc_Opaque *cl_petsc_IS_mt_createBlockRaw_cl_petsc_Comm_jint_LP_JA_jint_LP_JA_jint(
  cl_petsc_Comm comm, int bs, JA_jint *idx, JA_jint *error)
{
  IS result;
  check(ISCreateBlock(uncomm(comm), bs,
		      idx->header.length,
		      idx->data, &result),
	error);
  
  return (cl_petsc_Opaque *) result;
}


cl_petsc_Opaque *cl_petsc_IS_mt_createGeneralRaw_cl_petsc_Comm_LP_JA_jint_LP_JA_jint(
  cl_petsc_Comm comm, JA_jint *idx, JA_jint *error)
{
  IS result;
  check(ISCreateGeneral(uncomm(comm),
		      idx->header.length,
		      idx->data, &result),
	error);
  
  return (cl_petsc_Opaque *) result;
}


cl_petsc_Opaque *cl_petsc_IS_mt_createStrideRaw_cl_petsc_Comm_jint_jint_jint_LP_JA_jint(
  cl_petsc_Comm comm, jint n, jint first, jint step, JA_jint *error)
{
  IS result;
  check(ISCreateStride(uncomm(comm), n, first, step, &result), error);
  
  return (cl_petsc_Opaque *) result;
}


/*
 * Local variables:
 * c-file-style: "gnu"
 * c-file-offsets: ((arglist-intro . +))
 * End:
 */
