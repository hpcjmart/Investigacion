#include <vec.h>
#include "check.h"
#include "layout!cl_petsc_Opaque.h"
#include "layout!cl_petsc_PetscRandom.h"
#include "layout!JA_LP_cl_petsc_Opaque.h"
#include "layout!JA_jdouble.h"
#include "layout!JA_jint.h"
#include "ti_array_flags.h"
#include "layout!TI_ARR_jdouble_1.h"


#undef CHKERRQ
#define CHKERRQ(error) CHKERRA(error)


typedef TI_ARR_jdouble_1 Array;

#define unwrap(me)    ((Vec)         (me  )->cl_petsc_PetscObject_fld_handle)
#define unrand(rand)  ((PetscRandom) (rand)->cl_petsc_PetscObject_fld_handle)


void cl_petsc_Vec_mt_abs_L_LP_JA_jint(cl_petsc_Vec *me, JA_jint *error)
{
  check(VecAbs(unwrap(me)), error);
}


void cl_petsc_Vec_mt_axpby_L_jdouble_jdouble_LP_cl_petsc_Vec_LP_JA_jint(
  cl_petsc_Vec *me, jdouble alpha, jdouble beta, cl_petsc_Vec *x, JA_jint *error)
{
  check(VecAXPBY(&alpha, &beta, unwrap(x), unwrap(me)), error);
}

void cl_petsc_Vec_mt_axpy_L_jdouble_LP_cl_petsc_Vec_LP_JA_jint(
  cl_petsc_Vec *me, jdouble alpha, cl_petsc_Vec *x, JA_jint *error)
{
  check(VecAXPY(&alpha, unwrap(x), unwrap(me)), error);
}


void cl_petsc_Vec_mt_aypx_L_jdouble_LP_cl_petsc_Vec_LP_JA_jint(
  cl_petsc_Vec *me, jdouble alpha, cl_petsc_Vec *x, JA_jint *error)
{
  check(VecAYPX(&alpha, unwrap(x), unwrap(me)), error);
}


void cl_petsc_Vec_mt_copy_L_LP_cl_petsc_Vec_LP_JA_jint(
  cl_petsc_Vec *me, cl_petsc_Vec *y, JA_jint *error)
{
  check(VecCopy(unwrap(me), unwrap(y)), error);
}


cl_petsc_Opaque *cl_petsc_Vec_mt_createMPIRaw_jint_jint_LP_JA_jint(jint n, jint N, JA_jint *error)
{
  Vec vector;
  check(VecCreateMPI(PETSC_COMM_WORLD, n, N, &vector), error);
  return (cl_petsc_Opaque *) vector;
}


cl_petsc_Opaque *cl_petsc_Vec_mt_createSeqRaw_jint_LP_JA_jint(jint n, JA_jint *error)
{
  Vec vector;
  check(VecCreateSeq(PETSC_COMM_SELF, n, &vector), error);
  return (cl_petsc_Opaque *) vector;
}


jdouble cl_petsc_Vec_mt_dot_L_LP_cl_petsc_Vec_LP_JA_jint(
  cl_petsc_Vec *me, cl_petsc_Vec *y, JA_jint *error)
{
  double result;
  check(VecDot(unwrap(me), unwrap(y), &result), error);
  return result;
}


cl_petsc_Opaque *cl_petsc_Vec_mt_duplicateRaw_L_LP_JA_jint(
  cl_petsc_Vec *me, JA_jint *error)
{
  Vec mimic;
  check(VecDuplicate(unwrap(me), &mimic), error);
  return (cl_petsc_Opaque *) mimic;
}


Array cl_petsc_Vec_mt_getArrayRaw_L_cl_ti_domains_tiRectDomain1_LP_JA_jint(
  cl_petsc_Vec *me, cl_ti_domains_tiRectDomain1 domain, JA_jint *error)
{
  Array array;
  check(VecGetArray(unwrap(me), &array.A), error);

#if DUMPABLE_ARRAYS
  array.dumpfn = _ti_DUMP(jdouble, 1);
#endif
  array.domain = domain;
  array.stride[0] = 1;
  array.base[0] = 0;
  array.sideFactors[0] = 1;
  array.ancestor = array.A;
  array.where = "petsc.Vec.getArrayRaw()";
#if EXPLICITLY_STORE_CREATOR
  array.creator = MYPROC;
#endif

  return array;
}


int cl_petsc_Vec_mt_getLocalSize_L_LP_JA_jint(cl_petsc_Vec *me, JA_jint *error)
{
  int size;
  check(VecGetLocalSize(unwrap(me), &size), error);
  return size;
}


void cl_petsc_Vec_mt_getOwnershipRange_L_LP_JA_jint_LP_JA_jint_LP_JA_jint(
  cl_petsc_Vec *me, JA_jint *low, JA_jint *high, JA_jint *error)
{
  check(VecGetOwnershipRange(unwrap(me),
			     low ? low->data : 0,
			     high ? high->data : 0),
	error);
}


int cl_petsc_Vec_mt_getSize_L_LP_JA_jint(cl_petsc_Vec *me, JA_jint *error)
{
  int size;
  check(VecGetSize(unwrap(me), &size), error);
  return size;
}


void cl_petsc_Vec_mt_maxpyRaw_L_LP_JA_jdouble_LP_JA_LP_cl_petsc_Opaque_LP_JA_jint(
  cl_petsc_Vec *me, JA_jdouble *alpha, JA_LP_cl_petsc_Opaque *y, JA_jint *error)
{
  cl_petsc_Opaque ** const handles = y->data;
  Vec * const vectors = (Vec *) handles;
  
  check(VecMAXPY(y->header.length, alpha->data,
		 unwrap(me), vectors),
	error);
}


void cl_petsc_Vec_mt_mDotRaw_L_LP_JA_LP_cl_petsc_Opaque_LP_JA_jdouble_LP_JA_jint(
  cl_petsc_Vec *me, JA_LP_cl_petsc_Opaque *y, JA_jdouble *val, JA_jint *error)
{
  cl_petsc_Opaque ** const handles = y->data;
  Vec * const vectors = (Vec *) handles;
  
  check(VecMDot(y->header.length, unwrap(me), vectors, val->data), error);
}


jdouble cl_petsc_Vec_mt_norm_L_jint_LP_JA_jint(cl_petsc_Vec *me, jint type, JA_jint *error)
{
  double result;
  check(VecNorm(unwrap(me), type, &result), error);
  return result;
}


void cl_petsc_Vec_mt_norm1and2_L_LP_JA_jdouble_LP_JA_jint(
  cl_petsc_Vec *me, JA_jdouble *norms, JA_jint *error)
{
  JAVA_ARRAY_CHECK_LOCAL(norms, 0, 2);
  check(VecNorm(unwrap(me), NORM_1_AND_2, norms->data), error);
}


void cl_petsc_Vec_mt_pointwiseMult_L_LP_cl_petsc_Vec_LP_cl_petsc_Vec_LP_JA_jint(
  cl_petsc_Vec *me, cl_petsc_Vec *x, cl_petsc_Vec *y, JA_jint *error)
{
  check(VecPointwiseMult(unwrap(x), unwrap(y), unwrap(me)), error);
}


void cl_petsc_Vec_mt_reciprocal_L_LP_JA_jint(cl_petsc_Vec *me, JA_jint *error)
{
  check(VecReciprocal(unwrap(me)), error);
}


void cl_petsc_Vec_mt_restoreArray_L_TI_ARR_jdouble_1_LP_JA_jint(
  cl_petsc_Vec *me, TI_ARR_jdouble_1 array, JA_jint *error)
{
  check(VecRestoreArray(unwrap(me), &array.A), error);

  /*
   * At this point we would like to clear out the caller's copy of the
   * descriptor to forbid further use of the raw array.  Sadly, the
   * only way to do that would be to add an extra layer of
   * indirection.  That would require making the "array" parameter be
   * a local one-element Java array of local Titanium array
   * descriptors.  Ick.  For the time being, let's just trust the
   * caller to behave.
   */
}


void cl_petsc_Vec_mt_scale_L_jdouble_LP_JA_jint(cl_petsc_Vec *me, jdouble alpha, JA_jint *error)
{
  check(VecScale(&alpha, unwrap(me)), error);
}


void cl_petsc_Vec_mt_set_L_jdouble_LP_JA_jint(
  cl_petsc_Vec *me, jdouble alpha, JA_jint *error)
{
  check(VecSet(&alpha, unwrap(me)), error);
}


void cl_petsc_Vec_mt_setRandom_L_LP_cl_petsc_PetscRandom_LP_JA_jint(
  cl_petsc_Vec *me, cl_petsc_PetscRandom *rctx, JA_jint *error)
{
  check(VecSetRandom(unrand(rctx), unwrap(me)), error);
}


void cl_petsc_Vec_mt_setValue_L_jint_jdouble_jint(
  cl_petsc_Vec *me, jint row, jdouble value, jint mode)
{
  VecSetValue(unwrap(me), row, value, mode);
}


jdouble cl_petsc_Vec_mt_sum_L_LP_JA_jint(cl_petsc_Vec *me, JA_jint *error)
{
  double result;
  check(VecSum(unwrap(me), &result), error);
  return result;
}


void cl_petsc_Vec_mt_waxpy_L_jdouble_LP_cl_petsc_Vec_LP_cl_petsc_Vec_LP_JA_jint(
  cl_petsc_Vec *me, jdouble alpha, cl_petsc_Vec *x, cl_petsc_Vec *y, JA_jint *error)
{
  check(VecWAXPY(&alpha, unwrap(x), unwrap(y), unwrap(me)), error);
}


/*
 * Local variables:
 * c-file-style: "gnu"
 * c-file-offsets: ((arglist-intro . +))
 * End:
 */
