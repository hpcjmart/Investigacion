#include <da.h>
#include <vec.h>
#include "check.h"
#include "layout!JA_jdouble.h"
#include "layout!JA_jint.h"
#include "layout!cl_petsc_Opaque.h"
#include "layout!cl_petsc_Vec.h"
#include "layout!cl_petsc_DA.h"


#define unwrap(me) ((DA) (me)->cl_petsc_PetscObject_fld_handle)
#define unwrapVec(me) ((Vec) (me)->cl_petsc_PetscObject_fld_handle)
#define unwrapViewer(me)  ((Viewer) (me)->cl_petsc_PetscObject_fld_handle)
#define unwrapComm(me) ((MPI_Comm) (me).cl_petsc_Comm_fld_handle)

LP_cl_petsc_Opaque cl_petsc_DA_mt_createGlobalVectorRaw_L_LP_JA_jint(
  LP_cl_petsc_DA me, 
  LP_JA_jint error
)
{
  Vec vec;
  check(DACreateGlobalVector(unwrap(me), &vec), error);
  return (LP_cl_petsc_Opaque)vec;
}

LP_cl_petsc_Opaque cl_petsc_DA_mt_create1d_cl_petsc_Comm_jint_jint_jint_jint_LP_JA_jint_LP_JA_jint(
  cl_petsc_Comm comm, jint wrap, jint M, jint dof, jint s, LP_JA_jint lc, 
  LP_JA_jint error
)
{
  DA da;
  check(DACreate1d(unwrapComm(comm), wrap, M, dof,
		   s, lc ? lc->data : 0, &da), error);
  return (LP_cl_petsc_Opaque)da;
}


LP_cl_petsc_Opaque cl_petsc_DA_mt_create2d_cl_petsc_Comm_jint_jint_jint_jint_jint_jint_jint_jint_LP_JA_jint_LP_JA_jint_LP_JA_jint(
  cl_petsc_Comm comm, jint wrap, jint stencil_type, jint M, jint N, jint m, 
  jint n, jint dof, jint s, LP_JA_jint lx, LP_JA_jint ly, LP_JA_jint error
)
{
  DA da;
  check(DACreate2d(unwrapComm(comm), wrap, stencil_type, M, N, m, n, dof, s,
		   lx ? lx->data : 0, ly ? ly->data : 0, &da), error);
  return (LP_cl_petsc_Opaque)da;
}

void cl_petsc_DA_mt_globalToLocalBegin_L_LP_cl_petsc_Vec_jint_LP_cl_petsc_Vec_LP_JA_jint(
  LP_cl_petsc_DA me, LP_cl_petsc_Vec g, jint mode, LP_cl_petsc_Vec l, 
  LP_JA_jint error
)
{
  check(DAGlobalToLocalBegin(unwrap(me), unwrapVec(g), mode, unwrapVec(l)), 
	error);
}
  
void cl_petsc_DA_mt_globalToLocalEnd_L_LP_cl_petsc_Vec_jint_LP_cl_petsc_Vec_LP_JA_jint(
    LP_cl_petsc_DA me, LP_cl_petsc_Vec g, jint mode, LP_cl_petsc_Vec l, 
    LP_JA_jint error
)
{
  check(DAGlobalToLocalEnd(unwrap(me), unwrapVec(g), mode, unwrapVec(l)), 
	error);
}

void cl_petsc_DA_mt_localToGlobal_L_LP_cl_petsc_Vec_jint_LP_cl_petsc_Vec_LP_JA_jint(
    LP_cl_petsc_DA me, LP_cl_petsc_Vec l, jint mode, LP_cl_petsc_Vec g, 
    LP_JA_jint error
)
{
  check(DALocalToGlobal(unwrap(me), unwrapVec(l), mode, unwrapVec(g)), error);
}

LP_cl_petsc_Opaque cl_petsc_DA_mt_createLocalVectorRaw_L_LP_JA_jint(
    LP_cl_petsc_DA me, LP_JA_jint error
)
{
  Vec v;
  check(DACreateLocalVector(unwrap(me), &v), error);
  return (LP_cl_petsc_Opaque)v;
}

void cl_petsc_DA_mt_getCorners_L_LP_JA_jint_LP_JA_jint_LP_JA_jint(
    LP_cl_petsc_DA me, LP_JA_jint corner,
    LP_JA_jint extent, LP_JA_jint error
)
{
  jint *corner0 = 0, *corner1 = 0, *corner2 = 0;
  jint *extent0 = 0, *extent1 = 0, *extent2 = 0;

  switch (corner->header.length) {
  case 3:
    corner2 = &corner->data[2];
  case 2:
    corner1 = &corner->data[1];
  case 1:
    corner0 = &corner->data[0];
  }
  
  switch (extent->header.length) {
  case 3:
    extent2 = &extent->data[2];
  case 2:
    extent1 = &extent->data[1];
  case 1:
    extent0 = &extent->data[0];
  }

  check(DAGetCorners(unwrap(me),
		     corner0, corner1, corner2,
		     extent0, extent1, extent2),
	error);
}

void cl_petsc_DA_mt_getGhostCorners_L_LP_JA_jint_LP_JA_jint_LP_JA_jint(
    LP_cl_petsc_DA me, LP_JA_jint corner,
    LP_JA_jint extent, LP_JA_jint error
)
{
  jint *corner0 = 0, *corner1 = 0, *corner2 = 0;
  jint *extent0 = 0, *extent1 = 0, *extent2 = 0;

  switch (corner->header.length) {
  case 3:
    corner2 = &corner->data[2];
  case 2:
    corner1 = &corner->data[1];
  case 1:
    corner0 = &corner->data[0];
  }
  
  switch (extent->header.length) {
  case 3:
    extent2 = &extent->data[2];
  case 2:
    extent1 = &extent->data[1];
  case 1:
    extent0 = &extent->data[0];
  }

  check(DAGetGhostCorners(unwrap(me),
			  corner0, corner1, corner2,
			  extent0, extent1, extent2),
	error);
}

LP_JA_jint cl_petsc_DA_mt_getGlobalIndices_L_LP_JA_jint(
    LP_cl_petsc_DA me, 
    LP_JA_jint error
)
{
  int *arr;
  int length;
  LP_JA_jint indices;
  check(DAGetGlobalIndices(unwrap(me), &length, &arr), error);
  JAVA_ARRAY_BUILD(indices, length, arr);
  return indices;
}
