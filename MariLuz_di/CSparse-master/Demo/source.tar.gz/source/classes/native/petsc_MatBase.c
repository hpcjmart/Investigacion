#include <mat.h>
#include "check.h"
#include "layout!JA_jint.h"


#define unwrap(me) ((Mat) (me)->cl_petsc_PetscObject_fld_handle)


void cl_petsc_MatBase_mt_getSize_L_LP_JA_jint(
  cl_petsc_MatBase *me, JA_jint *error)
{
  check (MatGetSize(unwrap(me),
		    &me->cl_petsc_MatBase_fld_M,
		    &me->cl_petsc_MatBase_fld_N),
	 error);
  
  check (MatGetLocalSize(unwrap(me),
			 &me->cl_petsc_MatBase_fld_m,
			 &me->cl_petsc_MatBase_fld_n),
	 error);
}


/*
 * Local variables:
 * c-file-style: "gnu"
 * c-file-offsets: ((arglist-intro . +))
 * End:
 */
