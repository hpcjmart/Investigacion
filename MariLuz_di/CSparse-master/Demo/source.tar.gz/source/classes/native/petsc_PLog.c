#include <petsclog.h>


void cl_petsc_PLog_mt_flops_jint(jint f)
{
  PLogFlops(f);
}


/*
 * Local variables:
 * c-file-style: "gnu"
 * c-file-offsets: ((arglist-intro . +))
 * End:
 */
