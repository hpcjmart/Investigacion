#ifndef _INCLUDE_CHECK_H_
#define _INCLUDE_CHECK_H_

#include <petsc.h>


#define check( operation )			\
  do						\
    {						\
      const int error = (operation);		\
      CHKERRA( error );				\
    }						\
  while (0)


/*
 * Local Variables:
 * c-file-style: "gnu"
 * End:
 */

#endif /* _INCLUDE_CHECK_H_ */
