/*
  This program converts a matrix from the Boeing-Harwell format into 
  binary PETSc format.
*/

#include <limits.h>
#include <mat.h>
#include <viewer.h>
#include "check.h"
#include "matrix_io.h"

#undef CHKERRQ
#define CHKERRQ CHKERRA

int main(int argc, char **argv) {

  /* the format and filenames of the sparse matrix */
  int ascii, in, out;
  char infile[PATH_MAX], outfile[PATH_MAX];

  /* the sparse matrix, in compressed sparse row (csr) format */
  int    m, n, nz;
  int    *row_start, *col_idx;
  double *values;

  Mat A;
  int row;
  Viewer output;
  int scan;

  check( PetscInitialize( &argc, &argv, 0, 0 ) );
  check(OptionsHasName(0, "-ascii", &ascii));
  check(OptionsGetString(0, "-in", infile, sizeof(infile), &in));
  check(OptionsGetString(0, "-out", outfile, sizeof(outfile), &out));

  if (!(in && out))
    {
      fprintf(stderr, "Usage: %s [-ascii] -out <PETSc file> -in <rsa file>\n", argv[0]);
      exit(1);
    }
  
  /* read the Harwell-Boeing format (e.g. rsa format) and store the data in
     csr format. The dimension of the matrix is m by n (which, in our case,
     m = n). nz is the number of non-zero entries */
  read_hb_matrix(infile, &m, &n, &nz, &row_start, &col_idx, &values);

  check ( MatCreateSeqAIJ(PETSC_COMM_SELF, m, n, nz/m, PETSC_NULL, &A));

  for (row = 0; row < m; row++) {
    check (MatSetValues( A, 1, &row, row_start[row+1] - row_start[row], 
		  &(col_idx[row_start[row]]), &(values[row_start[row]]),
		  INSERT_VALUES));
  }
  check (MatAssemblyBegin(A, MAT_FINAL_ASSEMBLY));
  check (MatAssemblyEnd(A, MAT_FINAL_ASSEMBLY));
  /* Changed in the latest PETSc version. */
  if (!ascii) {
    check (ViewerBinaryOpen(MPI_COMM_SELF, outfile,
			    BINARY_CREATE, &output));
  }
  else {
    check (ViewerASCIIOpen(MPI_COMM_SELF, outfile, &output));
  }
  check (MatView(A, output));
  ViewerDestroy(output);
  MatDestroy(A);
  PetscFinalize();
  return 0;
}
