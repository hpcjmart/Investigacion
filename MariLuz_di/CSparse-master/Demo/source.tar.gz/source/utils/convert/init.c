#include <assert.h>
#include <petsc.h>
/*#include <sunperf.h>*/
#include <mat.h>
#include <timelib.h>
#include <vec.h>
#include "block_smvm.h"
#include "cache_block_smvm.h"
#include "check.h"
#include "constants.h"
#include "globals.h"
#include "padded.h"
#include "strategy.h"

#undef CHKERRQ
#define CHKERRQ CHKERRA

extern void VecPrintSeq(char *name, Vec v);
extern hrtime_t VecCopyDistToSeq(Vec dist, Vec seq);
extern hrtime_t VecCopySeqToDist(Vec seq, Vec dist);
extern double *x;


void init_strategy( int *argc, char ***argv )
{
  check( PetscInitialize( argc, argv, 0, 0 ) );
}

void init_solver( char type, int height, int width,
		  int m, int n, int nz,
		  int *row_start, int *col_idx, double *values,
		  double *b_raw )
{
  int i;
  Vec b;
  int row_first, row_last, row_count;

  MPI_Comm_size(PETSC_COMM_WORLD, &numProcs);
  MPI_Comm_rank(PETSC_COMM_WORLD, &myProc);

  if (myProc == 0) {
    printf("\nValues of first 10 x: \n");
    for (i = 0; i < 10; i++)
      printf("x[%d]=%f\n", i, x[i]);
  }

  /* shadow right-hand-side vector "b" into PETSc */
  check( VecCreateSeqWithArray( PETSC_COMM_SELF, m, b_raw, &b ) );

  VecPrintSeq("b", b);

  {
    int row, idx;
    int stripMin = m * myProc / numProcs;  
    int stripMax = stripMin + (m / numProcs);
    int d_nz, o_nz;
    
    /* 
       Estimate the number of on-diagonal and off-diagonal nonzeros. 
       These numbers are based on an even distribution of rows.
    */
    d_nz = 0; o_nz = 0;
    for (row = stripMin; row < stripMax; row++) {
      for (idx = row_start[row]; idx < row_start[row + 1]; idx++) {
	if ((col_idx[idx] > stripMin) && (col_idx[idx] < stripMax)) {
	  d_nz++;
	}
	else {
	  o_nz++;
	}
      }
    }
    row_count = stripMax - stripMin; /* More or less. */

    check ( MatCreateMPIAIJ( PETSC_COMM_WORLD, PETSC_DECIDE, PETSC_DECIDE,
			     m, n, d_nz/row_count, PETSC_NULL, o_nz/row_count, PETSC_NULL, &A) );

    if (myProc == 0) {
      for (row = 0; row < m; row++) {
	for (idx = row_start[ row ]; idx < row_start[ row + 1 ]; idx++) {
	  MatSetValue( A, row, col_idx[ idx ], values[ idx ], INSERT_VALUES );
	}
      }
    }
    check( MatAssemblyBegin( A, MAT_FINAL_ASSEMBLY ) );
    check( MatAssemblyEnd( A, MAT_FINAL_ASSEMBLY ) );
    check( MatGetOwnershipRange( A, &row_first, &row_last ) );
    row_count = row_last - row_first;
  }
  
  /* various and sundry scratch vectors */
  /* note that PETSc takes care of initializing these to zero */
  v_raw = alloc_padded( row_count );
  p_raw = alloc_padded( m );
  check( VecCreateMPIWithArray( PETSC_COMM_WORLD, row_count, m, v_raw, &v ) );
  check( VecCreateSeqWithArray( PETSC_COMM_SELF, m, p_raw, &p ) );
  
  check( VecDuplicate( b, &v_local ) );
  check( VecDuplicate( b, &r ) );
  check( VecDuplicate( b, &x_p ) );
  check( VecDuplicate( b, &new_r ) );
  check( VecDuplicate( v, &v1_dist));
  check( VecDuplicate( v, &v2_dist));

  /* Create the index sets and scatters to allow seq<=>dist vector copying. */
  check( ISCreateStride(PETSC_COMM_WORLD, m, 0, 1, &dist_indices));
  check( ISCreateStride(PETSC_COMM_SELF, m, 0, 1, &seq_indices));
  check(VecScatterCreate(b, seq_indices, v, dist_indices, &seq_to_dist));
  check(VecScatterCreate(v, dist_indices, b, seq_indices, &dist_to_seq));
  
  /* based on the type of smvm, do the corresponding initialization. */
  if (type != 'n')
    {
      VecType vecType;

      const int m_local = row_count;
      const int n_local = n;
      int nz_local = 0;
      int row;

      /* these are very closely tied to the particular way
	 that reg_block() walks across the source array */      
      int * const row_start_local = &row_start[ row_first ];
      int * const col_idx_local = col_idx;
      double * const values_local = values;
      
      /* sanity check */
      check( VecGetType( v, &vecType, PETSC_NULL ) );
      assert( vecType == VECMPI );
      check( VecGetType( p, &vecType, PETSC_NULL ) );
      assert( vecType == VECSEQ );
      
      /* count the nonzeros in our subset of the rows */
      for (row = row_first; row < row_last; ++row)
	nz_local += row_start[ row + 1 ] - row_start[ row ];
      
      /* set up blocking */
      switch (type) {
      case 'r':
	/* register blocking */
	reg_block(height, width, m_local, n_local, nz_local, nz,
		  row_start_local, col_idx_local, values_local,
		  &b_m, &b_n, &b_nz, &b_row_start, &b_col_idx, &b_values);
	reg_func = bsmvm_routines[height - 1][width - 1][0];
	break;

      case 'c':
	/* cache blocking */
	c_m = m_local;
	cache_block(height, width, m_local, n_local, nz_local, nz,
		    row_start_local, col_idx_local, values_local,
		    &c_row_start, &c_sparse_ptr, &c_values, &c_col_idx);
	break;
      }
    }

  /* initial guess for inv(A)*b (I just guess the solution is a vector of
     all 1s */
  check( VecSet( &one, x_p ) );

  /* find the residual r = b - A * x_p
     note: daxpy is a standard blas1 routine, more info: 'man daxpy'
  */

  
  /* r = A * x_p */
  VecCopySeqToDist(x_p, v1_dist);
  check( MatMult( A, v1_dist, v2_dist ) );
  VecCopyDistToSeq(v2_dist, r);

  /* r = -r */
  check( VecScale( &negOne, r ) );

  /* r = b + r = b + (-A * x_p) */
  check( VecAXPY( &one, b, r ) );
  
  /* assign the initial search direction (p = r) */
  check( VecCopy( r, p ) );

  /* Suprisingly, we don't need b any more.  Is this because the
     solver doesn't test how close its approximate solution is? */
  check( VecDestroy( b ) );
}


void finalize_solver( char type )
{
  check( VecDestroy( new_r ) );
  check( VecDestroy( x_p ) );
  check( VecDestroy( r ) );
  check( VecDestroy( v_local ) );
  check( VecDestroy( v1_dist));
  check( VecDestroy( v2_dist));
  check( VecDestroy( p ) );
  check( VecDestroy( v ) );
  check( ISDestroy(dist_indices));
  check( ISDestroy(seq_indices));
  free_padded( p_raw );
  free_padded( v_raw );

  switch (type) {
  case 'r':
    free( b_values );
    free( b_col_idx );
    free( b_row_start );
    break;
  case 'd':
    free( c_col_idx );
    free( c_values );
    free( c_sparse_ptr );
    free( c_row_start );
    break;
  }

  check( MatDestroy( A ) );
}


void finalize_strategy()
{
  check( OptionsClearValue( "-f" ) );
  check( OptionsClearValue( "-t" ) );
  check( OptionsClearValue( "-H" ) );
  check( OptionsClearValue( "-w" ) );
  check( OptionsClearValue( "-e" ) );
  check( PetscFinalize() );
}


/*
 * Local Variables:
 * c-file-style: "gnu"
 * End:
 */
