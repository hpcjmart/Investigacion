#include <petsc.h>
#include <mat.h>
#include <vec.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/time.h>

#define check( operation )                      \
do                                            \
{                                           \
   const int error = (operation);            \
   CHKERRA( error );                         \
}                                           \
while (0)


const double epsilon = 1.0e-8;
int thisProc;
int numProcs;
char *filename = NULL;

void parseArgs(int argc, char **argv) {
  int i;

  for (i = 1; i < argc; i++) {
    if (strcmp("-f", argv[i]) == 0) {
      filename = argv[i+1];
      i++;
    }
  }
}

int main(int argc, char **argv) {
  Viewer matinput;
  int hasName;
  int matType;
  Mat A;
  int m,n,M,N;
  Vec x,b,x_p,r,p,v,new_r;
  PetscRandom random;
  double threshold;
  double tmp;
  double s,a,g;
  struct timeval tp,tp2;
  
  /* Initialize PETSc and the global MPI constants. */
  check(PetscInitialize(&argc, &argv, NULL, NULL));
  MPI_Comm_size(PETSC_COMM_WORLD, &numProcs);
  MPI_Comm_rank(PETSC_COMM_WORLD, &thisProc);
  
  /* Get the filename from the command line arguments. */
  parseArgs(argc, argv);
  if (!filename) {
    if (thisProc == 0) {
      printf("Switches:\n");
      printf("-f filename\n");
      printf("\tThe input matrix, in PETSc binary format.\n");
    }
    return 1;
  }

  /* Create the output viewer object, and load in the matrix from
     disk. */
  check(ViewerBinaryOpen(MPI_COMM_WORLD, filename, BINARY_RDONLY, &matinput));
  check(OptionsHasName(PETSC_NULL, "-matload_block_size", &hasName));
  if (hasName) {
    matType = MATMPIBAIJ;
  }
  else {
    matType = MATMPIAIJ;
  }
  check(MatLoad(matinput, matType, &A));

  /* Get the local and global size of the matrix. */
  check(MatGetSize(A, &M, &N));
  check(MatGetLocalSize(A, &m, &n));

  /* Create the solution vector. */
  check(VecCreateMPI(MPI_COMM_WORLD, m, M, &x));

  /* populate it with random values in the range [0, 1) */
  check(PetscRandomCreate(MPI_COMM_WORLD, RANDOM_DEFAULT, &random));
  check(VecSetRandom(random, x));
  check(PetscRandomDestroy(random));
  
  /* Print out the solution vector. */
  if (thisProc == 0) {
    printf("Actual solution vector:\n");
  }
  check(VecView(x, VIEWER_STDOUT_WORLD));

  /* Create the RHS vector. */
  check(VecDuplicate(x, &b));
  check(MatMult(A, x, b));

  /* Set the threshold value. */
  check(VecDot(b, b, &tmp));
  threshold = epsilon * tmp;

  /* Create the guess vector. */
  check(VecDuplicate(x, &x_p));
  tmp = 1.0;
  check(VecSet(&tmp, x_p));

  /* Create the residual vector. */
  check(VecDuplicate(x, &r));
  
  /* r = A * x_p */
  check(MatMult(A, x_p, r));

  /* r = -r */
  tmp = -1.0;
  check(VecScale(&tmp, r));

  /* r = b + r */
  tmp = 1.0;
  check(VecAXPY(&tmp, b, r));

  /* Create the search direction vector, p. */
  check(VecDuplicate(x, &p));

  /* p = r */
  check(VecCopy(r, p));

  /* Destroy b. */
  check(VecDestroy(b));

  /* Create the temporary vectors v and new_r. */
  check(VecDuplicate(x, &v));
  check(VecDuplicate(x, &new_r));

  /* Main solver loop. */
  gettimeofday(&tp, NULL);
  do {
    tmp = 0;
    check(VecSet(&tmp, v));
    
    /* v = A * p */
    check(MatMult(A, p, v));

    /* s = (r' * r) */
    check(VecDot(r, r, &s));

    /* a = s / (p' * v) */
    check(VecDot(p, v, &tmp));
    a = s / tmp;

    /* x_p = x_p + (a * p) */
    check(VecAXPY(&a, p, x_p));

    /* new_r = r - a * v */
    check(VecCopy(r, new_r));
    tmp = -1.0 * a;
    check(VecAXPY(&tmp, v, new_r));

    /* g = (new_r' * new_r) / s */
    check(VecDot(new_r, new_r, &tmp));
    g = tmp / s;

    /* p = new_r + g * p */
    check(VecAYPX(&g, new_r, p));
    
    /* r = new_r */
    check(VecCopy(new_r, r));

    /*printf("Error: %e\n", s);*/
  } while (s >= threshold);

  gettimeofday(&tp2, NULL);

  /* Print out the result, x_p. */
  if (thisProc == 0) {
    printf("Calculated solution:");
  }

  if (thisProc == 0) {
    printf("Elapsed time: %f\n", (double)(tp2.tv_sec - tp.tv_sec) + 
	   ((double)(tp2.tv_usec - tp.tv_usec) / 1000000.0));
  }

  check(VecView(x_p, VIEWER_STDOUT_WORLD));
  check(PetscFinalize());
  return 0;
}

