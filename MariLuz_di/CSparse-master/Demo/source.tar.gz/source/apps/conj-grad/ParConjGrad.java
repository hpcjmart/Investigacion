/* This program reads a matrix in PETSc format from a file and solves Ax=b for
   a randomly generated b, using the conjugate gradient method. */

import java.io.*;
import petsc.*;

/* This is the parallel version. The extensive (maybe over-extensive)
   commenting from the sequential version has been removed. */

public class ParConjGrad {
     
  public static final double epsilon = 1.0e-8;
  public static int thisProc;
  public static int numProcs;
  public static String filename = null;

  public static void parseArgs(String[] args) {
    for (int i = 0; i < args.length; i++) {
      if (args[i].equals("-f")) {
	filename = args[i+1];
	i++;
      }
    }
  }

/* No Titanium parallel constructs are used; all the parallelism happens
   within PETSc. */
  public static single void main(String[] args) {
    thisProc = Ti.thisProc();
    numProcs = Ti.numProcs();
   
    parseArgs(args);

    if (filename == null) {
      /* 
	 Only processor 0 will print out this error message. Titanium and
	 Java have synchronized I/O, so it is not an error for multiple 
	 processors to print to stdout. But it is darned confusing.
      */
      if (thisProc == 0) {
	System.out.println("Switches:");
	System.out.println("-f filename");
	System.out.println("    The input matrix, in PETSc binary format.");
      }
      System.exit(1);
    }
      
    Petsc local petsc = new Petsc(args, null, null, null);

    /* 
       We're using Comm.world instead of Comm.self here, so that the proper
       MPI communicator will be used when the Viewer performs its synchronized
       output. 
    */
    Viewer local viewer = ViewerASCII.out(Comm.world);

    /* 
       Create a viewer for the matrix file on disk.
    */
    ViewerBinary local matinput = new ViewerBinary(Comm.world, filename, 
						   ViewerBinary.BINARY_RDONLY,
						   null);

    /* Create a new matrix from the one on disk. */
    /* 
       Note the keyword "local". I mentioned earlier that every object
       reference in Titanium is global by default. So the runtime system
       doesn't know if it should perform communication when it accesses the
       object data or not. Checking to see what to do takes up time. You can
       make your programs more efficient by declaring object references you
       know to be local as "local". All PETSc objects in our interface are
       local, because that's how PETSc does things. Every process sees its
       own piece of a distributed data structure, not anyone else's.
    */
    /* 
       If the user gave a block size on the command line, we ask for
       the matrix in MATMPIBAIJ form: MPI-parallel, blocked, AIJ
       format. If the user did not give a block size on the command
       line, we request MATMPIAIJ form: MPI-parallel, non-blocked, AIJ
       format. MATMPIBAIJ and MATMPIAIJ are constants in interface
       MatType that tell PETSc how we want the matrix data stored.
    */
    
    int format = Options.hasName(null, "-matload_block_size", null)
	? MatType.MATMPIBAIJ
	: MatType.MATMPIAIJ;
    Mat local A = new Mat(matinput, format, null);

    /*
       Lowercase m and n are the sizes (m = row, n = column) of the local 
       portion of the matrix.
       Capital M and N are the sizes of the global matrix.
    */
    int m = A.m;
    int n = A.n;
    int M = A.M;
    int N = A.N;

    /* Create the solution vector. */
    Vec local x = new Vec(m, M, null);

    /* populate it with random values in the range [0, 1) */
    PetscRandom local random = new PetscRandom(Comm.world, null);
    x.setRandom(random, null);
    random.destroy(null);

    /* Print out the solution vector. */
    if (thisProc == 0) {
      System.out.println("Actual solution vector:");
    }
    x.view(viewer, null);

    /* 
       Create b, the RHS of the equation, by multiplying A by x. Don't forget
       the local qualifier....
     */
    Vec local b = new Vec(m, M, null);
    A.mult(x, b, null);

    /* Set the threshold value to be epsilon times the dot product of b with
       itself. */
    double threshold = epsilon * b.dot(b, null);

    /* Forget we know what the solution vector is and create a new solution 
       guess vector, x_p. */
    Vec local x_p = new Vec(m, M, null);

    /* Set x_p to all 1's, as an initial guess. */
    x_p.set(1.0, null);

    /* Create a vector r, the residual. */
    Vec local r = new Vec(m, M, null);

    /* r = A * x_p */
    A.mult(x_p, r, null);

    /* r = -r */
    r.scale(-1.0, null);

    /* r = b + r */
    r.axpy(1.0, b, null);
    
    /* Create a search direction vector, p. */
    Vec local p = new Vec(m, M, null);

    /* p = r */
    r.copy(p, null);

    /* Destroy b. */
    /* 
       We can't actually do this, because Java and Titanium don't allow you
       to destroy individual objects; memory is reclaimed through automatic
       garbage collection. And it is not reclaimed at all on distributed
       systems (it's a hard CS problem), which is kind of an annoyance you 
       have to deal with by allocating big chunks of RAM and doing your own 
       management.
     */
    
    /* Create temporary vectors v and new_r. */
    Vec local v = new Vec(m, M, null);
    Vec local new_r = new Vec(m, M, null);

    /* Declare s here because it's used outside the loop. */
    double s;

    /* Main solver loop. */
    Timer timer = new Timer();
    timer.start();
    do {
      /* Zero out v, because mult is an additive operation. */
      v.set(0, null);

      /* v = A * p */
      A.mult(p, v, null);
      
      /* s = (r' * r) */
      s = r.dot(r, null);

      /* a = s / (p' * v) */
      double a = s / p.dot(v, null);

      /* x_p = x_p + (a * p) */
      x_p.axpy(a, p, null);

      /* new_r = r - a * v */
      r.copy(new_r, null);
      new_r.axpy(-1.0 * a, v, null);

      /* g = (new_r' * new_r) / s */
      double g = new_r.dot(new_r, null) / s;

      /* p = new_r + g*p */
      p.aypx(g, new_r, null);

      /* r = new_r */
      new_r.copy(r, null);

      /*System.out.println("Error: " + s);*/
    } while (s >= threshold);
    timer.stop();

    /* Print out the result, x_p. */
    if (thisProc == 0) {
      System.out.println("Calculated solution:");
    }
    x_p.view(viewer, null);

    if (thisProc == 0) {
      System.out.println("Elapsed time: " + timer.secs());
    }

    petsc.finalize(null);
  }
}
