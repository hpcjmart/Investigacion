import java.io.*;
import petsc.*;

public class Fuel extends SNESNonlinear
                  implements Constants, InsertMode {
 
   static final double one = 1.0;
   static final double two = 2.0;

   public static final int COARSE_LEVEL = 0;
   public static final int FINE_LEVEL = 1;
   public static int thisProc;
   public static int Nx;
   public static int Ny;
   public static final double bratu_lambda_max = 6.81;
   public static final double bratu_lambda_min = 0.;

   public static Timer local multTime, multTransTime, funcTime, jacobTime, totalTime, initialGuessTime, formGridTime, solveTime;
   public static int funcCount = 0;
   
   protected local void FormInitialGuess1(Vec local X,
                                          int[] local error ) {
   
      int i, j, row, mx, my;
      int[] local s = new int[2];
      int[] local m = new int[2];
      int[] local S = new int[2];
      int[] local M = new int[2];
      double lambda, temp1, temp, hx, hy, hxdhy, hydhx, sc;
      double[1d] local x;

      initialGuessTime.start();

      Vec local localX = fine.localX;
      
      mx = fine.mx;	  my = fine.my;     lambda = param;
      hx = one/(mx-1);	  hy = one/(my-1);
      sc = hx*hy*lambda;  hxdhy = hx/hy;    hydhx = hy/hx;

      temp1 = lambda/(lambda + one);
   
      /* Get ghost points */
      fine.da.getCorners(s, m, null);
      fine.da.getGhostCorners(S, M, null);
      x = localX.getArray(null);
      
      /* Compute initial guess */
      for (j = s[1]; j < s[1] + m[1]; j++) {
         temp = Math.min(j, my-j-1) * hy;
         for (i = s[0]; i < s[0] + m[0]; i++) {
            row = i - S[0] + (j - S[1]) * M[0];
            if (i == 0 || j == 0 || i == mx-1 || j == my-1 ) {
               x[row] = 0.0;
               continue;
            }
         x[row] = temp1 * Math.sqrt(Math.min((Math.min(i, mx-i-1))*hx, temp));
         }
      }
      localX.restoreArray(x, null);

      /* Insert values into global vector */
      fine.da.localToGlobal(localX, INSERT_VALUES, X, null);

      initialGuessTime.stop();
   }
   
          
   protected local void function(Vec local X, Vec local F, int[] local error) {
  
      int i, j, row, mx, my;
      int[] local s = new int[2];
      int[] local m = new int[2];
      int[] local S = new int[2];
      int[] local M = new int[2];
      double lambda, hx, hy, hxdhy, hydhx, sc;
      double u, uxx, uyy;
      double[1d] local x;
      double[1d] local f;

      funcTime.start();

      Vec local localX = fine.localX;
      Vec local localF = fine.localF;

      
      mx = fine.mx;	  my = fine.my;     lambda = param;
      hx = one/(mx-1);	  hy = one/(my-1);
      sc = hx*hy*lambda;  hxdhy = hx/hy;    hydhx = hy/hx;
   
      /* Get ghost points */
      fine.da.globalToLocalBegin(X, INSERT_VALUES, localX, null);
      fine.da.globalToLocalEnd(X, INSERT_VALUES, localX, null);
      fine.da.getCorners(s, m, null);
      fine.da.getGhostCorners(S, M , null);
      x = localX.getArray(null);
      f = localF.getArray(null);

      /* Evaluate function */

      /* LIM. */
      int s1=s[1],m1=m[1],S1=S[1],M0=M[0],s0=s[0],S0=S[0],m0=m[0];

      for (j = s1; j < s1 + m1; j++) {
         row = (j - S1) * M0 + s0 - S0 - 1;

         for (i = s0; i < s0 + m0; i++) {
            row++;
            if (i > 0 && i < mx -1 && j > 0 && j < my-1) {
               u = x[row];
               uxx = (two * u - x[row-1] - x[row+1]) * hydhx;
               uyy = (two * u - x[row-M0] - x[row+M0]) * hxdhy;
               f[row] = uxx + uyy - sc * Math.exp(u);
            }
            else if ((i > 0 && i < mx-1) || (j > 0 && j < my-1)) {
               f[row] = .5 * two * (hydhx + hxdhy) * x[row];
            }
            else {
               f[row] = .25 * two * (hydhx + hxdhy) * x[row];
            }
         }
      }
      localX.restoreArray(x, null);
      localF.restoreArray(f, null);

      /* Insert values into global vector */
      fine.da.localToGlobal(localF, INSERT_VALUES, F, null);
      funcTime.stop();
   }


   protected local void FormJacobian_Grid(GridCtx local grid,
					  Vec local X, MatBase local J,
					  MatBase local B, int[] local error) {
             
     formGridTime.start();

      Mat local jac = (Mat local)J;
      int i, j, row, mx, my;
      int[] local s = new int[2];
      int[] local m = new int[2];
      int[] local S = new int[2];
      int[] local M = new int[2];
      int[] local col = new int[5];
      double[] local v = new double[5];
      int[] local grow = new int[1];
      int[] local ltog;
      double lambda, hx, hy, hxdhy, hydhx, sc;
      double[] local value = new double[1];
      Vec local localX = grid.localX;

      double[1d] local x;

      mx = grid.mx;	  my = grid.my;     lambda = param;
      hx = one/(mx-1);	  hy = one/(my-1);
      sc = hx*hy;	  hxdhy = hx/hy;    hydhx = hy/hx;

      /* Get ghost points */
      grid.da.globalToLocalBegin(X, INSERT_VALUES, localX, null);
      grid.da.globalToLocalEnd(X, INSERT_VALUES, localX, null);
      grid.da.getCorners(s, m, null);
      grid.da.getGhostCorners(S, M, null);
      ltog = grid.da.getGlobalIndices(null);
     
      x = localX.getArray(null);

      /* LIM. */
      int s1, m1, S1, M0, s0, S0, m0;
      s1=s[1]; m1=m[1]; S1=S[1]; M0=M[0]; s0=s[0]; S0=S[0]; m0=m[0];

      /* Evaluate Jacobian of function */
      for (j = s1; j < s1 + m1; j++) {
         row = (j - S1) * M0 + s0 - S0 - 1;
         for (i = s0; i < s0 + m0; i++) {
            row++;
            grow[0] = ltog[row];
            if (i > 0 && i < mx-1 && j > 0 && j < my-1) {
               v[0] = -hxdhy; col[0] = ltog[row - M0];
               v[1] = -hydhx; col[1] = ltog[row - 1];
               v[2] = two * (hydhx + hxdhy) - sc * lambda * Math.exp(x[row]);
               col[2] = grow[0];
               v[3] = -hydhx; col[3] = ltog[row + 1];
               v[4] = -hxdhy; col[4] = ltog[row + M0];
               jac.setValues(1, grow, 5, col, v, INSERT_VALUES, null);
            }
            else if ((i > 0 && i < mx-1) || (j > 0 && j < my-1)) {
               value[0] = .5 * two * (hydhx + hxdhy);
               jac.setValues(1, grow, 1, grow, value, INSERT_VALUES, null);
            }
            else {
               value[0] = .25 * two * (hydhx + hxdhy);
               jac.setValues(1, grow, 1, grow, value, INSERT_VALUES, null);
            }
         }
      }
      jac.assemblyBegin(Mat.FINAL_ASSEMBLY, null);
      localX.restoreArray(x, null);
      jac.assemblyEnd(Mat.FINAL_ASSEMBLY, null);
     formGridTime.stop();
   }


   protected local void jacobian(Vec local X,
                   MatBase local[] local J, MatBase local[] local B,
                   int[] local flag, int[] local error) {

     jacobTime.start();
      flag[0] = SAME_NONZERO_PATTERN;
      FormJacobian_Grid(fine, X, J[0], B[0], null);

      /* create coarse grid jacobian for preconditioner */
      SLES local sles = getSLES(null);
      PC local pc = sles.getPC(null);
      
      /* use String instead of PCType */
      String local pctype = pc.getType(null);
      if (pctype.equals(PC.MG)) {

         sles_fine.setOperators(fine.J, fine.J,
				SAME_NONZERO_PATTERN, null);

         /* restrict X to coarse grid */
         R.mult(X, coarse.x, null);
	 coarse.x.pointwiseMult(Rscale, coarse.x, null);
         /* form Jacobian on coarse grid */
         FormJacobian_Grid(coarse, coarse.x, coarse.J,
			   coarse.J, null);
         sles_coarse.setOperators(coarse.J, coarse.J,
				  SAME_NONZERO_PATTERN, null);
      }
     jacobTime.stop();
   }
    
 
   protected local void FormInterpolation(int[] local error) {
 
      int i, j, m_fine, M;
      int Mx = coarse.mx, My = coarse.my;
      int[] local idx;
      int[] local idx_c;
      int m_coarse;
      int[] local row = new int[1];
      int[] local cols = new int[4];
      int mx = fine.mx,  my = fine.my;
      int c0, c1, c2, c3, nc, ratio = this.ratio;
      int i_end, i_end_ghost, m_c_local, m_fine_local;
      int i_c, j_c;
      int col;
      double x, y;
      double[] local v= new double[4];
      Mat local mat;
             
      /* arrays correspond to original int
      start[2]: i_start, j_start
      m[2]: m, n
      start_ghost[2]: i_start_ghost, j_start_ghost
      m_ghost[2]: m_ghost, n_ghost
      start_c[2]: i_start_c, j_start_c
      m_c[2]: m_c, n_c
      start_ghost_c[2]; i_start_ghost_c, j_start_ghost_c
      m_ghost_c[2]: m_ghost_c, n_ghost_c
      */

      int[] local start = new int[2];
      int[] local m = new int[2];
      int[] local start_ghost = new int[2];
      int[] local m_ghost = new int[2];
      int[] local start_c = new int[2];
      int[] local m_c = new int[2];
      int[] local start_ghost_c = new int[2];
      int[] local m_ghost_c = new int[2];
      
      fine.da.getCorners(start, m,  null);
      fine.da.getGhostCorners(start_ghost, m_ghost, null);;
      idx = fine.da.getGlobalIndices(null);

      coarse.da.getCorners(start_c, m_c, null);
      coarse.da.getGhostCorners(start_ghost_c, m_ghost_c, null);
      idx_c = coarse.da.getGlobalIndices(null);

      /* create interpolation matrix */
      m_fine_local = fine.x.getLocalSize(null);
      m_c_local = coarse.x.getLocalSize(null);
      m_fine = fine.x.getSize(null);
      m_coarse = coarse.x.getSize(null);
      mat = new Mat(m_fine_local, m_c_local, m_fine, m_coarse,
                    5, null, 3, null, null);
      
      /* loop over local fine grid nodes setting interpolation for those*/
      for ( j = start[1]; j < start[1] + m[1]; j++ ) {
         for ( i = start[0]; i < start[0] + m[0]; i++ ) {
            /* convert to local "natural" numbering and then to PETSc global numbering */
            row[0] = idx[m_ghost[0] * (j - start_ghost[1]) + (i - start_ghost[0])];

            i_c = (i/ratio);    /* coarse grid node to left of fine grid node */
            j_c = (j/ratio);    /* coarse grid node below fine grid node */

            /*
            Only include those interpolation points that are truly
            nonzero. Note this is very important for final grid lines
            in x and y directions; since they have no right/top neighbors
            */
            x  = (i - i_c*ratio)/((double)ratio);
            y  = (j - j_c*ratio)/((double)ratio);
            
            /* printf("i j %d %d %g %g\n",i,j,x,y); */
            nc = 0;
            
            /* one left and below; or we are right on it */
            if (j_c < start_ghost_c[1] || j_c > start_ghost_c[1] + m_ghost_c[1]) {
               if (thisProc == 0)
               System.out.println("Sorry j " + j_c + start_ghost_c[1]
                                  + (start_ghost_c[1] + m_ghost_c[1]));
               System.exit(3);
            }
            
            if (i_c < start_ghost_c[0] || i_c > start_ghost_c[0] + m_ghost_c[0]) {
               if (thisProc == 0)
               System.out.println("Sorry i " + i_c + start_ghost_c[0]
                                  + (start_ghost_c[0] + m_ghost_c[0]));
               System.exit(3);
            }
 
            col = m_ghost_c[0] * (j_c - start_ghost_c[1])
                  + (i_c - start_ghost_c[0]);
            cols[nc] = idx_c[col];
            v[nc++]  = x*y - x - y + 1.0;
            
            /* one right and below */
            if (i_c * ratio != i) {
               cols[nc] = idx_c[col + 1];
               v[nc++]  = - x * y + x;
            }
            
            /* one left and above */
            if (j_c * ratio != j) {
               cols[nc] = idx_c[col + m_ghost_c[0]];
               v[nc++]  = - x * y + y;
            }
            
            /* one right and above */
            if (j_c * ratio != j && i_c * ratio != i) {
               cols[nc] = idx_c[col + m_ghost_c[0] + 1];
               v[nc++]  = x * y;
            }
            mat.setValues(1, row, nc, cols, v, INSERT_VALUES, null);
         }
      }
      mat.assemblyBegin(Mat.FINAL_ASSEMBLY, null);
      mat.assemblyEnd(Mat.FINAL_ASSEMBLY, null);

      Rscale = coarse.x.duplicate(null);
      fine.x.set(one, null);
      mat.multTrans(fine.x, Rscale, null);
      Rscale.reciprocal(null);
 
      /*
      this is merely so we provide a restriction "matrix" to the multigrid code
      so we flip the roles of MatMult() and MatMultTrans() on the "interpolation
      restriction" matrix
      */
      R = new MyMatrix(m_c_local, m_fine_local,
		       m_coarse, m_fine, mat, null);
                             
   }


   final private double param = Utils.getOption("-par", 6.0);
   final private int ratio = Utils.getOption("-ratio", 2);
   final private CoarseCtx local coarse = new CoarseCtx();
   final private FineCtx local fine = new FineCtx(ratio, coarse);
   final private SLES local sles_coarse;
   final private SLES local sles_fine;
   private MyMatrix local R;
   private Vec local Rscale;

   Fuel() {
      super(Comm.world, null);
      
      /*
      if (thisProc == 0) {
         System.out.println("Coarse grid size " + coarse.mx
			    + " by " + coarse.my);
         System.out.println("Fine grid size " + fine.mx
			    + " by " + fine.my);
      }
      */

      if (param >= bratu_lambda_max || param < bratu_lambda_min) {
	 if (thisProc == 0)
	    System.out.println("Lambda is out of range");
	 System.exit(1);
      }

      /* provide user function and Jacobian */
      setFunction(fine.b, null);
      setJacobian(fine.J, fine.J, null);

      /* set two level additive Schwarz preconditioner */
      /* MG local mg = new MG(getSLES(null).getPC(null)); */
      SLES local sles = getSLES(null);
      PC local pc = sles.getPC(null);
      MG local mg = new MG(pc);

      mg.setLevels(2, null);
      mg.setType(MG.ADDITIVE, null);
      
      /* Create coarse level */
      sles_coarse = mg.getCoarseSolve(null);
      sles_coarse.setOptionsPrefix("coarse_", null);
      sles_coarse.setFromOptions(null);
      sles_coarse.setOperators(coarse.J, coarse.J,
			       DIFFERENT_NONZERO_PATTERN, null);
      mg.setX(COARSE_LEVEL, coarse.x, null);
      mg.setRhs(COARSE_LEVEL, coarse.b, null);

      /* Create fine level */
      sles_fine = mg.getSmoother(FINE_LEVEL, null);
      sles_fine.setOptionsPrefix("fine_", null);
      sles_fine.setFromOptions(null);
      sles_fine.setOperators(fine.J, fine.J,
                                  DIFFERENT_NONZERO_PATTERN, null);
      mg.setR(FINE_LEVEL, fine.r, null);
      mg.setResidualDefault(FINE_LEVEL, fine.J, null);

      /* Create interpolation between the levels */
      FormInterpolation(null);
      mg.setInterpolate(FINE_LEVEL, R, null);
      mg.setRestriction(FINE_LEVEL, R, null);
   }
  

   public local void destroy(int[] local error) {
      super.destroy(error);
      fine.destroy(error);
      coarse.destroy(error);
      R.destroy(error);
      Rscale.destroy(error);
   }
   

   static public void main(String[] args) {
      String local help =
	 "This program demonstrates use of the SNES package to solve systems of\n" +
	 "nonlinear equations in parallel, using 2-dimensional distributed arrays.\n" +
	 "The 2-dim Bratu (SFI - solid fuel ignition) test problem is used, where\n" +
	 "analytic formation of the Jacobian is the default.\n" +
	 "\n" +
	 "  Solves the linear systems via 2 level additive Schwarz\n" +
	 "\n" +
	 "The command line\n" +
	 "options are:\n" +
	 "  -par <parameter>, where <parameter> indicates the problem's nonlinearity\n" +
	 "     problem SFI:  <parameter> = Bratu parameter (0 <= par <= 6.81)\n" +
	 "  -Mx <xg>, where <xg> = number of grid points in the x-direction on coarse grid\n" +
	 "  -My <yg>, where <yg> = number of grid points in the y-direction on coarse grid\n\n";

      Petsc.initialize(args, "ex11options", help, null);
      thisProc = Ti.thisProc();
      
      Nx = Utils.getOption("-Nx", PETSC_DECIDE);
      Ny = Utils.getOption("-Ny", PETSC_DECIDE);

      /* Create the zillions of timers. */
      multTime = new Timer(); multTransTime = new Timer(); 
      funcTime = new Timer(); jacobTime = new Timer(); totalTime = new Timer();
      initialGuessTime = new Timer(); formGridTime = new Timer(); 
      solveTime = new Timer();

      totalTime.start();

      /* Create nonlinear solver */
      Fuel local fuel = new Fuel();

      /* Set options, then solve nonlinear system */
      fuel.setFromOptions(null);
      fuel.FormInitialGuess1(fuel.fine.x, null);

      solveTime.start();
      int its = fuel.solve(fuel.fine.x, null);
      solveTime.stop();

      /*
      if (thisProc == 0) {
          System.out.println("Number of Newton iterations = " + its);
      }
      */

      /* optionally display solution vector */
      if (Options.hasName(null, "-solution_view", null))
	 fuel.fine.x.view(ViewerASCII.out(Comm.world), null);

      /* Free data structures */
      fuel.destroy(null);

      totalTime.stop();

      System.out.println("multTime: " + multTime.secs());
      System.out.println("multTransTime: " + multTransTime.secs());
      System.out.println("funcTime: " + funcTime.secs());
      System.out.println("jacobTime: " + jacobTime.secs());
      System.out.println("initialGuessTime: " + jacobTime.secs());
      System.out.println("formGridTime: " + formGridTime.secs());
      System.out.println("solveTime: " + solveTime.secs());
      System.out.println("totalTime: " + totalTime.secs());      
      Petsc.finish(null);
   } /* end of main */
} /* end of class Fuel */


// Local variables:
// c-basic-offset: 3
// End:
