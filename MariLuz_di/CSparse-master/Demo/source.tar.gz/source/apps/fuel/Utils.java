import petsc.Options;


class Utils {

   static int getOption(String local name, int fallback) {
      Integer local option = Options.getInt(null, name, null);
      return option == null ? fallback : option.intValue();
   }

   static double getOption(String local name, double fallback) {
      Double local option = Options.getDouble(null, name, null);
      return option == null ? fallback : option.doubleValue();
   }
}


// Local variables:
// c-basic-offset: 3
// End:
