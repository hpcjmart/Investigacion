import petsc.*;


class GridCtx {
   final int mx, my;
   final Vec local localX, localF;
   final DA local da;
   final Vec local x,b;
   final Mat local J;
   final int n, nLocal;

   GridCtx(int mx, int my) {
      this.mx = mx;
      this.my = my;

      /* Set up distributed array for grid */
      da = new DA(Comm.world, DA.NONPERIODIC, DA.STENCIL_STAR,
		  mx, my, Fuel.Nx, Fuel.Ny, 1, 1,
		  null, null, null);

      x = da.createGlobalVector(null);
      b = x.duplicate(null);
      
      n = mx * my;
      nLocal = x.getLocalSize(null);

      localX = da.createLocalVector(null);
      localF = localX.duplicate(null);
      J = new Mat(nLocal, nLocal, n, n, 5, null, 3, null, null);
   }

   protected local void destroy(int[] local error) {
      J.destroy(error);
      x.destroy(error);
      b.destroy(error);
      da.destroy(error);
      localX.destroy(error);
      localF.destroy(error);
   }
}


// Local variables:
// c-basic-offset: 3
// End:
