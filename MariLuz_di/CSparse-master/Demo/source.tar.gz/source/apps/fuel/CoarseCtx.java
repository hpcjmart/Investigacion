final class CoarseCtx extends GridCtx {

    CoarseCtx() {
	super(Utils.getOption("-Mx", 5),
	      Utils.getOption("-My", 5));
    }
}
