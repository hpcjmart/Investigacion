import petsc.*;

final class MyMatrix extends MatShell {

   private final Mat local mat;

   MyMatrix(int m_c_local, int m_fine_local, int m_coarse,
            int m_fine, Mat local mat, int[] local error) {
      super(Comm.world, m_c_local, m_fine_local, m_coarse, m_fine, error);
      this.mat = mat;
   }
   
   public local void mult(Vec local x, Vec local y, int[] local error) {
     Fuel.multTime.start();
      mat.multTrans(x, y, error);
     Fuel.multTime.stop();
   }   
   
   public local void multTransAdd(Vec local x, Vec local y, 
                                  Vec local z, int[] local error) {
     Fuel.multTransTime.start();
      mat.multAdd(x, y, z, error);
     Fuel.multTransTime.stop();
   }   
   
   public local void destroy(int[] local error) {
      mat.destroy(error);
   }   
            
}            
