#ifdef PETSC_RCS_HEADER
static char vcid[] = "$Id: ex11.c,v 1.4 1999/05/14 06:10:09 cjlin Exp $";
#endif

static char help[] =
"This program demonstrates use of the SNES package to solve systems of\n\
nonlinear equations in parallel, using 2-dimensional distributed arrays.\n\
The 2-dim Bratu (SFI - solid fuel ignition) test problem is used, where\n\
analytic formation of the Jacobian is the default.  \n\
\n\
  Solves the linear systems via 2 level additive Schwarz \n\
\n\
The command line\n\
options are:\n\
  -par <parameter>, where <parameter> indicates the problem's nonlinearity\n\
     problem SFI:  <parameter> = Bratu parameter (0 <= par <= 6.81)\n\
  -Mx <xg>, where <xg> = number of grid points in the x-direction on coarse grid\n\
  -My <yg>, where <yg> = number of grid points in the y-direction on coarse grid\n\n";


/*  
    1) Solid Fuel Ignition (SFI) problem.  This problem is modeled by
    the partial differential equation
  
            -Laplacian u - lambda*exp(u) = 0,  0 < x,y < 1 ,
  
    with boundary conditions
   
             u = 0  for  x = 0, x = 1, y = 0, y = 1.
  
    A finite difference approximation with the usual 5-point stencil
    is used to discretize the boundary value problem to obtain a nonlinear 
    system of equations.
*/

#include "snes.h"
#include "da.h"
#include "mg.h"
#include <time.h>


/* This timer code is not just for whizzy convenience's sake; it also adds
   overhead roughly like what the Titanium timers will add. */

typedef struct {
  struct timeval tv;
  long elapSec;
  long elapUsec;
} Timer;

Timer multTime, multTransTime, funcTime, jacobTime, totalTime, initialGuessTime, formGridTime, solveTime;

void initTimer(Timer *timer) {
 timer->elapSec = 0;
 timer->elapUsec = 0;
}

void startTimer(Timer *timer) {
  gettimeofday(&timer->tv, NULL);
}

void stopTimer(Timer *timer) {
  struct timeval newTv;
  gettimeofday(&newTv, NULL);
  timer->elapSec += newTv.tv_sec - timer->tv.tv_sec;
  timer->elapUsec += newTv.tv_usec - timer->tv.tv_usec;
}

double getSecs(Timer *timer) {
  return (double)timer->elapSec + ((double)timer->elapUsec / 1000000.);
}

void initAllTheTimers() {
  initTimer(&multTime); initTimer(&multTransTime); initTimer(&funcTime);
  initTimer(&jacobTime); initTimer(&totalTime); initTimer(&initialGuessTime);
  initTimer(&formGridTime); initTimer(&solveTime);
}


/* User-defined application contexts */


typedef struct {
   int        mx,my;            /* number grid points in x and y direction */
   Vec        localX,localF;    /* local vectors with ghost region */
   DA         da;
   Vec        x,b,r;            /* global vectors */
   Mat        J;                /* Jacobian on grid */
} GridCtx;

typedef struct {
   double      param;           /* test problem parameter */
   GridCtx     fine;
   GridCtx     coarse;
   SLES        sles_coarse;
   SLES        sles_fine;
   int         ratio;
   Mat         R;               /* restriction fine to coarse */
   Vec         Rscale;
} AppCtx;

#define COARSE_LEVEL 0
#define FINE_LEVEL   1

extern int FormFunction(SNES,Vec,Vec,void*), FormInitialGuess1(AppCtx*,Vec);
extern int FormJacobian(SNES,Vec,Mat*,Mat*,MatStructure*,void*);
extern int FormInterpolation(AppCtx *);

/*
      Mm_ratio - ration of grid lines between fine and coarse grids.
*/
#undef __FUNC__
#define __FUNC__ "main"
int main( int argc, char **argv )
{
  SNES          snes;                      
  AppCtx        user;                      
  int           ierr, its, N, n, Nx = PETSC_DECIDE, Ny = PETSC_DECIDE;
  int           size, flg,nlocal,Nlocal;
  double        bratu_lambda_max = 6.81, bratu_lambda_min = 0.;
  SLES          sles;
  PC            pc;

  /* Initialize all those darned timers. */
  initAllTheTimers();

  /*
      Initialize PETSc, note that default options in ex11options can be 
      overridden at the command line
  */
  PetscInitialize( &argc, &argv,"ex11options",help );

  user.ratio = 2;
  user.coarse.mx = 5; user.coarse.my = 5; user.param = 6.0;
  ierr = OptionsGetInt(PETSC_NULL,"-Mx",&user.coarse.mx,&flg); CHKERRA(ierr);
  ierr = OptionsGetInt(PETSC_NULL,"-My",&user.coarse.my,&flg); CHKERRA(ierr);
  ierr = OptionsGetInt(PETSC_NULL,"-ratio",&user.ratio,&flg); CHKERRA(ierr);
  user.fine.mx = user.ratio*(user.coarse.mx-1)+1; user.fine.my = user.ratio*(user.coarse.my-1)+1;

  /*
  PetscPrintf(PETSC_COMM_WORLD,"Coarse grid size %d by %d\n",user.coarse.mx,user.coarse.my);
  PetscPrintf(PETSC_COMM_WORLD,"Fine grid size %d by %d\n",user.fine.mx,user.fine.my);
  */

  ierr = OptionsGetDouble(PETSC_NULL,"-par",&user.param,&flg); CHKERRA(ierr);
  if (user.param >= bratu_lambda_max || user.param < bratu_lambda_min) {
    SETERRA(1,0,"Lambda is out of range");
  }
  n = user.fine.mx*user.fine.my; N = user.coarse.mx*user.coarse.my;

  MPI_Comm_size(PETSC_COMM_WORLD,&size);
  ierr = OptionsGetInt(PETSC_NULL,"-Nx",&Nx,&flg); CHKERRA(ierr);
  ierr = OptionsGetInt(PETSC_NULL,"-Ny",&Ny,&flg); CHKERRA(ierr);

  startTimer(&totalTime);

  /* Set up distributed array for fine grid */
  ierr = DACreate2d(PETSC_COMM_WORLD,DA_NONPERIODIC,DA_STENCIL_STAR,user.fine.mx,
                    user.fine.my,Nx,Ny,1,1,PETSC_NULL,PETSC_NULL,&user.fine.da); CHKERRA(ierr);
  ierr = DACreateGlobalVector(user.fine.da,&user.fine.x); CHKERRA(ierr);
  ierr = VecDuplicate(user.fine.x,&user.fine.r); CHKERRA(ierr);
  ierr = VecDuplicate(user.fine.x,&user.fine.b); CHKERRA(ierr);
  ierr = VecGetLocalSize(user.fine.x,&nlocal);CHKERRA(ierr);
  ierr = DACreateLocalVector(user.fine.da,&user.fine.localX); CHKERRA(ierr);
  ierr = VecDuplicate(user.fine.localX,&user.fine.localF); CHKERRA(ierr);
  ierr = MatCreateMPIAIJ(PETSC_COMM_WORLD,nlocal,nlocal,n,n,5,PETSC_NULL,3,PETSC_NULL,&user.fine.J); CHKERRA(ierr);

  /* Set up distributed array for coarse grid */
  ierr = DACreate2d(PETSC_COMM_WORLD,DA_NONPERIODIC,DA_STENCIL_STAR,user.coarse.mx,
                    user.coarse.my,Nx,Ny,1,1,PETSC_NULL,PETSC_NULL,&user.coarse.da); CHKERRA(ierr);
  ierr = DACreateGlobalVector(user.coarse.da,&user.coarse.x); CHKERRA(ierr);
  ierr = VecDuplicate(user.coarse.x,&user.coarse.b); CHKERRA(ierr);
  ierr = VecGetLocalSize(user.coarse.x,&Nlocal);CHKERRA(ierr);
  ierr = DACreateLocalVector(user.coarse.da,&user.coarse.localX); CHKERRA(ierr);
  ierr = VecDuplicate(user.coarse.localX,&user.coarse.localF); CHKERRA(ierr);
  ierr = MatCreateMPIAIJ(PETSC_COMM_WORLD,Nlocal,Nlocal,N,N,5,PETSC_NULL,3,PETSC_NULL,&user.coarse.J); CHKERRA(ierr);

  /* Create nonlinear solver */
  ierr = SNESCreate(PETSC_COMM_WORLD,SNES_NONLINEAR_EQUATIONS,&snes);CHKERRA(ierr);

  /* provide user function and Jacobian */
  ierr = SNESSetFunction(snes,user.fine.b,FormFunction,&user); CHKERRA(ierr);
  ierr = SNESSetJacobian(snes,user.fine.J,user.fine.J,FormJacobian,&user);CHKERRA(ierr);

  /* set two level additive Schwarz preconditioner */
  ierr = SNESGetSLES(snes,&sles);CHKERRA(ierr);
  ierr = SLESGetPC(sles,&pc); CHKERRA(ierr);
  ierr = PCSetType(pc,PCMG); CHKERRA(ierr);
  ierr = MGSetLevels(pc,2); CHKERRA(ierr);
  ierr = MGSetType(pc,MGADDITIVE); CHKERRA(ierr);

  /* Create coarse level */
  ierr = MGGetCoarseSolve(pc,&user.sles_coarse); CHKERRA(ierr);
  ierr = SLESSetOptionsPrefix(user.sles_coarse,"coarse_"); CHKERRA(ierr);
  ierr = SLESSetFromOptions(user.sles_coarse); CHKERRA(ierr);
  ierr = SLESSetOperators(user.sles_coarse,user.coarse.J,user.coarse.J,DIFFERENT_NONZERO_PATTERN);CHKERRA(ierr);
  ierr = MGSetX(pc,COARSE_LEVEL,user.coarse.x);CHKERRA(ierr); 
  ierr = MGSetRhs(pc,COARSE_LEVEL,user.coarse.b);CHKERRA(ierr); 

  /* Create fine level */
  ierr = MGGetSmoother(pc,FINE_LEVEL,&user.sles_fine); CHKERRA(ierr);
  ierr = SLESSetOptionsPrefix(user.sles_fine,"fine_"); CHKERRA(ierr);
  ierr = SLESSetFromOptions(user.sles_fine); CHKERRA(ierr);
  ierr = SLESSetOperators(user.sles_fine,user.fine.J,user.fine.J,DIFFERENT_NONZERO_PATTERN);CHKERRA(ierr);
  ierr = MGSetR(pc,FINE_LEVEL,user.fine.r);CHKERRA(ierr); 
  ierr = MGSetResidual(pc,FINE_LEVEL,MGDefaultResidual,user.fine.J); CHKERRA(ierr);

  /* Create interpolation between the levels */
  ierr = FormInterpolation(&user);CHKERRA(ierr);
  ierr = MGSetInterpolate(pc,FINE_LEVEL,user.R);CHKERRA(ierr);
  ierr = MGSetRestriction(pc,FINE_LEVEL,user.R);CHKERRA(ierr);

  /* Set options, then solve nonlinear system */
  ierr = SNESSetFromOptions(snes); CHKERRA(ierr);
  ierr = FormInitialGuess1(&user,user.fine.x); CHKERRA(ierr);

  startTimer(&solveTime);
  ierr = SNESSolve(snes,user.fine.x,&its); CHKERRA(ierr);
  stopTimer(&solveTime);

  /*
  PetscPrintf(PETSC_COMM_WORLD,"Number of Newton iterations = %d\n", its );
  */

  /* optionally display solution vector */
  ierr = OptionsHasName(0, "-solution_view", &flg); CHKERRA(ierr);
  if (flg) {
    ierr = VecView(user.fine.x, VIEWER_STDOUT_WORLD); CHKERRA(ierr);
  }

  stopTimer(&totalTime);

  /* Free data structures */
  ierr = MatDestroy(user.fine.J); CHKERRA(ierr);
  ierr = VecDestroy(user.fine.x); CHKERRA(ierr);
  ierr = VecDestroy(user.fine.r); CHKERRA(ierr);
  ierr = VecDestroy(user.fine.b); CHKERRA(ierr);
  ierr = DADestroy(user.fine.da); CHKERRA(ierr);
  ierr = VecDestroy(user.fine.localX); CHKERRA(ierr);
  ierr = VecDestroy(user.fine.localF); CHKERRA(ierr);

  ierr = MatDestroy(user.coarse.J); CHKERRA(ierr);
  ierr = VecDestroy(user.coarse.x); CHKERRA(ierr);
  ierr = VecDestroy(user.coarse.b); CHKERRA(ierr);
  ierr = DADestroy(user.coarse.da); CHKERRA(ierr);
  ierr = VecDestroy(user.coarse.localX); CHKERRA(ierr);
  ierr = VecDestroy(user.coarse.localF); CHKERRA(ierr);

  ierr = SNESDestroy(snes); CHKERRA(ierr);
  ierr = MatDestroy(user.R);CHKERRA(ierr); 
  ierr = VecDestroy(user.Rscale);CHKERRA(ierr); 

  printf("multTime: %f\n", getSecs(&multTime));
  printf("multTransTime: %f\n", getSecs(&multTransTime));
  printf("funcTime: %f\n", getSecs(&funcTime));
  printf("jacobTime: %f\n", getSecs(&jacobTime));
  printf("initialGuessTime: %f\n", getSecs(&initialGuessTime));
  printf("formGridTime: %f\n", getSecs(&formGridTime));
  printf("solveTime: %f\n", getSecs(&solveTime));
  printf("totalTime: %f\n", getSecs(&totalTime));

  PetscFinalize();

  return 0;
}/* --------------------  Form initial approximation ----------------- */
#undef __FUNC__
#define __FUNC__ "FormInitialGuess1"
int FormInitialGuess1(AppCtx *user,Vec X)
{
  int     i, j, row, mx, my, ierr, xs, ys, xm, ym, Xm, Ym, Xs, Ys;
  double  one = 1.0, lambda, temp1, temp, hx, hy, hxdhy, hydhx,sc;
  Scalar  *x;
  Vec     localX = user->fine.localX;

  startTimer(&initialGuessTime);

  mx = user->fine.mx;       my = user->fine.my;            lambda = user->param;
  hx = one/(double)(mx-1);  hy = one/(double)(my-1);
  sc = hx*hy*lambda;        hxdhy = hx/hy;            hydhx = hy/hx;

  temp1 = lambda/(lambda + one);

  /* Get ghost points */
  ierr = DAGetCorners(user->fine.da,&xs,&ys,0,&xm,&ym,0); CHKERRQ(ierr);
  ierr = DAGetGhostCorners(user->fine.da,&Xs,&Ys,0,&Xm,&Ym,0); CHKERRQ(ierr);
  ierr = VecGetArray(localX,&x); CHKERRQ(ierr);

  /* Compute initial guess */
  for (j=ys; j<ys+ym; j++) {
    temp = (double)(PetscMin(j,my-j-1))*hy;
    for (i=xs; i<xs+xm; i++) {
      row = i - Xs + (j - Ys)*Xm; 
      if (i == 0 || j == 0 || i == mx-1 || j == my-1 ) {
        x[row] = 0.0; 
        continue;
      }
      x[row] = temp1*sqrt( PetscMin( (double)(PetscMin(i,mx-i-1))*hx,temp) ); 
    }
  }
  ierr = VecRestoreArray(localX,&x); CHKERRQ(ierr);

  /* Insert values into global vector */
  ierr = DALocalToGlobal(user->fine.da,localX,INSERT_VALUES,X); CHKERRQ(ierr);

  stopTimer(&initialGuessTime);

  return 0;
}


 /* --------------------  Evaluate Function F(x) --------------------- */
#undef __FUNC__
#define __FUNC__ "FormFunction"
int FormFunction(SNES snes,Vec X,Vec F,void *ptr)
{
  AppCtx  *user = (AppCtx *) ptr;
  int     ierr, i, j, row, mx, my, xs, ys, xm, ym, Xs, Ys, Xm, Ym;
  double  two = 2.0, one = 1.0, lambda,hx, hy, hxdhy, hydhx,sc;
  Scalar  u, uxx, uyy, *x,*f;
  Vec     localX = user->fine.localX, localF = user->fine.localF; 

  startTimer(&funcTime);

  mx = user->fine.mx;       my = user->fine.my;       lambda = user->param;
  hx = one/(double)(mx-1);  hy = one/(double)(my-1);
  sc = hx*hy*lambda;        hxdhy = hx/hy;            hydhx = hy/hx;

  /* Get ghost points */
  ierr = DAGlobalToLocalBegin(user->fine.da,X,INSERT_VALUES,localX); CHKERRQ(ierr);
  ierr = DAGlobalToLocalEnd(user->fine.da,X,INSERT_VALUES,localX); CHKERRQ(ierr);
  ierr = DAGetCorners(user->fine.da,&xs,&ys,0,&xm,&ym,0); CHKERRQ(ierr);
  ierr = DAGetGhostCorners(user->fine.da,&Xs,&Ys,0,&Xm,&Ym,0); CHKERRQ(ierr);
  ierr = VecGetArray(localX,&x); CHKERRQ(ierr);
  ierr = VecGetArray(localF,&f); CHKERRQ(ierr);

  /* Evaluate function */
  
  for (j=ys; j<ys+ym; j++) {
    row = (j - Ys)*Xm + xs - Xs - 1; 
    for (i=xs; i<xs+xm; i++) {
      row++;
      if (i > 0 && i < mx-1 && j > 0 && j < my-1) {
        u = x[row];
        uxx = (two*u - x[row-1] - x[row+1])*hydhx;
        uyy = (two*u - x[row-Xm] - x[row+Xm])*hxdhy;
        f[row] = uxx + uyy - sc*exp(u);
      } else if ((i > 0 && i < mx-1) || (j > 0 && j < my-1)){
        f[row] = .5*two*(hydhx + hxdhy)*x[row];
      } else {
        f[row] = .25*two*(hydhx + hxdhy)*x[row];
      }
    }
  }
  ierr = VecRestoreArray(localX,&x); CHKERRQ(ierr);
  ierr = VecRestoreArray(localF,&f); CHKERRQ(ierr);

  /* Insert values into global vector */
  ierr = DALocalToGlobal(user->fine.da,localF,INSERT_VALUES,F); CHKERRQ(ierr);

  stopTimer(&funcTime);

  PLogFlops(11*ym*xm);
  return 0; 
} 

#undef __FUNC__
#define __FUNC__ "FormJacobian_Grid"
int FormJacobian_Grid(AppCtx *user,GridCtx *grid,Vec X, Mat *J,Mat *B)
{
  Mat     jac = *J;
  int     ierr, i, j, row, mx, my, xs, ys, xm, ym, Xs, Ys, Xm, Ym, col[5];
  int     nloc, *ltog, grow;
  Scalar  two = 2.0, one = 1.0, lambda, v[5], hx, hy, hxdhy, hydhx, sc, *x, value;
  Vec     localX = grid->localX;

  startTimer(&formGridTime);

  mx = grid->mx;            my = grid->my;            lambda = user->param;
  hx = one/(double)(mx-1);  hy = one/(double)(my-1);
  sc = hx*hy;               hxdhy = hx/hy;            hydhx = hy/hx;

  /* Get ghost points */
  ierr = DAGlobalToLocalBegin(grid->da,X,INSERT_VALUES,localX); CHKERRQ(ierr);
  ierr = DAGlobalToLocalEnd(grid->da,X,INSERT_VALUES,localX); CHKERRQ(ierr);
  ierr = DAGetCorners(grid->da,&xs,&ys,0,&xm,&ym,0); CHKERRQ(ierr);
  ierr = DAGetGhostCorners(grid->da,&Xs,&Ys,0,&Xm,&Ym,0); CHKERRQ(ierr);
  ierr = DAGetGlobalIndices(grid->da,&nloc,&ltog); CHKERRQ(ierr);

  ierr = VecGetArray(localX,&x); CHKERRQ(ierr);

  /* Evaluate Jacobian of function */
  for (j=ys; j<ys+ym; j++) {
    row = (j - Ys)*Xm + xs - Xs - 1; 
    for (i=xs; i<xs+xm; i++) {
      row++;
      grow = ltog[row];
      if (i > 0 && i < mx-1 && j > 0 && j < my-1) {
        v[0] = -hxdhy; col[0] = ltog[row - Xm];
        v[1] = -hydhx; col[1] = ltog[row - 1];
        v[2] = two*(hydhx + hxdhy) - sc*lambda*exp(x[row]); col[2] = grow;
        v[3] = -hydhx; col[3] = ltog[row + 1];
        v[4] = -hxdhy; col[4] = ltog[row + Xm];
        ierr = MatSetValues(jac,1,&grow,5,col,v,INSERT_VALUES); CHKERRQ(ierr);
      } else if ((i > 0 && i < mx-1) || (j > 0 && j < my-1)){
        value = .5*two*(hydhx + hxdhy);
        ierr = MatSetValues(jac,1,&grow,1,&grow,&value,INSERT_VALUES); CHKERRQ(ierr);
      } else {
        value = .25*two*(hydhx + hxdhy);
        ierr = MatSetValues(jac,1,&grow,1,&grow,&value,INSERT_VALUES); CHKERRQ(ierr);
      }
    }
  }
  ierr = MatAssemblyBegin(jac,MAT_FINAL_ASSEMBLY); CHKERRQ(ierr);
  ierr = VecRestoreArray(localX,&x); CHKERRQ(ierr);
  ierr = MatAssemblyEnd(jac,MAT_FINAL_ASSEMBLY); CHKERRQ(ierr);

  stopTimer(&formGridTime);

  return 0;
}

/* --------------------  Evaluate Jacobian F'(x) --------------------- */
#undef __FUNC__
#define __FUNC__ "FormJacobian"
int FormJacobian(SNES snes,Vec X,Mat *J,Mat *B,MatStructure *flag,void *ptr)
{
  AppCtx  *user = (AppCtx *) ptr;
  int     ierr;
  PCType  pctype;
  SLES    sles;
  PC      pc;

  startTimer(&jacobTime);

  *flag = SAME_NONZERO_PATTERN;
  ierr = FormJacobian_Grid(user,&user->fine,X,J,B); CHKERRQ(ierr);

  /* create coarse grid jacobian for preconditioner */
  ierr = SNESGetSLES(snes,&sles);CHKERRQ(ierr);
  ierr = SLESGetPC(sles,&pc);CHKERRQ(ierr);
  ierr = PCGetType(pc,&pctype);CHKERRQ(ierr);
  if (PetscTypeCompare(pctype,PCMG)) {

    ierr = SLESSetOperators(user->sles_fine,user->fine.J,user->fine.J,SAME_NONZERO_PATTERN);CHKERRA(ierr);

    /* restrict X to coarse grid */
    ierr = MatMult(user->R,X,user->coarse.x);CHKERRQ(ierr);
    ierr = VecPointwiseMult(user->Rscale,user->coarse.x,user->coarse.x);CHKERRQ(ierr);
    /* form Jacobian on coarse grid */
    ierr = FormJacobian_Grid(user,&user->coarse,user->coarse.x,&user->coarse.J,&user->coarse.J);CHKERRQ(ierr);
    ierr = SLESSetOperators(user->sles_coarse,user->coarse.J,user->coarse.J,SAME_NONZERO_PATTERN);CHKERRA(ierr);

  }

  stopTimer(&jacobTime);

  return 0;
}

/* 
   Unfortunately the PETSc multigrid interface expects the interpolation to 
   be provided as a multtrans() and the restriction as a mult() so we need
   to provide a shell matrix that reverses the roles
*/

/* this is our interpolation add routine */
int MatMultTransAdd_Ours(Mat shell,Vec x, Vec y, Vec z)
{
  Mat mat;
  int ierr;

  startTimer(&multTransTime);

  ierr = MatShellGetContext(shell,(void **)&mat);CHKERRQ(ierr);
  ierr = MatMultAdd(mat,x,y,z);CHKERRQ(ierr);
  
  stopTimer(&multTransTime);
  return 0;
}
/* this is our restriction routine */
int MatMult_Ours(Mat shell,Vec x, Vec y)
{
  Mat mat;
  int ierr;

  startTimer(&multTime);

  ierr = MatShellGetContext(shell,(void **)&mat);CHKERRQ(ierr);
  ierr = MatMultTrans(mat,x,y);CHKERRQ(ierr);

  stopTimer(&multTime);

  return 0;
}
int MatDestroy_Ours(Mat shell)
{
  Mat mat;
  int ierr;

  ierr = MatShellGetContext(shell,(void **)&mat);CHKERRQ(ierr);
  ierr = MatDestroy(mat);CHKERRQ(ierr);
  return 0;
}


#undef __FUNC__
#define __FUNC__ "FormInterpolation"
/*
      Forms the interpolation (and restriction) operator from 
coarse grid to fine.
*/
int FormInterpolation(AppCtx *user)
{
  int      ierr,i,j,i_start,m_fine,j_start,m,n,M,Mx = user->coarse.mx,My = user->coarse.my,*idx;
  int      m_ghost,n_ghost,*idx_c,m_ghost_c,n_ghost_c,m_coarse;
  int      row,i_start_ghost,j_start_ghost,cols[4],mx = user->fine.mx, m_c,my = user->fine.my;
  int      c0,c1,c2,c3,nc,ratio = user->ratio,i_end,i_end_ghost,m_c_local,m_fine_local;
  int      i_c,j_c,i_start_c,j_start_c,n_c,i_start_ghost_c,j_start_ghost_c,col;
  Scalar   v[4],x,y, one = 1.0;
  Mat      mat;
  Vec      Rscale;
  
  ierr = DAGetCorners(user->fine.da,&i_start,&j_start,0,&m,&n,0);CHKERRQ(ierr);
  ierr = DAGetGhostCorners(user->fine.da,&i_start_ghost,&j_start_ghost,0,&m_ghost,&n_ghost,0);CHKERRQ(ierr);
  ierr = DAGetGlobalIndices(user->fine.da,PETSC_NULL,&idx); CHKERRQ(ierr);

  ierr = DAGetCorners(user->coarse.da,&i_start_c,&j_start_c,0,&m_c,&n_c,0);CHKERRQ(ierr);
  ierr = DAGetGhostCorners(user->coarse.da,&i_start_ghost_c,&j_start_ghost_c,0,&m_ghost_c,&n_ghost_c,0);CHKERRQ(ierr);
  ierr = DAGetGlobalIndices(user->coarse.da,PETSC_NULL,&idx_c); CHKERRQ(ierr);

  /* create interpolation matrix */
  ierr = VecGetLocalSize(user->fine.x,&m_fine_local);CHKERRQ(ierr);
  ierr = VecGetLocalSize(user->coarse.x,&m_c_local);CHKERRQ(ierr);
  ierr = VecGetSize(user->fine.x,&m_fine);CHKERRQ(ierr);
  ierr = VecGetSize(user->coarse.x,&m_coarse);CHKERRQ(ierr);
  ierr = MatCreateMPIAIJ(PETSC_COMM_WORLD,m_fine_local,m_c_local,m_fine,m_coarse,
                         5,0,3,0,&mat);CHKERRQ(ierr);

  /* loop over local fine grid nodes setting interpolation for those*/
  for ( j=j_start; j<j_start+n; j++ ) {
    for ( i=i_start; i<i_start+m; i++ ) {
      /* convert to local "natural" numbering and then to PETSc global numbering */
      row    = idx[m_ghost*(j-j_start_ghost) + (i-i_start_ghost)];

      i_c = (i/ratio);    /* coarse grid node to left of fine grid node */
      j_c = (j/ratio);    /* coarse grid node below fine grid node */

      /* 
         Only include those interpolation points that are truly 
         nonzero. Note this is very important for final grid lines
         in x and y directions; since they have no right/top neighbors
      */
      x  = ((double)(i - i_c*ratio))/((double)ratio);
      y  = ((double)(j - j_c*ratio))/((double)ratio);
      /* printf("i j %d %d %g %g\n",i,j,x,y); */
      nc = 0;
      /* one left and below; or we are right on it */
      if (j_c < j_start_ghost_c || j_c > j_start_ghost_c+n_ghost_c) {
        SETERRQ3(1,1,"Sorry j %d %d %d",j_c,j_start_ghost_c,j_start_ghost_c+n_ghost_c);
      }
      if (i_c < i_start_ghost_c || i_c > i_start_ghost_c+m_ghost_c) {
        SETERRQ3(1,1,"Sorry i %d %d %d",i_c,i_start_ghost_c,i_start_ghost_c+m_ghost_c);
      }
      col      = m_ghost_c*(j_c-j_start_ghost_c) + (i_c-i_start_ghost_c);
      cols[nc] = idx_c[col];
      v[nc++]  = x*y - x - y + 1.0;
      /* one right and below */
      if (i_c*ratio != i) { 
        cols[nc] = idx_c[col+1];
        v[nc++]  = -x*y + x;
      }
      /* one left and above */
      if (j_c*ratio != j) { 
        cols[nc] = idx_c[col+m_ghost_c];
        v[nc++]  = -x*y + y;
      }
      /* one right and above */
      if (j_c*ratio != j && i_c*ratio != i) { 
        cols[nc] = idx_c[col+m_ghost_c+1];
        v[nc++]  = x*y;
      }
      ierr = MatSetValues(mat,1,&row,nc,cols,v,INSERT_VALUES); CHKERRQ(ierr); 
    }
  }
  ierr = MatAssemblyBegin(mat,MAT_FINAL_ASSEMBLY); CHKERRQ(ierr);
  ierr = MatAssemblyEnd(mat,MAT_FINAL_ASSEMBLY); CHKERRQ(ierr);

  ierr = VecDuplicate(user->coarse.x,&Rscale);CHKERRQ(ierr);
  ierr = VecSet(&one,user->fine.x);CHKERRQ(ierr);
  ierr = MatMultTrans(mat,user->fine.x,Rscale);CHKERRQ(ierr);
  ierr = VecReciprocal(Rscale);CHKERRQ(ierr);
  user->Rscale = Rscale;

  /*
     this is merely so we provide a restriction "matrix" to the multigrid code
     so we flip the roles of MatMult() and MatMultTrans() on the "interpolation/restriction"
     matrix
  */
  ierr = MatCreateShell(PETSC_COMM_WORLD,m_c_local,m_fine_local,m_coarse,m_fine,
                        mat,&user->R);CHKERRQ(ierr);
  ierr = MatShellSetOperation(user->R,MATOP_MULT,(void*)MatMult_Ours);CHKERRQ(ierr);
  ierr = MatShellSetOperation(user->R,MATOP_MULT_TRANS_ADD,(void*)MatMultTransAdd_Ours);CHKERRQ(ierr);
  ierr = MatShellSetOperation(user->R,MATOP_DESTROY,(void*)MatDestroy_Ours);CHKERRQ(ierr);
  return 0;
}
