import petsc.Vec;


final class FineCtx extends GridCtx {

    final Vec local r;

    FineCtx(int ratio, CoarseCtx local coarse) {
	super(ratio * (coarse.mx - 1) + 1,
	      ratio * (coarse.my - 1) + 1);
	
	r = x.duplicate(null);
    }

    public local void destroy(int[] local error) {
	super.destroy(error);
	r.destroy(error);
    }
}
